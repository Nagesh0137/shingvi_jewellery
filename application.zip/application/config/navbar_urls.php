<?php
defined('BASEPATH') or exit('No direct script access allowed');

$config['navbar'] = array(

    // 1. Dashboard
    array(
        'title' => 'Dashboard',
        'icon' => 'iconoir-home',
        'href' => 'admin/index',
        'method' => 'index',
    ),
    array(
        'title' => 'Add Numbers',
        'icon' => 'iconoir-numbered-list-left',
        'href' => 'admin/add_numbers',
        'method' => 'add_numbers',
    ),
    array(
        'title' => 'Numbers List',
        'icon' => 'iconoir-numbers',
        'href' => 'admin/numbers_list',
        'method' => 'numbers_list',
    ),
    array(
        'title' => 'Orders List',
        'icon' => 'iconoir-cart',
        'href' => 'admin/orders_list',
        'method' => 'orders_list',
    ),

    // 2. Master Management
    array(
        'title' => 'Master',
        'icon' => 'iconoir-database-tag',
        'href' => '#',
        'submenu' => array(
            array('title' => 'Add Category', 'url' => 'admin/add_category', 'method' => 'add_category'),
            array('title' => 'Add Banner', 'url' => 'admin/add_banner', 'method' => 'add_banner'),
            array('title' => 'About us', 'url' => 'admin/about_us', 'method' => 'about_us'),
            array('title' => 'Mission and Vision', 'url' => 'admin/mission_and_vision', 'method' => 'mission_and_vision'),
            array('title' => 'Add Filter', 'url' => 'admin/add_filter', 'method' => 'add_filter'),
        )
    ),

    // 3. Communication
    array(
        'title' => 'Communication',
        'icon' => 'iconoir-chat-lines',
        'href' => '#',
        'submenu' => array(
            array('title' => 'Contact Form List', 'url' => 'admin/contact_form_list', 'method' => 'contact_form'),
            array('title' => 'Send Notifications', 'url' => 'admin/notifications', 'method' => 'notifications'),
            array('title' => 'Email Templates', 'url' => 'admin/email_templates', 'method' => 'email_templates'),
        )
    ),

    // 4. Admin Management
    array(
        'title' => 'Admin Management',
        'icon' => 'iconoir-user-badge-check',
        'href' => '#',
        'submenu' => array(
            array('title' => 'Admin Position', 'url' => 'admin/admin_position', 'method' => 'admin_position'),
            array('title' => 'Add Admin', 'url' => 'admin/add_admin', 'method' => 'add_admin'),
            array('title' => 'Add permission Method', 'url' => 'admin/admin_permission_url', 'method' => 'admin_permission_url'),
            array('title' => 'Permission Setup', 'url' => 'admin/permission_setup', 'method' => 'permission_setup'),
        )
    ),

    // Optional Redundant Contact List Entry (can be removed if already in Communication)
    array(
        'title' => 'Contact Form List',
        'icon' => 'iconoir-contact-book',
        'href' => 'admin/contact_form_list',
        'method' => 'contact_form_list',
    ),

    // 5. Reports
    array(
        'title' => 'Reports',
        'icon' => 'iconoir-pie-chart',
        'href' => '#',
        'submenu' => array(
            array('title' => 'User Reports', 'url' => 'admin/user_reports', 'method' => 'user_reports'),
            array('title' => 'Activity Reports', 'url' => 'admin/activity_reports', 'method' => 'activity_reports'),
            array('title' => 'System Reports', 'url' => 'admin/system_reports', 'method' => 'system_reports'),
        )
    ),

);
