<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config['encryption_key'] = '801cd547b3553b8bc3af6f16477d1f466d08637afa8ea62e8616bb566b0b72a7';
