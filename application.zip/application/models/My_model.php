<?php
defined('BASEPATH') or exit('No direct script access allowed');
class My_model extends CI_model
{
	public function select_join_3($table1, $table2, $table3, $on1, $on2, $select, $where = [])
	{
		$this->db->select($select);
		$this->db->from($table1);
		$this->db->join($table2, $on1);
		$this->db->join($table3, $on2);
		if (!empty($where)) {
			$this->db->where($where);
		}
		return $this->db->get()->result_array();
	}
	// In application/models/My_model.php
	public function delete_where($table, $where)
	{
		return $this->db->where($where)->delete($table);
	}

	public function insert($tname, $data)
	{
		$this->db->insert($tname, $data);
		return $this->db->insert_id();
	}
	public function select($tname)
	{
		return $this->db->get($tname)->result_array();
	}
	public function select_where($tname, $cond)
	{
		$this->db->where($cond);
		return $this->db->get($tname)->result_array();
	}
	public function update($tname, $cond, $data)
	{
		$this->db->where($cond);
		return $this->db->update($tname, $data);
	}


	public function select_by_like($tname, $cond)
	{
		$this->db->or_like($cond);
		return $this->db->get('company_job_details_tbl')->result_array();
	}
	public function delthis($tname, $cond)
	{
		$this->db->where($cond);
		return $this->db->delete($tname);
	}
	public function query($query)
	{
		return $this->db->query($query)->result_array();
	}
	public function select_column($columns, $table_name)
	{
		return $this->db->select($columns)->get($table_name)->result_array();
	}
	public function insert_batch($table, $data)
	{
		return $this->db->insert_batch($table, $data);
	}
	public function select_where_login($tname, $cond)
	{
		$this->db->where($cond);
		return $this->db->get($tname)->result_array();
	}
	function create_table($tname, $arr)
	{
		$sql = "CREATE TABLE " . $tname . "(" . $tname . "_id int auto_increment primary key";
		foreach ($arr as $key => $value) {
			$sql .= ", " . $key . " text";
		}
		$sql .= ");";
		return ($this->db->query($sql));
	}
	public function multiple_images($image = array())
	{
		return $this->db->insert_batch('vichardhan_tbl', $image);
	}
	public function select_where_order($table, $where, $order_column, $order_type)
	{
		$this->db->where($where);
		$this->db->order_by($order_column, $order_type);
		$query = $this->db->get($table);
		return $query->result_array();
	}

	public function count_where($table, $where = [])
	{
		if (!empty($where)) {
			$this->db->where($where);
		}
		return $this->db->count_all_results($table);
	}
}
