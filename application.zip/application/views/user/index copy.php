<!-- Categories -->
<section class="border-top d-md-none col-sm d-block">
  <div class="container py-lg-1">
    <div class="overflow-auto" data-simplebar="">
      <div class="nav flex-nowrap justify-content-between gap-4 py-2">
        <?php
        foreach ($category as $row) {
          ?>
          <a class="nav-link align-items-center animate-underline gap-2 p-0" href="shop-catalog-grocery.html">
            <span class="d-flex align-items-center justify-content-center bg-body-tertiary rounded-circle"
              style="width: 40px; height: 40px">
              <i class="ci-percent text-primary fs-xl"></i>
            </span>
            <span class="d-block animate-target fw-semibold text-nowrap ms-1"><?= $row['category_name'] ?></span>
          </a>
        <?php } ?>
      </div>
    </div>
  </div>
</section>


<!-- Page content -->
<main class="content-wrapper">

  <!-- Hero slider -->
  <section class="position-relative mb-1 pb-0">
    <div class="swiper position-absolute top-0 start-0 w-100 h-100" data-swiper="{
          &quot;effect&quot;: &quot;fade&quot;,
          &quot;loop&quot;: true,
          &quot;speed&quot;: 400,
          &quot;pagination&quot;: {
            &quot;el&quot;: &quot;.swiper-pagination&quot;,
            &quot;clickable&quot;: true
          },
          &quot;autoplay&quot;: {
            &quot;delay&quot;: 5500,
            &quot;disableOnInteraction&quot;: false
          }
        }" data-bs-theme="dark">
      <div class="swiper-wrapper">

        <?php foreach ($banner as $key => $row) { ?>
          <!-- Slide -->
          <div class="swiper-slide position-relative" style="background-color: #6dafca">
            <div class="position-absolute d-flex align-items-center w-100 h-100 z-2">
              <div class="container mt-lg-n4">
                <div class="row">
                  <div class="col-9 col-sm-8 col-md-7 col-lg-6">
                    <p class="fs-sm text-white mb-lg-4"><strong><?= $row['banner_desc'] ?></strong></p>
                    <h1 class="pb-2 pb-md-3 pb-lg-4"><?= $row['banner_title'] ?></h1>
                    <!-- <a class="btn btn-lg btn-outline-light rounded-pill" href="shop-catalog-grocery.html">Shop now</a> -->
                  </div>
                </div>
              </div>
            </div>
            <img src="<?= base_url() ?>uploads/<?= $row['banner_img'] ?>"
              class="position-absolute top-0 start-0 w-100 h-100 object-fit-cover rtl-flip" alt="Image">
            <!-- Bottom shadow overlay -->
            <div style="
              position: absolute;
              left: 0; right: 0; bottom: 0; height: 150px;
              background: linear-gradient(to top, rgba(0, 0, 0, 0.65), rgba(0,0,0,0));
              pointer-events: none;
              z-index: 3;
            "></div>
          </div>
        <?php } ?>

      </div>

      <!-- Slider pagination (Bullets) -->
      <div class="swiper-pagination pb-sm-2"></div>
    </div>
    <div class="d-md-none" style="height: 380px"></div>
    <div class="d-none d-md-block d-lg-none" style="height: 420px"></div>
    <div class="d-none d-lg-block d-xl-none" style="height: 500px"></div>
    <div class="d-none d-xl-block d-xxl-none" style="height: 560px"></div>
    <div class="d-none d-xxl-block" style="height: 624px"></div>
  </section>

  <!-- Why Choose Us Section -->
  <section class="container py-5 mb-4">
    <div class="text-center mb-5">
      <h2 class="h1 mb-3">Why Choose VIP Numbers?</h2>
      <em class="lead text-muted">Get the perfect mobile number that represents your identity</em>
    </div>
    <div class="row g-4">
      <div class="col-lg-4 col-md-6">
        <div class="card h-100 border-0 shadow-sm text-center p-4">
          <div
            class="bg-primary bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center mx-auto mb-4"
            style="width: 80px; height: 80px;">
            <!-- Premium Quality: Use a star or diamond icon -->
            <i class="ci-star text-primary fs-1"></i>
          </div>
          <h4 class="mb-3">Premium Quality</h4>
          <p class="text-muted mb-0">Handpicked VIP numbers with unique patterns and sequences that make you stand out.
          </p>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="card h-100 border-0 shadow-sm text-center p-4">
          <div
            class="bg-success bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center mx-auto mb-4"
            style="width: 80px; height: 80px;">
            <!-- Instant Activation: Use a flash or clock icon -->
            <i class="ci-clock text-success fs-1"></i>
          </div>
          <h4 class="mb-3">Instant Activation</h4>
          <p class="text-muted mb-0">Get your VIP number activated instantly after purchase with complete documentation.
          </p>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="card h-100 border-0 shadow-sm text-center p-4">
          <div
            class="bg-warning bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center mx-auto mb-4"
            style="width: 80px; height: 80px;">
            <!-- 24/7 Support: Use a headphones or support icon -->
            <i class="ci-headphones text-warning fs-1"></i>
          </div>
          <h4 class="mb-3">24/7 Support</h4>
          <p class="text-muted mb-0">Round-the-clock customer support to help you find and activate your perfect number.
          </p>
        </div>
      </div>
    </div>
  </section>

  <!-- Featured categories that turns into carousel on screen < 992px (lg breackpoint) -->
  <!-- Categories Section -->




  <!-- Categories + Popular products -->
  <section class="container pb-5 mb-2 mt-3 mb-sm-3 mb-lg-4 mb-xl-5">
    <div class="row">

      <!-- Categories list -->


      <div class="col-lg-12">
        <div class="d-flex align-items-center justify-content-between border-bottom pb-3 pb-md-4 mb-3 mb-lg-4">
          <h2 class="h4 mb-0">
            <!-- <i class="ci-phone me-2 text-primary"></i> -->
            Premium VIP Numbers
          </h2>
          <div class="nav ms-3">
            <a class="nav-link animate-underline px-0 py-2" href="shop-catalog-grocery.html">
              <span class="animate-target">View all</span>
              <i class="ci-chevron-right fs-base ms-1"></i>
            </a>
          </div>
        </div>

        <!-- Products grid -->
        <div class="row row-cols-12 row-cols-sm-12 row-cols-md-4 row-cols-lg-3 row-cols-xl-4 g-4">

          <!-- Item -->
          <?php
          foreach ($product as $row) {

            ?>
            <div class="col-6 m-0 mt-2 pt-0" style="padding:3px;">
              <div class="card shadow-sm p-0 m-0 border-1 text-dark position-relative overflow-hidden">
                <!-- VIP Badge -->

                <div class="card-body" style="padding: 12px;">
                  <div class="d-flex w-100 justify-content-between align-items-center mb-1"
                    style="vertical-align: middle;">
                    <span class="badge bg-dark-subtle text-dark" style="font-size: 12px;vertical-align: middle;">Save
                      ₹2586</span>
                    <span class="text-muted small">
                      <i onclick="addToWishlist('<?= $row['numbers_tbl_id'] ?>')" class="ci-heart fs-5 text-danger"
                        style="cursor: pointer;"></i>
                    </span>
                  </div>
                  <!-- <div class="text-center mb-2">
                    <i class="ci-phone text-primary fs-2 mb-2"></i>
                  </div> -->
                  <h6 class="card-title text-center m-0 fw-bold text-primary" style="font-size: 17px;">
                    <?= $row['mobile_number'] ?>
                  </h6>
                  <div class="text-center p-0 m-0 mt-2">
                    <span style="font-size:12px;" class="mb-1 text-decoration-line-through text-muted">₹15,015</span>
                    <br>
                    <span style="font-size:16px;" class="mb-1 fw-bold text-success">₹12,429</span>
                  </div>
                  <div class=" mt-1">
                    <a class="nav-link w-100 float-end animate-underline fs-base px-0" href="#newAddressModal"
                      data-bs-toggle="modal">
                      <button class="btn btn-warning btn-sm float-end w-100 flex-fill fw-bold" style="font-size: 11px;">
                        <i class="ci-shopping-cart me-1"></i> Buy Now
                      </button>
                    </a>
                    <!-- onclick="buyNow('<?= $row['numbers_tbl_id'] ?>')" -->
                    <!-- <button class="btn btn-outline-primary btn-sm" style="font-size: 11px;">
                      <i class="ci-eye"></i>
                    </button> -->
                  </div>
                </div>
              </div>
            </div>
            <!-- <div class="col"> -->
            <!-- <div class="card product-card p-3 h-100 bg-transparent border-1 shadow-lg">
                 
                  <div class="card-body pt-0 px-1 px-md-2 px-lg-3 pb-2">
                    <div class="h6 mb-2"><?= $row['mobile_number'] ?></div>
                    <h3 class="fs-sm lh-base mb-0">
                      <a class="hover-effect-underline" style="font-size: 12px;">You Saved &#8377; 2354</a>
                    </h3>
                     
                  </div>

                  <div class="fs-xs text-body-secondary px-1 px-md-2 px-lg-3 pb-2 pb-md-3"><?= $row['price'] ?></div>

                </div> -->

            <!-- </div> -->
          <?php } ?>
          <div class="modal fade" id="newAddressModal" data-bs-backdrop="static" tabindex="-1"
            aria-labelledby="newAddressModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-md modal-dialog-centered">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="newAddressModalLabel">Add new address</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <form class="row g-3 g-lg-4 needs-validation" novalidate="">


                    <div class="col-lg-4">
                      <div class="position-relative">
                        <label for="add-zip" class="form-label">ZIP code</label>
                        <input type="text" class="form-control" id="add-zip" required="">
                        <div class="invalid-feedback">Please enter your ZIP code!</div>
                      </div>
                    </div>
                    <div class="col-lg-8">
                      <div class="position-relative">
                        <label for="add-address" class="form-label">Address</label>
                        <input type="text" class="form-control" id="add-address" required="">
                        <div class="invalid-feedback">Please enter your address!</div>
                      </div>
                    </div>
                    <div class="col-12">
                      <div class="form-check mb-0">
                        <input type="checkbox" class="form-check-input" id="set-primary-3">
                        <label for="set-primary-3" class="form-check-label">Set as primary address</label>
                      </div>
                    </div>
                    <div class="col-12">
                      <div class="d-flex gap-3 pt-2 pt-sm-0">
                        <button type="submit" class="btn btn-primary">Add address</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <script>
            function addToWishlist(id) {
              $.ajax({
                url: '<?= base_url("user/add_to_wishlist") ?>',
                type: 'POST',
                data: { id: id },
                success: function (response) {
                  console.log(response);
                  // You can show toast or update icon here
                }
              });
            }

            function buyNow(id) {
              $.ajax({
                url: '<?= base_url("user/add_to_buy") ?>',
                type: 'POST',
                data: { id: id },
                success: function (response) {
                  console.log(response);
                  // Redirect or show message if needed
                }
              });
            }
          </script>

        </div>
      </div>
    </div>
  </section>


  <!-- Number Categories -->
  <section class="container pb-5 mb-2 mb-sm-3 mb-lg-4 mb-xl-5">
    <h2 class="h3 text-center pb-1 pb-sm-2 pb-md-3 pb-lg-0 mb-4 mb-lg-5">Browse by Number Type</h2>
    <div class="swiper pb-lg-2" data-swiper="{
        &quot;slidesPerView&quot;: 1,
        &quot;spaceBetween&quot;: 24,
        &quot;pagination&quot;: {
          &quot;el&quot;: &quot;.swiper-pagination&quot;,
          &quot;clickable&quot;: true
        },
        &quot;breakpoints&quot;: {
          &quot;500&quot;: {
            &quot;slidesPerView&quot;: 2
          },
          &quot;768&quot;: {
            &quot;slidesPerView&quot;: 3
          },
          &quot;992&quot;: {
            &quot;slidesPerView&quot;: 4
          }
        }
      }">
      <div class="swiper-wrapper">

        <!-- Lucky Numbers -->
        <div class="swiper-slide text-center">
          <div class="position-relative d-inline-block text-dark-emphasis bg-warning-subtle rounded-circle p-5 mb-4">
            <i class="ci-star text-warning" style="font-size: 3rem;"></i>
          </div>
          <h3 class="h5 mb-2">
            <a class="animate-underline stretched-link" href="shop-catalog-grocery.html">
              <span class="animate-target">Lucky Numbers</span>
            </a>
          </h3>
          <p class="fs-sm mb-0">Numbers with repeating digits like 777, 888</p>
        </div>

        <!-- Sequential -->
        <div class="swiper-slide text-center">
          <div class="position-relative d-inline-block text-dark-emphasis bg-success-subtle rounded-circle p-5 mb-4">
            <i class="ci-sort text-success" style="font-size: 3rem;"></i>
          </div>
          <h3 class="h5 mb-2">
            <a class="animate-underline stretched-link" href="shop-catalog-grocery.html">
              <span class="animate-target">Sequential</span>
            </a>
          </h3>
          <p class="fs-sm mb-0">Sequential patterns like 123, 456, 789</p>
        </div>

        <!-- Premium VIP -->
        <div class="swiper-slide text-center">
          <div class="position-relative d-inline-block text-dark-emphasis bg-info-subtle rounded-circle p-5 mb-4">
            <i class="ci-award text-info" style="font-size: 3rem;"></i>
          </div>
          <h3 class="h5 mb-2">
            <a class="animate-underline stretched-link" href="shop-catalog-grocery.html">
              <span class="animate-target">Premium VIP</span>
            </a>
          </h3>
          <p class="fs-sm mb-0">Exclusive premium numbers for business</p>
        </div>

        <!-- Memorable -->
        <div class="swiper-slide text-center">
          <div class="position-relative d-inline-block text-dark-emphasis bg-danger-subtle rounded-circle p-5 mb-4">
            <i class="ci-bookmark text-danger" style="font-size: 3rem;"></i>
          </div>
          <h3 class="h5 mb-2">
            <a class="animate-underline stretched-link" href="shop-catalog-grocery.html">
              <span class="animate-target">Memorable</span>
            </a>
          </h3>
          <p class="fs-sm mb-2">Easy to remember patterns and combinations</p>
        </div>
      </div>

      <!-- Slider pagination (Bullets) -->
      <div class="swiper-pagination position-static mt-3 mt-sm-4"></div>
    </div>
  </section>





  <!-- Customer Reviews & Success Stories -->
  <section class="container pb-5 mb-2 mb-sm-3 mb-lg-4">
    <h2 class="h3 mb-4 text-center">What Our Customers Say</h2>
    <div class="row">

      <!-- Reviews Carousel -->
      <div class="col-lg-8 mb-4 mb-lg-0">
        <div class="d-flex flex-column gap-1 gap-md-2">

          <!-- Review 1 -->
          <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4">
              <div class="d-flex align-items-start">
                <div class="flex-shrink-0 me-3">
                  <div class="bg-primary bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center"
                    style="width: 60px; height: 60px;">
                    <i class="ci-user text-primary fs-4"></i>
                  </div>
                </div>
                <div class="flex-grow-1">
                  <div class="d-flex justify-content-between align-items-start mb-2">
                    <h5 class="mb-0">Rajesh Kumar</h5>
                    <div class="text-warning">
                      <i class="ci-star-filled"></i>
                      <i class="ci-star-filled"></i>
                      <i class="ci-star-filled"></i>
                      <i class="ci-star-filled"></i>
                      <i class="ci-star-filled"></i>
                    </div>
                  </div>
                  <p class="text-muted mb-2">"Got the perfect VIP number for my business! The process was smooth and the
                    number was activated instantly. Highly recommended!"</p>
                  <small class="text-body-secondary">Business Owner • Mumbai</small>
                </div>
              </div>
            </div>
          </div>

          <!-- Review 2 -->
          <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4">
              <div class="d-flex align-items-start">
                <div class="flex-shrink-0 me-3">
                  <div class="bg-success bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center"
                    style="width: 60px; height: 60px;">
                    <i class="ci-user text-success fs-4"></i>
                  </div>
                </div>
                <div class="flex-grow-1">
                  <div class="d-flex justify-content-between align-items-start mb-2">
                    <h5 class="mb-0">Priya Sharma</h5>
                    <div class="text-warning">
                      <i class="ci-star-filled"></i>
                      <i class="ci-star-filled"></i>
                      <i class="ci-star-filled"></i>
                      <i class="ci-star-filled"></i>
                      <i class="ci-star-filled"></i>
                    </div>
                  </div>
                  <p class="text-muted mb-2">"Amazing collection of VIP numbers! Found the lucky number I was looking
                    for. Customer service was excellent throughout."</p>
                  <small class="text-body-secondary">Entrepreneur • Delhi</small>
                </div>
              </div>
            </div>
          </div>

          <!-- Review 3 -->
          <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4">
              <div class="d-flex align-items-start">
                <div class="flex-shrink-0 me-3">
                  <div class="bg-warning bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center"
                    style="width: 60px; height: 60px;">
                    <i class="ci-user text-warning fs-4"></i>
                  </div>
                </div>
                <div class="flex-grow-1">
                  <div class="d-flex justify-content-between align-items-start mb-2">
                    <h5 class="mb-0">Amit Patel</h5>
                    <div class="text-warning">
                      <i class="ci-star-filled"></i>
                      <i class="ci-star-filled"></i>
                      <i class="ci-star-filled"></i>
                      <i class="ci-star-filled"></i>
                      <i class="ci-star"></i>
                    </div>
                  </div>
                  <p class="text-muted mb-2">"Great prices and genuine VIP numbers. The website is easy to use and the
                    delivery was super fast. Will definitely buy again!"</p>
                  <small class="text-body-secondary">Professional • Bangalore</small>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

      <!-- How It Works: Step-by-Step Design -->
      <div class="col-lg-4">
        <div class="card h-100 border-0 shadow-sm">
          <div class="card-body p-4">
            <h3 class="h4 mb-4 text-center text-primary">How It Works</h3>
            <ol class="list-unstyled m-0 p-0">
              <!-- Step 1 -->
              <li class="mb-4">
                <div class="d-flex align-items-start">
                  <div
                    class="bg-primary bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center flex-shrink-0 me-3"
                    style="width: 44px; height: 44px;">
                    <span class="fw-bold text-primary fs-5">1</span>
                  </div>
                  <div>
                    <h5 class="mb-1">Browse Numbers</h5>
                    <p class="mb-0 text-muted small">No login or registration required. Instantly explore our premium
                      VIP numbers and pick your favorite.</p>
                  </div>
                </div>
              </li>
              <!-- Step 2 -->
              <li class="mb-4">
                <div class="d-flex align-items-start">
                  <div
                    class="bg-success bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center flex-shrink-0 me-3"
                    style="width: 44px; height: 44px;">
                    <span class="fw-bold text-success fs-5">2</span>
                  </div>
                  <div>
                    <h5 class="mb-1">Secure Payment</h5>
                    <p class="mb-0 text-muted small">Select your number and pay securely with our encrypted payment
                      gateway. Your details are always safe.</p>
                  </div>
                </div>
              </li>
              <!-- Step 3 -->
              <li>
                <div class="d-flex align-items-start">
                  <div
                    class="bg-warning bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center flex-shrink-0 me-3"
                    style="width: 44px; height: 44px;">
                    <span class="fw-bold text-warning fs-5">3</span>
                  </div>
                  <div>
                    <h5 class="mb-1">Get Your Number</h5>
                    <p class="mb-0 text-muted small">Receive your VIP number instantly after payment. No waiting, no
                      hassle—it's yours right away!</p>
                  </div>
                </div>
              </li>
            </ol>
            <div class="text-center mt-4">
              <a class="btn btn-warning rounded-pill fw-bold px-4" href="#!">
                Get Started Now
                <i class="ci-chevron-right fs-base ms-1"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>




  <!-- Final CTA Section -->
  <section class="bg-body-tertiary py-5">
    <div class="container text-center">
      <div class="row justify-content-center">
        <div class="col-lg-8">
          <h2 class="h1 mb-4">Ready to Get Your VIP Number?</h2>
          <p class="lead text-muted mb-4">Join thousands of satisfied customers who found their perfect mobile number
            with us.</p>
          <div class="d-flex flex-wrap justify-content-center gap-3">
            <a class="btn btn-primary btn-lg rounded-pill px-4" href="#!">
              <i class="ci-phone me-2"></i>
              Browse All Numbers
            </a>
            <a class="btn btn-outline-primary btn-lg rounded-pill px-4" href="#!">
              <i class="ci-headphones me-2"></i>
              Contact Support
            </a>
          </div>
        </div>
      </div>
    </div>
  </section>
</main>