<!-- About Us Hero Section -->
<section class="container py-5">
    <div class="row ">
        <?php if (isset($about[0])): ?>
            <div class="col-lg-6 mb-4 mb-lg-0">
                <div class="pe-lg-4">
                    <h4 class="display-5 mb-4 text-dark"><?= htmlspecialchars($about[0]['about_title']) ?>
                    </h4>
                    <em class="text-muted mb-4 h6"><?= nl2br(htmlspecialchars($about[0]['about_desc'])) ?></em>

                    <!-- Quick Stats -->
                    <div class=" row g-3 mb-4 mt-2">
                        <div class="col-6">
                            <div class="bg-primary bg-opacity-10 rounded-3 p-3 text-center">
                                <div class="h4 text-primary mb-1">5+</div>
                                <small class="text-muted">Years Experience</small>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="bg-success bg-opacity-10 rounded-3 p-3 text-center">
                                <div class="h4 text-success mb-1">100%</div>
                                <small class="text-muted">Customer Satisfaction</small>
                            </div>
                        </div>
                    </div>

                    <!-- Key Features -->
                    <div class="row g-4 mt-2">
                        <div class="col-6">
                            <div class="d-flex align-items-center">
                                <div class="bg-primary bg-opacity-10 rounded-circle p-3 me-3">
                                    <i class="ci-star text-primary fs-4"></i>
                                </div>
                                <div>
                                    <h6 class="mb-1">Premium Quality</h6>
                                    <small class="text-muted">Excellence in every number</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="d-flex align-items-center">
                                <div class="bg-success bg-opacity-10 rounded-circle p-3 me-3">
                                    <i class="ci-award  text-success fs-4"></i>
                                </div>
                                <div>
                                    <h6 class="mb-1">Trusted Service</h6>
                                    <small class="text-muted">Reliable & secure</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="d-flex align-items-center">
                                <div class="bg-info bg-opacity-10 rounded-circle p-3 me-3">
                                    <i class="ci-phone text-info fs-4"></i>
                                </div>
                                <div>
                                    <h6 class="mb-1">24/7 Support</h6>
                                    <small class="text-muted">Always here to help</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="d-flex align-items-center">
                                <div class="bg-warning bg-opacity-10 rounded-circle p-3 me-3">
                                    <i class="ci-delivery text-warning fs-4"></i>
                                </div>
                                <div>
                                    <h6 class="mb-1">Fast Delivery</h6>
                                    <small class="text-muted">Quick activation</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6   ">
                <img src="<?= base_url() ?>uploads/<?= $about[0]['about_img'] ?>" alt="About VIP Numbers"
                    class=" rounded-3 shadow-lg" height="10px">

            </div>
        <?php else: ?>
            <!-- Default content if no about data -->
            <div class="col-lg-6 mb-4 mb-lg-0">
                <div class="pe-lg-4">
                    <h1 class="display-4 mb-4 text-gradient">About VIP Numbers</h1>
                    <p class="lead text-muted mb-4">We are dedicated to providing premium VIP mobile numbers that
                        reflect your unique identity and status. Our carefully curated collection offers exclusive
                        number combinations that make you stand out.</p>

                    <!-- Quick Stats -->
                    <div class="row g-3 mb-4">
                        <div class="col-6">
                            <div class="bg-primary bg-opacity-10 rounded-3 p-3 text-center">
                                <div class="h4 text-primary mb-1">5+</div>
                                <small class="text-muted">Years Experience</small>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="bg-success bg-opacity-10 rounded-3 p-3 text-center">
                                <div class="h4 text-success mb-1">100%</div>
                                <small class="text-muted">Customer Satisfaction</small>
                            </div>
                        </div>
                    </div>

                    <!-- Key Features -->
                    <div class="row g-4 mt-2">
                        <div class="col-6">
                            <div class="d-flex align-items-center">
                                <div class="bg-primary bg-opacity-10 rounded-circle p-3 me-3">
                                    <i class="ci-star text-primary fs-4"></i>
                                </div>
                                <div>
                                    <h6 class="mb-1">Premium Quality</h6>
                                    <small class="text-muted">Excellence in every number</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="d-flex align-items-center">
                                <div class="bg-success bg-opacity-10 rounded-circle p-3 me-3">
                                    <i class="ci-security-check text-success fs-4"></i>
                                </div>
                                <div>
                                    <h6 class="mb-1">Trusted Service</h6>
                                    <small class="text-muted">Reliable & secure</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="d-flex align-items-center">
                                <div class="bg-info bg-opacity-10 rounded-circle p-3 me-3">
                                    <i class="ci-phone text-info fs-4"></i>
                                </div>
                                <div>
                                    <h6 class="mb-1">24/7 Support</h6>
                                    <small class="text-muted">Always here to help</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="d-flex align-items-center">
                                <div class="bg-warning bg-opacity-10 rounded-circle p-3 me-3">
                                    <i class="ci-delivery text-warning fs-4"></i>
                                </div>
                                <div>
                                    <h6 class="mb-1">Fast Delivery</h6>
                                    <small class="text-muted">Quick activation</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="position-relative image-overlay">
                    <div class="bg-gradient-primary rounded-3 d-flex align-items-center justify-content-center shadow-lg"
                        style="min-height: 400px;">
                        <div class="text-center text-white">
                            <i class="ci-phone fs-1 mb-3"></i>
                            <h4>VIP Mobile Numbers</h4>
                            <p class="mb-0">Premium • Exclusive • Unique</p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- Statistics Section -->
<section class="bg-light py-5" data-aos="fade-up">
    <div class="container">
        <div class="row g-4 text-center">
            <div class="col-md-3 col-6">
                <div class="stats-counter text-primary mb-2" data-count="10000">0</div>
                <p class="mb-0 text-muted">Happy Customers</p>
            </div>
            <div class="col-md-3 col-6">
                <div class="stats-counter text-success mb-2" data-count="50000">0</div>
                <p class="mb-0 text-muted">VIP Numbers</p>
            </div>
            <div class="col-md-3 col-6">
                <div class="stats-counter text-info mb-2" data-count="100">0</div>
                <p class="mb-0 text-muted">Cities Covered</p>
            </div>
            <div class="col-md-3 col-6">
                <div class="stats-counter text-warning mb-2">24/7</div>
                <p class="mb-0 text-muted">Customer Support</p>
            </div>
        </div>
    </div>
</section>

<!-- Mission & Vision Section -->
<section class="container py-5 my-5" data-aos="fade-up">
    <div class="text-center mb-5">
        <h2 class="display-5 mb-3 text-dark">Our Mission & Vision</h2>
        <em class="lead text-muted">Driving excellence and innovation in the VIP numbers industry</em>
    </div>

    <?php if (isset($mission_vision[0])): ?>
        <div class="row align-items-center">
            <div class="col-lg-6 mb-4 mb-lg-0" data-aos="fade-right">
                <div class="position-relative image-overlay">
                    <img src="<?= base_url() ?>uploads/<?= $mission_vision[0]['mission_vision_img'] ?>"
                        alt="Mission & Vision" class="img-fluid rounded-3 shadow">
                    <div
                        class="position-absolute bottom-0 start-0 h-25 end-0 bg-gradient-to-t from-dark to-transparent rounded-bottom-3 p-4">
                        <div class="text-white">
                            <!-- <h4 class="mb-2"><?= htmlspecialchars($mission_vision[0]['mission_vision_title']) ?></h4> -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6" data-aos="fade-left">
                <div class="ps-lg-4">
                    <div class="feature-card mb-4">
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-3">
                                <div class="bg-primary rounded-circle p-3 me-3">
                                    <i class="ci-target text-white fs-4"></i>
                                </div>
                                <h3 class="mb-0">Our Mission</h3>
                            </div>
                            <p class="text-muted mb-0">
                                <?= nl2br(htmlspecialchars($mission_vision[0]['mission_vision_desc'])) ?>
                            </p>
                        </div>
                    </div>

                    <div class="feature-card">
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-3">
                                <div class="bg-success rounded-circle p-3 me-3">
                                    <i class="ci-eye text-white fs-4"></i>
                                </div>
                                <h3 class="mb-0">Our Vision</h3>
                            </div>
                            <p class="text-muted mb-0">To become the leading provider of premium VIP mobile numbers
                                globally, setting new standards of excellence and customer satisfaction in the
                                telecommunications industry.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <!-- Default Mission & Vision content -->
        <div class="row align-items-center">
            <div class="col-lg-6 mb-4 mb-lg-0" data-aos="fade-right">
                <div class="position-relative image-overlay">
                    <div class="bg-gradient-primary rounded-3 d-flex align-items-center justify-content-center shadow"
                        style="height: 400px;">
                        <div class="text-center text-white">
                            <i class="ci-rocket fs-1 mb-3"></i>
                            <h4>Innovation & Excellence</h4>
                            <p class="mb-0">Driving the future of premium numbers</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6" data-aos="fade-left">
                <div class="ps-lg-4">
                    <div class="feature-card mb-4">
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-3">
                                <div class="bg-primary rounded-circle p-3 me-3">
                                    <i class="ci-target text-white fs-4"></i>
                                </div>
                                <h3 class="mb-0">Our Mission</h3>
                            </div>
                            <p class="text-muted mb-0">To provide exceptional VIP mobile numbers that reflect our
                                customers' unique identity and status. We are committed to delivering premium quality
                                numbers with unmatched customer service and innovative solutions.</p>
                        </div>
                    </div>

                    <div class="feature-card">
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-3">
                                <div class="bg-success rounded-circle p-3 me-3">
                                    <i class="ci-eye text-white fs-4"></i>
                                </div>
                                <h3 class="mb-0">Our Vision</h3>
                            </div>
                            <p class="text-muted mb-0">To become the leading provider of premium VIP mobile numbers
                                globally, setting new standards of excellence and customer satisfaction in the
                                telecommunications industry.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</section>





<!-- CTA Section -->
<section class="bg-primary py-5" data-bs-theme="dark" data-aos="fade-up">
    <div class="container text-center">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <h2 class="display-6 text-white mb-3">Ready to Get Your VIP Number?</h2>
                <p class="lead text-white-50 mb-4">Join thousands of satisfied customers who have found their
                    perfect VIP mobile number with us.</p>
                <div class="d-flex flex-column flex-sm-row gap-3 justify-content-center">
                    <a href="<?= base_url() ?>user/products" class="btn btn-light btn-lg">Browse Numbers</a>
                    <a href="<?= base_url() ?>user/contact" class="btn btn-outline-light btn-lg">Contact Us</a>
                </div>
            </div>
        </div>
    </div>
</section>



<!-- JavaScript for animations and interactions -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Counter animation
        const counters = document.querySelectorAll('.stats-counter[data-count]');

        const animateCounter = (counter) => {
            const target = parseInt(counter.getAttribute('data-count'));
            const increment = target / 100;
            let current = 0;

            const updateCounter = () => {
                if (current < target) {
                    current += increment;
                    counter.textContent = Math.floor(current).toLocaleString() + '+';
                    requestAnimationFrame(updateCounter);
                } else {
                    counter.textContent = target.toLocaleString() + '+';
                }
            };

            updateCounter();
        };

        // Intersection Observer for counter animation
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateCounter(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        });

        counters.forEach(counter => {
            observer.observe(counter);
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Add loading effect to images
        const images = document.querySelectorAll('img[src*="uploads"]');
        images.forEach(img => {
            img.addEventListener('load', function () {
                this.classList.add('loaded');
            });

            if (img.complete) {
                img.classList.add('loaded');
            }
        });
    });
</script>

<style>
    /* Enhanced styles for the about page */
    html {
        scroll-behavior: smooth;
    }

    /* Image loading effect */
    img[src*="uploads"] {
        transition: opacity 0.3s ease;
        opacity: 0;
    }

    img[src*="uploads"].loaded {
        opacity: 1;
    }

    /* Custom gradient background */
    .bg-gradient-primary {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }

    .bg-gradient-to-t {
        background: linear-gradient(to top, rgba(0, 0, 0, 0.8) 0%, transparent 100%);
    }

    /* Text gradient effect */
    .text-gradient {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }

    /* Enhanced hover effects */
    .team-card:hover,
    .feature-card:hover {
        transform: translateY(-10px);
        transition: all 0.3s ease;
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15) !important;
    }

    .value-icon:hover {
        transform: scale(1.1) rotate(5deg);
        transition: all 0.3s ease;
    }

    /* Button hover effects */
    .btn:hover {
        transform: translateY(-2px);
        transition: all 0.3s ease;
    }

    .btn-lg:hover {
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
    }

    /* Stats counter styling */
    .stats-counter {
        font-weight: 700;
        font-size: 2.5rem;
        line-height: 1;
    }

    /* Image overlay effects */
    .image-overlay {
        position: relative;
        overflow: hidden;
        border-radius: 1rem;
    }

    .image-overlay::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(45deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.1));
        opacity: 0;
        transition: opacity 0.3s ease;
        z-index: 1;
    }

    .image-overlay:hover::before {
        opacity: 1;
    }

    /* Accordion customization */
    .accordion-button {
        background: transparent;
        border: none;
        font-weight: 600;
        color: #333;
    }

    .accordion-button:not(.collapsed) {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        box-shadow: none;
    }

    .accordion-button::after {
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23333'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
    }

    .accordion-button:not(.collapsed)::after {
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23fff'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
    }

    /* Responsive improvements */
    @media (max-width: 768px) {
        .stats-counter {
            font-size: 2rem;
        }

        .display-4 {
            font-size: 2.25rem;
        }

        .display-5 {
            font-size: 1.875rem;
        }

        .display-6 {
            font-size: 1.625rem;
        }

        .value-icon {
            width: 60px !important;
            height: 60px !important;
        }

        .feature-card .card-body {
            padding: 1.5rem;
        }
    }

    @media (max-width: 576px) {
        .stats-counter {
            font-size: 1.75rem;
        }

        .lead {
            font-size: 1rem;
        }

        .btn-lg {
            padding: 0.75rem 1.5rem;
            font-size: 1rem;
        }

        .image-overlay div[style*="height"] {
            min-height: 100px !important;
        }
    }

    /* Animation for page load */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .animate-fadeInUp {
        animation: fadeInUp 0.8s ease-out;
    }

    /* Loading spinner for images */
    .img-loading {
        background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
        background-size: 200% 100%;
        animation: loading 1.5s infinite;
    }

    @keyframes loading {
        0% {
            background-position: 200% 0;
        }

        100% {
            background-position: -200% 0;
        }
    }
</style>