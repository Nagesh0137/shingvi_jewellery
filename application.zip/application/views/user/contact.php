<!-- Page content -->
<main class="content-wrapper">
    <div class="container py-5 mb-2 mb-sm-3 mb-md-4 mb-lg-5 mt-lg-3 mt-xl-4">

        <!-- Page title -->
        <h1 class="text-center">Contact us</h1>
        <p class="text-center pb-2 pb-sm-3">Get in touch for VIP mobile numbers, premium digits, and special number
            services</p>


        <!-- Form + Image -->
        <section class="row row-cols-1 row-cols-md-2 g-0 overflow-hidden rounded-5">

            <!-- Contact form -->
            <div class="col bg-body-tertiary py-5 px-4 px-xl-5">
                <form class="needs-validation py-md-2 px-md-1 px-lg-3 mx-lg-3" novalidate="">
                    <div class="position-relative mb-4">
                        <label for="name" class="form-label">Name *</label>
                        <input type="text" class="form-control form-control-lg rounded-pill"
                            placeholder="Enter Full Name" id="name" required="">
                        <div class="invalid-tooltip bg-transparent z-0 py-0 ps-3">Enter your name!</div>
                    </div>
                    <div class="position-relative mb-4">
                        <label for="email" class="form-label">Email *</label>
                        <input type="email" class="form-control form-control-lg rounded-pill" placeholder="Enter Email"
                            id="email" required="">
                        <div class="invalid-tooltip bg-transparent z-0 py-0 ps-3">Enter your email address!</div>
                    </div>
                    <div class="position-relative mb-4">
                        <label for="phone" class="form-label">Your Phone Number</label>
                        <input type="tel" class="form-control form-control-lg rounded-pill" id="phone"
                            placeholder="+91 XXXXX XXXXX">
                    </div>
                    <div class="position-relative mb-4">
                        <label class="form-label">Subject *</label>
                        <select class="form-select form-select-lg rounded-pill" data-select="{
                  &quot;classNames&quot;: {
                    &quot;containerInner&quot;: [&quot;form-select&quot;, &quot;form-select-lg&quot;, &quot;rounded-pill&quot;]
                  }
                }" required="">
                            <option value="">Select subject</option>
                            <option value="VIP Number Inquiry">VIP Number Inquiry</option>
                            <option value="Premium Digits">Premium Digits</option>
                            <option value="Number Availability">Number Availability</option>
                            <option value="Pricing Information">Pricing Information</option>
                            <option value="Custom Number Request">Custom Number Request</option>
                            <option value="Golden Numbers">Golden Numbers</option>
                            <option value="Platinum Numbers">Platinum Numbers</option>
                            <option value="Technical Support">Technical Support</option>
                            <option value="Order Status">Order Status</option>
                            <option value="General Query">General Query</option>
                        </select>
                        <div class="invalid-tooltip bg-transparent z-0 py-0 ps-3">Select the subject of your message!
                        </div>
                    </div>
                    <div class="position-relative mb-4">
                        <label for="message" class="form-label">Message</label>
                        <textarea class="form-control form-control-lg rounded-6" id="message" rows="3"
                            placeholder="Tell us about your VIP number requirements, preferred digits, or any specific patterns you're looking for..."
                            required=""></textarea>
                        <div class="invalid-tooltip bg-transparent z-0 py-0 ps-3">Write your message!</div>
                    </div>

                    <!-- <div class="position-relative mb-4">
                        <label for="budget" class="form-label">Budget Range</label>
                        <select class="form-select form-select-lg rounded-pill" id="budget">
                            <option value="">Select budget range</option>
                            <option value="Under 10000">Under ₹10,000</option>
                            <option value="10000-25000">₹10,000 - ₹25,000</option>
                            <option value="25000-50000">₹25,000 - ₹50,000</option>
                            <option value="50000-100000">₹50,000 - ₹1,00,000</option>
                            <option value="100000-250000">₹1,00,000 - ₹2,50,000</option>
                            <option value="Above 250000">Above ₹2,50,000</option>
                        </select>
                    </div> -->
                    <div class="pt-2">
                        <button type="submit" class="btn btn-lg btn-dark rounded-pill">Send Inquiry</button>
                        <div class="form-text mt-2">
                            <small class="text-muted">
                                <i class="ci-shield-check me-1"></i>
                                Your information is secure and will only be used to assist with your VIP number inquiry.
                            </small>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Image -->
            <div class="col position-relative">
                <img src="<?= base_url() ?>uassets/img/contactus.jpg" class=" h-100 center object-fit-cover"
                    alt="Image">
            </div>
        </section>


        <!-- Contacts -->
        <section class="row row-cols-1 row-cols-sm-2 row-cols-lg-4 g-4 pt-5 pb-3 pb-md-4 pb-lg-3 mt-lg-0 mt-xxl-4">
            <div class="col text-center pt-1 pt-sm-2 pt-md-3">
                <div
                    class="position-relative d-inline-block bg-body-tertiary text-dark-emphasis fs-xl rounded-circle p-4 mb-3">
                    <i class="ci-phone-outgoing position-absolute top-50 start-50 translate-middle"></i>
                </div>
                <h3 class="h6">Call us directly</h3>
                <ul class="list-unstyled m-0">
                    <li class="nav animate-underline justify-content-center">
                        VIP Numbers:
                        <a class="nav-link animate-target fs-base ms-1 p-0"
                            href="tel:+919876543210">+91&nbsp;98765&nbsp;43210</a>
                    </li>
                    <li class="nav animate-underline justify-content-center">
                        Premium Support:
                        <a class="nav-link animate-target fs-base ms-1 p-0"
                            href="tel:+919999999999">+91&nbsp;99999&nbsp;99999</a>
                    </li>
                </ul>
            </div>
            <div class="col text-center pt-1 pt-sm-2 pt-md-3">
                <div
                    class="position-relative d-inline-block bg-body-tertiary text-dark-emphasis fs-xl rounded-circle p-4 mb-3">
                    <i class="ci-mail position-absolute top-50 start-50 translate-middle"></i>
                </div>
                <h3 class="h6">Send a message</h3>
                <ul class="list-unstyled m-0">
                    <li class="nav animate-underline justify-content-center">
                        VIP Numbers:
                        <a class="nav-link animate-target fs-base ms-1 p-0"
                            href="mailto:vip@mobilenumbers.com">vip@mobilenumbers.com</a>
                    </li>
                    <!-- <li class="nav animate-underline justify-content-center">
                        Support:
                        <a class="nav-link animate-target fs-base ms-1 p-0"
                            href="mailto:support@mobilenumbers.com">support@mobilenumbers.com</a>
                    </li> -->
                </ul>
            </div>
            <div class="col text-center pt-1 pt-sm-2 pt-md-3">
                <div
                    class="position-relative d-inline-block bg-body-tertiary text-dark-emphasis fs-xl rounded-circle p-4 mb-3">
                    <i class="ci-map-pin position-absolute top-50 start-50 translate-middle"></i>
                </div>
                <h3 class="h6">Office location</h3>
                <ul class="list-unstyled m-0">
                    <li>Mumbai 400001, India</li>
                    <li>123 VIP Tower, Nariman Point</li>
                </ul>
            </div>
            <div class="col text-center pt-1 pt-sm-2 pt-md-3">
                <div
                    class="position-relative d-inline-block bg-body-tertiary text-dark-emphasis fs-xl rounded-circle p-4 mb-3">
                    <i class="ci-clock position-absolute top-50 start-50 translate-middle"></i>
                </div>
                <h3 class="h6">Business hours</h3>
                <ul class="list-unstyled m-0">
                    <li>Mon - Fri 9:00 - 19:00</li>
                    <li>Sat - Sun 10:00 - 17:00</li>
                </ul>
            </div>
        </section>

        <hr class="my-lg-5">


        <!-- Help center CTA -->
        <section class="text-center pb-xxl-3 pt-4 pt-lg-3">
            <h2 class="pt-md-2 pt-lg-0">Need help finding your VIP number?</h2>
            <p class="pb-2 pb-sm-3">Browse our collection of premium mobile numbers or check our FAQ section for common
                questions about VIP numbers and pricing.</p>
            <a class="btn btn-lg btn-outline-dark rounded-pill" href="#!">Browse VIP Numbers</a>
        </section>
    </div>
</main>