<!-- Navigation bar (Page header) -->
<header class="navbar navbar-expand-lg navbar-sticky bg-body d-block z-fixed p-0"
  data-sticky-navbar="{&quot;offset&quot;: 500}">
  <div class="container py-2 py-lg-3">
    <div class="d-flex align-items-center gap-3">

      <!-- Mobile offcanvas menu toggler (Hamburger) -->
      <button type="button" class="navbar-toggler me-4 me-md-2" data-bs-toggle="offcanvas" data-bs-target="#navbarNav"
        aria-controls="navbarNav" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Country slect visible on screens > 768px wide (md breakpoint) -->


      <!-- City slect visible on screens > 768px wide (md breakpoint) -->

      <a class="navbar-brand fs-2 py-0 m-0 me-auto me-sm-n5 d-md-block d-sm d-none" href="index.html"><img
          src="<?= base_url() ?>uassets/img/vi.png" alt="" class="img-fluid" height="30" width="40"></a>
    </div>

    <!-- Navbar brand (Logo) -->
    <ul class="navbar-nav position-relative me-xl-n5 d-md-flex d-sm d-none">
      <li class="nav-item pb-lg-2 me-lg-n1 me-xl-0">
        <a href="<?= base_url() ?>user/index" class="nav-link active">Home</a>
      </li>

      <li class="nav-item dropdown pb-lg-2 me-lg-n1 me-xl-0">
        <a class="nav-link " href="<?= base_url() ?>user/about">About Us</a>

      </li>
      <li class="nav-item dropdown pb-lg-2 me-lg-n1 me-xl-0">
        <a class="nav-link " href="<?= base_url() ?>user/products">Products</a>

      </li>
      <li class="nav-item pb-lg-2 me-lg-n2 me-xl-0">
        <a class="nav-link" href="<?= base_url() ?>user/contact">Contact</a>
      </li>
      <li class="nav-item pb-lg-2 me-lg-n2 me-xl-0">
        <a class="nav-link" href="<?= base_url() ?>user/faq">FAQ</a>
      </li>
    </ul>
    <!-- Button group -->
    <div class="d-flex align-items-center"><!-- Cart button -->
      <button type="button"
        class="btn btn-icon btn-lg fs-xl btn-outline-secondary position-relative border-0 rounded-circle animate-scale"
        data-bs-toggle="offcanvas" data-bs-target="#shoppingCart" aria-controls="shoppingCart"
        aria-label="Shopping cart">
        <span class="position-absolute top-0 start-100 badge fs-xs text-bg-primary rounded-pill mt-1 ms-n4 z-2"
          style="--cz-badge-padding-y: .25em; --cz-badge-padding-x: .42em">3</span>
        <!-- <i class="ci-shopping-bag animate-target"></i> -->
        <i class="ci-heart animate-target  me-1"></i>
      </button>
    </div>
  </div>

  <!-- Main navigation that turns into offcanvas on screens < 992px wide (lg breakpoint) -->

</header>