<div class="container-fluid">
	<div class="row">
		<div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <h3 class="p-0 m-0">
                        Add Product
                    </h3>
                    <form action="<?=base_url()?>admin/update_product" method="post" enctype="multipart/form-data" >
                    	<input type="hidden" name="product_tbl_id" value="<?=$det[0]['product_tbl_id']?>">
                        <div id="add_product_form">
                            <div class="row m-0 mt-3">
                            <div class="col-md-4 mb-3">
                                <label >Product name <span class="text-danger">*</span> </label>
                                <input type="text" name="product_name" value="<?=$det[0]['product_name']?>" class="form-control" placeholder="e.g.  meat trays , produce trays" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label >Avg Price <span class="text-danger">*</span> </label>
                                <input type="number" step="0.01" class="form-control" name="avg_price" value="<?=$det[0]['avg_price']?>" placeholder="Enter Avg Price" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label>Product Image <span class="text-danger">*</span> </label>
                                <input name="product_img" class="file-upload form-control" type="file" accept="image/*">
                                <input name="product_img1" value="<?=$det[0]['product_img'] ?>" class="form-control" type="hidden">
                            </div>
                            <div class="col-md-8 mb-3">
                                <label >Product Details <span class="text-danger">*</span> </label>
                                <input type="text" name="product_details" class="form-control" value="<?=$det[0]['product_details']?>" placeholder="Enter Product Details" required>
                            </div>
                            <div class="col-md-4">
                                <div class="row">
                                    <div class="col-md-12 mb-1 mt-1">
                                        <label class="m-0">Product Type<span class="text-danger">*</span> </label>
                                        <select class="form-control" required name="category_id">
                                            <option value="" disabled selected>Select Type</option>
                                            <?php 
                                                foreach($category as $row){
                                            ?>
                                            <option <?php if($row['category_id']==$det[0]['category_id']){echo 'selected';}?> value="<?=$row['category_id']?>"><?=$row['category_name']?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label class="m-0">Unit Type<span class="text-danger">*</span> </label>
                                        <select class="form-control form-select" required name="unit_id">
                                            <?php 
                                                foreach($unit as $row){
                                            ?>
                                            <option <?php if($row['unit_tbl_id']== $det[0]['unit_id']){echo 'selected';}?> value="<?=$row['unit_tbl_id']?>"><?=$row['unit_name']?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <button class="btn btn-primary" type="submit">SAVE</button>
                            </div>
                            </div>                        
                        </div>
                    </form>
                </div>
                <!-- end card body -->
            </div>
            <!-- end card -->
        </div>
	</div>
</div>