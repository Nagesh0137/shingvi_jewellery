
    <div class="container-fluid mt-3">
            <div class="row p-3">
                
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between">
                            <div class="header-title">
                                <h4 class="card-title">Vehicle</h4>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="table-responsive">
                                <table class="table mx-0">
                <thead>
                    <tr>
                        <th>Registration</th>
                        <th>Name</th>
                        <th>Expiry&nbsp;Date</th>
                        <th>Fitness&nbsp;Upto</th>
                        <th>Insurance&nbsp;Validity</th>
                        <th>Vehicle&nbsp;Type</th>
                        <th>Capacity</th>
                        <th>Permit&nbsp;Validity</th>
                        <th>PUC&nbsp;Validity</th>
                        <th>KYC&nbsp;Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>MH 16 CM 8466</td>
                        <td>Jitendra Baghel</td>
                        <td>-</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>Truck</td>
                        <td>30 MT</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>Not Subscribed</td>
                    </tr>
                    <tr>
                        <td>MH 16 CM 8466</td>
                        <td>Jitendra Baghel</td>
                        <td>-</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>Truck</td>
                        <td>30 MT</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>Not Subscribed</td>
                    </tr>
                    <tr>
                        <td>MH 16 CM 8466</td>
                        <td>Jitendra Baghel</td>
                        <td>-</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>Truck</td>
                        <td>30 MT</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>Not Subscribed</td>
                    </tr>
                    <tr>
                        <td>MH 16 CM 8466</td>
                        <td>Jitendra Baghel</td>
                        <td>-</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>Truck</td>
                        <td>30 MT</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>Not Subscribed</td>
                    </tr>
                    <tr>
                        <td>MH 16 CM 8466</td>
                        <td>Jitendra Baghel</td>
                        <td>-</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>Truck</td>
                        <td>30 MT</td>
                        <td>N/A</td>
                        <td>N/A</td>
                        <td>Not Subscribed</td>
                    </tr>
                </tbody>
            </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
    </div>
