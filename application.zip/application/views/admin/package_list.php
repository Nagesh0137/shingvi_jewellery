<div class="container-xxl">                    
    <div class="row">
        <?php
            foreach($list as $row)
            {
                ?>
                <div class="col-md-6 col-lg-3">
                            <div class="card">
                                <div class="card-body">
                                    <div class="text-center">

                                        <h6 class="pt-3 pb-2 m-0 fs-18 fw-medium"><?=$row['package_name']?></h6>
                                        <button class="btn btn-primary btn-sm">ADD FEATURES +</button>
                                        <p class="text-muted pt-2 mb-0"><?=$row['package_description']?></p>
                                        <div class="pt-3">
                                            <h2 class="d-inline-block ">&#8377; <?=$row['package_price']?></h2>
                                            <small class="font-12 text-muted">/<?=$row['package_type']?></small>
                                        </div>
                                       <hr class="hr-dashed">
                                        <ul class="list-unstyled pricing-content text-start pt-3 border-0 mb-0">
                                            <?php foreach ($row['feature'] as  $value) {
                                               ?>
                                               <li><?=$value['features']?></li>
                                               <?php
                                            }?>
                                        </ul>                                            
                                    </div><!--end pricing Table-->           
                                        <a href="<?=base_url()?>admin/delete_package/<?=$row['package_id']?>" class="float-left" onclick="return confirm('Are You Sure You Want to Delete Package?');"><span><i class="fa text-danger fa-trash"></i></span></a>     
                                        <a href="<?=base_url()?>admin/edit_package/<?=$row['package_id']?>" class="text-primary float-end"><span><i class="fa text-info fa-pencil"></i></span></a>
                                </div><!--end card-body--> 

                            </div><!--end card--> 
                        </div>
                <?php
            }
        ?>
    </div>
</div>