<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h6 class="heading">Order List</h6>
                    <table id="datatable-buttons" class="table table-sm table-bordered dt-responsive nowrap w-100">
                        <thead>
                            <tr class="">
                                <th>Action</th>
                                <th>SN</th>
                                <th>Number</th>
                                <th>Customer name</th>
                                <th>Customer Mobile</th>
                                <th>payment_status</th>
                            </tr>
                        </thead>


                        <tbody>
                            <?php
                            $i = 0;
                            foreach ($list as $row) {
                                $i++;

                                ?>

                                <tr>
                                    <td style="width: 100px">
                                        <!-- <a href="<?= base_url() ?>admin/edit_category/<?= $row['category_tbl_id'] ?>"
                                                class="btn btn-outline-secondary btn-sm edit" title="Edit">
                                                <i class="fas fa-pencil-alt"></i>
                                            </a>
                                            <button type="submit" class="btn p-0"
                                                style="border:none;background-color: none;">
                                                <a href="javascript:void(0);"
                                                    class="btn btn-outline-info btn-sm save d-none" title="Save"
                                                    onclick="toggleEditSave(<?= $i ?>)">
                                                    <i class="fas fa-save"></i>
                                                </a>
                                            </button>
                                            <a href="<?= base_url() ?>admin/delete_category/<?= $row['category_tbl_id'] ?>"
                                                onclick="return confirm('Are You Sure You Want to Delete ??')"
                                                class="btn btn-sm btn-outline-danger" title="Delete">
                                                <i class="fa fa-trash "></i>
                                            </a> -->
                                    </td>

                                    <td>
                                        <?= $i ?>
                                    </td>
                                    <td><?= $row['numbers_tbl_id'] ?></td>
                                    <td><?= $row['customer_name'] ?></td>
                                    <td><?= $row['customer_mobile'] ?></td>
                                    <td>
                                        <?php
                                        if ($row['payment_status'] == 'Paid') {
                                            ?>
                                            <span class="badge bg-success"><?= $row['payment_status'] ?></span>
                                            <?php
                                        } else {
                                            ?>
                                            <span class="badge bg-danger"><?= $row['payment_status'] ?></span>
                                            <?php
                                        }
                                        ?>


                                </tr>
                                <?php
                            }
                            if ($i == 0) {
                                ?>
                                <tr>
                                    <td colspan="6" class="text-center p-2">
                                        <h4>No Records Found</h4>
                                    </td>
                                </tr>
                                <?php
                            }
                            ?>




                        </tbody>
                    </table>
                </div>

            </div>

        </div>
    </div>
</div>