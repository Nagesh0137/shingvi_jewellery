<!-- Custom Dashboard Styles -->
<style>
    .dashboard-card {
        border-radius: 15px;
        border: none;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        transition: all 0.3s ease;
        overflow: hidden;
    }

    .dashboard-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
    }

    .stat-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
    }

    .stat-card.success {
        background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
    }

    .stat-card.warning {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    }

    .stat-card.info {
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
    }

    .stat-icon {
        font-size: 2.5rem;
        opacity: 0.8;
    }

    .chart-container {
        background: white;
        border-radius: 15px;
        padding: 20px;
    }

    .recent-orders {
        max-height: 400px;
        overflow-y: auto;
    }

    .visitor-analytics {
        background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%);
    }

    .table-responsive {
        border-radius: 10px;
        overflow: hidden;
    }

    .badge-status {
        font-size: 0.8rem;
        padding: 0.5rem 1rem;
        border-radius: 50px;
    }

    .animate-counter {
        animation: countUp 2s ease-out;
    }

    @keyframes countUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .progress-circle {
        width: 100px;
        height: 100px;
        border-radius: 50%;
        background: conic-gradient(#667eea 0deg, #764ba2 var(--percentage), #f0f0f0 var(--percentage));
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
    }

    .progress-circle::before {
        content: '';
        width: 70%;
        height: 70%;
        background: white;
        border-radius: 50%;
        position: absolute;
    }

    .progress-text {
        z-index: 1;
        font-weight: bold;
        color: #333;
    }

    @media (max-width: 768px) {
        .stat-card h3 {
            font-size: 1.5rem;
        }

        .stat-icon {
            font-size: 2rem;
        }

        .dashboard-card .card-body {
            padding: 15px;
        }

        .chart-container {
            padding: 15px;
        }
    }

    @media (max-width: 576px) {
        .stat-card h3 {
            font-size: 1.2rem;
        }

        .stat-icon {
            font-size: 1.8rem;
        }

        .progress-circle {
            width: 80px;
            height: 80px;
        }

        .table-responsive {
            font-size: 0.9rem;
        }

        .btn-group-sm .btn {
            padding: 0.25rem 0.5rem;
            font-size: 0.8rem;
        }
    }
</style>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-flex align-items-center justify-content-between">
                <h4 class="page-title mb-0 font-size-18">Dashboard</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Admin</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistics Cards Row -->
    <div class="row">
        <!-- Total VIP Numbers Available -->
        <div class="col-xl-3 col-md-6">
            <div class="card dashboard-card stat-card">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h6 class="text-uppercase fw-medium text-white-50 mb-2">Available VIP Numbers</h6>
                            <h3 class="mb-1 animate-counter" id="availableNumbers">
                                <?= $total_available ?>
                            </h3>
                            <p class="text-white-50 mb-0">Ready for Sale</p>
                        </div>
                        <div class="flex-shrink-0">
                            <i class="mdi mdi-phone-check stat-icon"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total VIP Numbers Sold -->
        <div class="col-xl-3 col-md-6">
            <div class="card dashboard-card stat-card success">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h6 class="text-uppercase fw-medium text-white-50 mb-2">Sold VIP Numbers</h6>
                            <h3 class="mb-1 animate-counter" id="soldNumbers">
                                <?= $total_sold ?>
                            </h3>
                            <p class="text-white-50 mb-0">Total Sales</p>
                        </div>
                        <div class="flex-shrink-0">
                            <i class="mdi mdi-phone-plus stat-icon"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Today's Sales -->
        <div class="col-xl-3 col-md-6">
            <div class="card dashboard-card stat-card warning">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h6 class="text-uppercase fw-medium text-white-50 mb-2">Today's Sales</h6>
                            <h3 class="mb-1 animate-counter" id="todaySales">
                                <?= $today_sales ?>
                            </h3>
                            <p class="text-white-50 mb-0">Numbers Sold Today</p>
                        </div>
                        <div class="flex-shrink-0">
                            <i class="mdi mdi-trending-up stat-icon"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Monthly Revenue -->
        <div class="col-xl-3 col-md-6">
            <div class="card dashboard-card stat-card info">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h6 class="text-uppercase fw-medium text-white-50 mb-2">Monthly Revenue</h6>
                            <h3 class="mb-1 animate-counter" id="monthlyRevenue">
                                ₹<?= number_format($monthly_revenue, 2) ?>
                            </h3>
                            <p class="text-white-50 mb-0">This Month</p>
                        </div>
                        <div class="flex-shrink-0">
                            <i class="mdi mdi-currency-inr stat-icon"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Sales Chart -->
        <div class="col-xl-6">
            <div class="card dashboard-card ">
                <div class="card-header">
                    <h4 class="card-title mb-0" id="chartTitle">Numbers Analytics - Last 7 Days</h4>
                    <div class="btn-group btn-group-sm" role="group">
                        <button type="button" class="btn btn-outline-primary active" id="dailyChart">Daily</button>
                        <button type="button" class="btn btn-outline-primary" id="monthlyChart">Monthly</button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="chart-container">
                        <canvas id="salesChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <!-- Recent Orders -->
        <div class="col-xl-6">
            <div class="card dashboard-card">
                <div class="card-header pb-0 mb-0">
                    <h4 class="card-title mb-0 m-0 p-0 float-start">Recent Number Sales</h4>
                    <a href="<?= base_url('admin/add_numbers') ?>" class="btn btn-sm btn-outline-primary float-end">View
                        All</a>
                </div>
                <div class="card-body pt-0 mt-1">
                    <div class="table-responsive recent-orders">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>VIP Number</th>
                                    <th>Price</th>
                                    <!-- <th>Region</th> -->
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_sales as $key => $sale) {

                                    if ($key >= 4)
                                        break;
                                    ?>
                                    <tr>
                                        <td>
                                            <strong><?= $sale['mobile_number'] ?></strong>
                                        </td>
                                        <td>
                                            <span class="fw-medium">₹<?= number_format($sale['price'], 2) ?></span>
                                        </td>
                                        <!-- <td><?= $sale['port_region'] ?? 'N/A' ?></td> -->
                                        <td>
                                            <span
                                                class="badge badge-status <?= $sale['product_status'] == 'Sold' ? 'bg-danger' : 'bg-primary' ?>">
                                                <?= $sale['product_status'] ?>
                                            </span>
                                        </td>
                                        <td><?= isset($sale['sold_time']) ? date('d-M-Y', strtotime($sale['sold_time'])) : date('d-M-Y', strtotime($sale['entry_date'])) ?>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Sales Chart
        const ctx = document.getElementById('salesChart').getContext('2d');
        let salesChart;

        // Default daily data
        let dailyData = {
            labels: <?= json_encode($daily_labels) ?>,
            datasets: [{
                label: 'Numbers Sold',
                data: <?= json_encode($daily_sales) ?>,
                borderColor: 'rgba(255, 59, 15, 0.94)',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4
            }]
        };

        let monthlyData = {
            labels: <?= json_encode($monthly_labels) ?>,
            datasets: [{
                label: 'Numbers Sold',
                data: <?= json_encode($monthly_sales) ?>,
                borderColor: 'rgba(255, 59, 15, 0.94)',
                backgroundColor: 'rgba(236, 57, 16, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4
            }, {
                label: 'Numbers Inserted',
                data: <?= json_encode($monthly_sales_entry) ?>,
                borderColor: '#667eea',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4
            }]
        };

        function createChart(data) {
            if (salesChart) {
                salesChart.destroy();
            }

            salesChart = new Chart(ctx, {
                type: 'line',
                data: data,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: data.datasets.length > 1,
                            position: 'top',
                            labels: {
                                usePointStyle: true,
                                padding: 20,
                                font: {
                                    size: 12
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(0,0,0,0.1)'
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    },
                    elements: {
                        point: {
                            radius: 6,
                            hoverRadius: 8
                        }
                    }
                }
            });
        }

        // Initialize with daily data
        createChart(dailyData);

        // Chart toggle buttons
        document.getElementById('dailyChart').addEventListener('click', function () {
            this.classList.add('active');
            document.getElementById('monthlyChart').classList.remove('active');
            document.getElementById('chartTitle').textContent = 'Numbers Analytics - Last 7 Days';
            createChart(dailyData);
        });

        document.getElementById('monthlyChart').addEventListener('click', function () {
            this.classList.add('active');
            document.getElementById('dailyChart').classList.remove('active');
            document.getElementById('chartTitle').textContent = 'Numbers Analytics - Last 12 Months';
            createChart(monthlyData);
        });

        // Animate counters
        function animateCounter(element, target) {
            let current = 0;
            const increment = target / 100;
            const timer = setInterval(() => {
                current += increment;
                if (current >= target) {
                    current = target;
                    clearInterval(timer);
                }
                element.textContent = Math.floor(current);
            }, 20);
        }

        // Auto-refresh data every 30 seconds
        setInterval(function () {
            // You can add AJAX calls here to refresh the dashboard data
            console.log('Dashboard data refreshed');
        }, 30000);

        // Add loading animations
        function showLoading(elementId) {
            const element = document.getElementById(elementId);
            if (element) {
                element.innerHTML = '<i class="mdi mdi-loading mdi-spin"></i>';
            }
        }

        // Smooth scroll animations for stats cards
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-counter');
                }
            });
        }, observerOptions);

        // Observe all stat cards
        document.querySelectorAll('.stat-card').forEach(card => {
            observer.observe(card);
        });

        // Add click effects to dashboard cards
        document.querySelectorAll('.dashboard-card').forEach(card => {
            card.addEventListener('mouseenter', function () {
                this.style.transform = 'translateY(-2px)';
            });

            card.addEventListener('mouseleave', function () {
                this.style.transform = 'translateY(0)';
            });
        });
    });
</script>