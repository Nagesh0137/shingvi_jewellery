<?php
if (isset($about_det[0])) {
?>
	<div class="container bg-white p-4">
		<form action="<?= base_url() ?>admin/update_details" method="post" enctype="multipart/form-data">
			<div class="row">
				<div class="col-12">
					<h4 class="heading text-uppercase" style="font-family: arial;">Update Details</h4>
				</div>
				<hr>
			</div>
			<div class="row">
				<div class="col-md-6 mt-2">
					<input type="hidden" name="about_tbl_id" value="<?= $about_det[0]['about_tbl_id'] ?>">
					<input type="hidden" name="about_image1" value="<?= $about_det[0]['about_image'] ?>" class="form-control">
					<label class="font-weight-bold text-uppercase">Title</label>&nbsp;<span class="text-danger">*</span>
					<input type="text" name="title" multiple class="form-control" value="<?= $about_det[0]['title'] ?>">
				</div>
				<div class="col-md-6 mt-2">
					<label class="font-weight-bold text-uppercase">Image</label>&nbsp;<span class="text-danger">*</span>
					<input type="file" name="about_image" class="form-control" value="<?= $about_det[0]['about_image'] ?>">
				</div>

				<div class="col-md-10 mt-4">
					<label class="font-weight-bold text-uppercase">Description</label>&nbsp;<span class="text-danger">*</span>
					<textarea name="description" rows="6" required="" class=" form-control" data-sample-short><?= $about_det[0]['description'] ?></textarea>
				</div>
				<div class="col-md-2 mt-4">
					<label>old image</label><br>
					<img src="<?= base_url() ?>uploads/<?= $about_det[0]['about_image'] ?>" width="150px" height="150px">
				</div>
				<div class="col-md-12 text-center">
					<button class="btn btn-success mt-4 btn-ml text-uppercase"><b>Update</b></button>
				</div>
			</div>
		</form>
	</div>
<?php
} else {
?>
	<div class="container bg-white p-4">
		<form action="<?= base_url() ?>admin/add_about_page" method="post" enctype="multipart/form-data">
			<div class="row">
				<div class="col-12">
					<h3 class="heading text-uppercase">About Details</h3>
				</div>
				<hr>
			</div>

			<div class="row">
				<div class="col-md-6 mt-2">
					<label class="font-weight-bold text-uppercase">Title</label>&nbsp;<span class="text-danger">*</span>
					<input type="text" name="title" multiple class="form-control" placeholder="Enter Title">
				</div>
				<div class="col-md-6 mt-2">
					<label class="font-weight-bold text-uppercase">Image</label>&nbsp;<span class="text-danger">*</span>
					<input type="file" name="about_image" class="form-control" placeholder="Enter Title">
				</div>

				<div class="col-md-12 mt-2">
					<label class="font-weight-bold text-uppercase">Description</label>&nbsp;<span class="text-danger">*</span>
					<textarea name="description" rows="5" required="" class=" form-control"></textarea>
				</div>
				<div class="col-md-12 text-center">
					<button class="btn btn-success mt-4 btn-ml text-uppercase"><b>Save</b></button>
				</div>
			</div>


		</form>
		<div class="row mt-2">
			<div class="col-md-12">
				<div class="col-md-12">
					<h4 class="heading "><b>About List</b></h4>
				</div>
				<div class="col-md-12">
					<table class="table table-bordered  table-hover">
						<tr>
							<th>Action</th>
							<th>SN</th>
							<th>Title</th>
							<th>Image</th>
							<th>Description</th>
						</tr>
						<?php
						$i = 0;
						foreach ($about_company as $row) {
						?>
							<tr>
								<td style="font-size:20px; text-align: center;"><a href="<?= base_url() ?>admin/edit_company/<?= $row['about_tbl_id'] ?>" class="btn btn-outline-secondary btn-sm edit" title="Edit"><i class="fas fa-pencil-alt"></i></a></td>
								<td><?= ++$i; ?></td>
								<td><?= $row['title'] ?></td>
								<td>
									<img src="<?= base_url() ?>uploads/<?= $row['about_image'] ?>" width="100px" height="100px" />
								</td>
								<td><?= $row['description'] ?></td>

							</tr>
						<?php
						}
						?>
					</table>
				</div>
			</div>
		</div>
	</div>

<?php
}
?>