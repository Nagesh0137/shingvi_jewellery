<?php if (isset($det)) { ?>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Edit About Us</h5>

                <form action="<?= base_url() ?>admin/update_about_us" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="about_tbl_id" value="<?= $det['about_tbl_id'] ?>">
                    <input type="hidden" name="old_about_img" value="<?= $det['about_img'] ?>">
                    <div class="row">
                        <div class="form-floating col-md-6 mb-3">
                            <input type="file" value="<?= $det['about_img'] ?>" name="about_img" class="form-control" id="floatingnameInput" placeholder="Select About Image">
                            <label for="floatingnameInput">About Image</label>
                            <img src="<?= base_url() ?>uploads/<?= $det['about_img'] ?>" class="img-fluid mt-2" height="50px" width="50px" alt="About Image">
                        </div>
                        <div class="form-floating col-md-6 mb-3">
                            <input type="text" value="<?= $det['about_title'] ?>" name="about_title" class="form-control" id="floatingnameInput" placeholder="Enter About Title">
                            <label for="floatingnameInput">About Title</label>
                        </div>
                        <div class="form-floating col-md-12 mb-3">
                            <textarea name="about_desc" class="form-control" id="about_desc" style="height: 150px;"><?= $det['about_desc'] ?></textarea>
                            <label for="about_desc">About Description</label>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary w-md">UPDATE</button>
                            <a href="<?= base_url() ?>admin/about_us" class="btn btn-secondary w-md">CANCEL</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php } else { ?>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Add About Us</h5>

                <form action="<?= base_url() ?>admin/save_about_us" method="post" enctype="multipart/form-data">
                    <div class="row">
                        <div class="form-floating col-md-6 mb-3">
                            <input type="file" name="about_img" class="form-control" id="floatingnameInput" placeholder="Select About Image" required>
                            <label for="floatingnameInput">About Image <span class=" text-danger">*</span></label>
                        </div>
                        <div class="form-floating col-md-6 mb-3">
                            <input type="text" name="about_title" class="form-control" id="floatingnameInput" placeholder="Enter About Title" required>
                            <label for="floatingnameInput">About Title <span class=" text-danger">*</span></label>
                        </div>
                        <div class="form-floating col-md-12 mb-3">
                            <textarea name="about_desc" class="form-control" id="about_desc" style="height: 80px;" placeholder="Enter About Description"></textarea>
                            <label for="about_desc">About Description <span class=" text-danger">*</span></label>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary w-md">SAVE</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">About Us List</h4>
                <table id="datatable-buttons" class="table table-sm table-bordered dt-responsive nowrap w-100">
                    <thead>
                        <tr>
                            <th>Action</th>
                            <th>SN</th>
                            <th>About Image</th>
                            <th>About Title</th>
                            <th>Description</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                        $i = 0;
                        foreach ($list as $row) {
                            $i++;
                        ?>
                            <tr id="myEdit<?= $i ?>">
                                <form action="<?= base_url() ?>admin/update_about_us" method="post" enctype="multipart/form-data">
                                    <td style="width: 120px">
                                        <a href="<?= base_url() ?>admin/edit_about_us/<?= $row['about_tbl_id'] ?>" class="btn btn-outline-secondary btn-sm edit" title="Edit">
                                            <i class="fas fa-pencil-alt"></i>
                                        </a>
                                        <button type="submit" class="btn btn-outline-info btn-sm save d-none" title="Save" id="save_btn<?= $i ?>">
                                            <i class="fas fa-save"></i>
                                        </button>
                                        <a href="<?= base_url() ?>admin/delete_about_us/<?= $row['about_tbl_id'] ?>" onclick="return confirm('Are You Sure You Want to Delete ??')" class="btn btn-sm btn-outline-danger" title="Delete">
                                            <i class="fa fa-trash "></i>
                                        </a>
                                    </td>
                                    <td>
                                        <?= $i ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($row['about_img'])): ?>
                                            <img src="<?= base_url() ?>uploads/<?= $row['about_img'] ?>" alt="About Image" style="width: 80px; height: 50px; object-fit: cover;" class="img-thumbnail">
                                        <?php else: ?>
                                            <span class="text-muted">No Image</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span id="title_span<?= $i ?>"><?= $row['about_title'] ?></span>
                                        <input type="hidden" name="about_id" value="<?= $row['about_tbl_id'] ?>">
                                        <input type="text" class="form-control d-none" required value="<?= $row['about_title'] ?>" name="about_title" id="about_title<?= $i ?>">
                                    </td>
                                    <td>
                                        <span id="desc_span<?= $i ?>"><?= substr($row['about_desc'], 0, 50) ?>...</span>
                                        <textarea class="form-control d-none" name="about_desc" id="about_desc<?= $i ?>"><?= $row['about_desc'] ?></textarea>
                                    </td>

                                </form>
                            </tr>
                        <?php
                        }
                        if ($i == 0) {
                        ?>
                            <tr>
                                <td colspan="5" class="text-center p-2">
                                    <h4>No Records Found</h4>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>

                    </tbody>
                </table>
            </div>

        </div>

    </div>
<?php } ?>

<script>
    function toggleEditSave(index) {
        // Toggle visibility of spans and inputs
        const titleSpan = document.getElementById('title_span' + index);
        const titleInput = document.getElementById('about_title' + index);
        const descSpan = document.getElementById('desc_span' + index);
        const descInput = document.getElementById('about_desc' + index);
        const editBtn = document.querySelector('#myEdit' + index + ' .edit');
        const saveBtn = document.getElementById('save_btn' + index);

        if (titleInput.classList.contains('d-none')) {
            // Switch to edit mode
            titleSpan.classList.add('d-none');
            titleInput.classList.remove('d-none');
            descSpan.classList.add('d-none');
            descInput.classList.remove('d-none');
            editBtn.classList.add('d-none');
            saveBtn.classList.remove('d-none');
        } else {
            // Switch to view mode
            titleSpan.classList.remove('d-none');
            titleInput.classList.add('d-none');
            descSpan.classList.remove('d-none');
            descInput.classList.add('d-none');
            editBtn.classList.remove('d-none');
            saveBtn.classList.add('d-none');
        }
    }
</script>