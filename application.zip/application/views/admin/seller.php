<!-- <div class="content-inner " id="page_layout"> -->
   <div class="container-fluid">
        <div class="row p-3">
            <div class="col-lg-12">
         <div class="row">
            <div class="col-sm-4 col-md-3">
               <div class="card card-block card-stretch card-height">
                  
                   <div class="card-body">
                     <div class="d-flex align-items-center justify-content-between pb-3">
                        <div class="d-flex align-items-center">
                           <img class="img-fluid rounded-circle avatar-30" src="<?=base_url()?>uploads/219983.png" alt="" loading="lazy">
                           <div class="media-body ms-2">
                              <p class="mb-0 line-height"></p>
                              <h6><a href="#">Row</a></h6>
                           </div>
                        </div>
                        <span class="text-warning d-block line-height">
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                        </span>      
                     </div>
                     <div class="d-flex align-items-center justify-content-between pb-3">
                        <div class="d-flex align-items-center">
                           <div class="media-body ms-2">
                              
                           </div>
                        </div>
                          <div class="media-group text-right">
                           <a href="#" class="iq-media "><i style="font-size:19px;" class="avatar-40  fa fa-flask rounded-circle" data-toggle="tooltip" data-placement="bottom" title="Quality Profile"></i></a>
                           <a href="#" class="iq-media"><i style="font-size:19px;" class="avatar-40 fa fa-user-circle rounded-circle"></i></a>
                           </div>    
                     </div>
                     
                     
                     
                  </div>
               </div>
            </div>
            <div class="col-sm-4 col-md-3">
               <div class="card card-block card-stretch card-height">
                  
                   <div class="card-body">
                     <div class="d-flex align-items-center justify-content-between pb-3">
                        <div class="d-flex align-items-center">
                           <img class="img-fluid rounded-circle avatar-30" src="<?=base_url()?>uploads/219983.png" alt="" loading="lazy">
                           <div class="media-body ms-2">
                              <p class="mb-0 line-height"></p>
                              <h6><a href="#">Row</a></h6>
                           </div>
                        </div>
                        <span class="text-warning d-block line-height">
                         <i class="material-symbols-outlined md-18">star</i>
                         <i class="material-symbols-outlined md-18">star</i>
                         <i class="material-symbols-outlined md-18">star</i>
                         <i class="material-symbols-outlined md-18">star</i>
                         <i class="material-symbols-outlined md-18">star</i>
                        </span>      
                     </div>
                     <div class="d-flex align-items-center justify-content-between pb-3">
                        <div class="d-flex align-items-center">
                           <div class="media-body ms-2">
                              
                           </div>
                        </div>
                          <div class="media-group text-right">
                           <a href="#" class="iq-media"><i style="font-size:19px;" class="avatar-40  fa fa-flask rounded-circle" data-toggle="tooltip" data-placement="bottom" title="Quality Profile"></i></a>
                           <a href="#" class="iq-media"><i style="font-size:19px;" class="avatar-40 fa fa-user-circle rounded-circle"></i></a>
                           </div>    
                     </div>
                     
                     
                     
                  </div>
               </div>
            </div>
            <div class="col-sm-4 col-md-3">
               <div class="card card-block card-stretch card-height">
                  
                   <div class="card-body">
                     <div class="d-flex align-items-center justify-content-between pb-3">
                        <div class="d-flex align-items-center">
                           <img class="img-fluid rounded-circle avatar-30" src="<?=base_url()?>uploads/219983.png" alt="" loading="lazy">
                           <div class="media-body ms-2">
                              <p class="mb-0 line-height"></p>
                              <h6><a href="#">Row</a></h6>
                           </div>
                        </div>
                        <span class="text-warning d-block line-height">
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                        </span>      
                     </div>
                     <div class="d-flex align-items-center justify-content-between pb-3">
                        <div class="d-flex align-items-center">
                           <div class="media-body ms-2">
                              
                           </div>
                        </div>
                          <div class="media-group text-right">
                           <a href="#" class="iq-media "><i style="font-size:19px;" class="avatar-40  fa fa-flask rounded-circle" data-toggle="tooltip" data-placement="bottom" title="Quality Profile"></i></a>
                           <a href="#" class="iq-media"><i style="font-size:19px;" class="avatar-40 fa fa-user-circle rounded-circle"></i></a>
                           </div>    
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-sm-4 col-md-3">
               <div class="card card-block card-stretch card-height">
                  
                   <div class="card-body">
                     <div class="d-flex align-items-center justify-content-between pb-3">
                        <div class="d-flex align-items-center">
                           <img class="img-fluid rounded-circle avatar-30" src="<?=base_url()?>uploads/219983.png" alt="" loading="lazy">
                           <div class="media-body ms-2">
                              <p class="mb-0 line-height"></p>
                              <h6><a href="#">Row</a></h6>
                           </div>
                        </div>
                        <span class="text-warning d-block line-height">
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                        </span>      
                     </div>
                     <div class="d-flex align-items-center justify-content-between pb-3">
                        <div class="d-flex align-items-center">
                           <div class="media-body ms-2">
                              
                           </div>
                        </div>
                          <div class="media-group text-right">
                           <a href="#" class="iq-media "><i style="font-size:19px;" class="avatar-40  fa fa-flask rounded-circle" data-toggle="tooltip" data-placement="bottom" title="Quality Profile"></i></a>
                           <a href="#" class="iq-media"><i style="font-size:19px;" class="avatar-40 fa fa-user-circle rounded-circle"></i></a>
                           </div>    
                     </div>
                     
                     
                     
                  </div>
               </div>
            </div>
            <div class="col-sm-4 col-md-3">
               <div class="card card-block card-stretch card-height">
                  
                   <div class="card-body">
                     <div class="d-flex align-items-center justify-content-between pb-3">
                        <div class="d-flex align-items-center">
                           <img class="img-fluid rounded-circle avatar-30" src="<?=base_url()?>uploads/219983.png" alt="" loading="lazy">
                           <div class="media-body ms-2">
                              <p class="mb-0 line-height"></p>
                              <h6><a href="#">Row</a></h6>
                           </div>
                        </div>
                        <span class="text-warning d-block line-height">
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                        </span>      
                     </div>
                     <div class="d-flex align-items-center justify-content-between pb-3">
                        <div class="d-flex align-items-center">
                           <div class="media-body ms-2">
                              
                           </div>
                        </div>
                          <div class="media-group text-right">
                           <a href="#" class="iq-media "><i style="font-size:19px;" class="avatar-40  fa fa-flask rounded-circle" data-toggle="tooltip" data-placement="bottom" title="Quality Profile"></i></a>
                           <a href="#" class="iq-media"><i style="font-size:19px;" class="avatar-40 fa fa-user-circle rounded-circle"></i></a>
                           </div>    
                     </div>
                     
                     
                     
                  </div>
               </div>
            </div>

            <div class="col-sm-4 col-md-3">
               <div class="card card-block card-stretch card-height">
                  
                   <div class="card-body">
                     <div class="d-flex align-items-center justify-content-between pb-3">
                        <div class="d-flex align-items-center">
                           <img class="img-fluid rounded-circle avatar-30" src="<?=base_url()?>uploads/219983.png" alt="" loading="lazy">
                           <div class="media-body ms-2">
                              <p class="mb-0 line-height"></p>
                              <h6><a href="#">Row</a></h6>
                           </div>
                        </div>
                        <span class="text-warning d-block line-height">
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                     <i class="material-symbols-outlined md-18">star</i>
                        </span>      
                     </div>
                     <div class="d-flex align-items-center justify-content-between pb-3">
                        <div class="d-flex align-items-center">
                           <div class="media-body ms-2">
                              
                           </div>
                        </div>
                          <div class="media-group text-right">
                           <a href="#" class="iq-media "><i style="font-size:19px;" class="avatar-40  fa fa-flask rounded-circle" data-toggle="tooltip" data-placement="bottom" title="Quality Profile"></i></a>
                           <a href="#" class="iq-media"><i style="font-size:19px;" class="avatar-40 fa fa-user-circle rounded-circle"></i></a>
                           </div>    
                     </div>
                     
                     
                     
                  </div>
               </div>
            </div>
            
                        </div>
            
            
            
            
            
         </div>
      </div>
        </div>

</div>