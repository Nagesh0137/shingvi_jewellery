<div class="container-fluid p-3">
         <div class="row p-3">
            <div class="col-sm-12 mt-3">
               <h1 class="text-center bg-white p-2 mb-3 text-primary"><b>Introducing new Subscription Plans</b></h1>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12">
               <div class="card m-2">
                  <div class="card-header p-2 text-center" >
                      <h3>Prepaid Pack</h3>
                  </div>
                  <div class="card-body border text-center rounded">
                     <h2 class="text-uppercase">Basic</h2>
                     <div class="d-flex align-items-center justify-content-center">
                        <h1 class="mb-2" style="font-size:35px;">&#8377;10000</h1>                         
                        <small class=" text-muted">/ Month</small>
                     </div> 
                     <ul class="list-unstyled line-height-4 mb-0">
                        <li>Discover Buyers</li>
                        <li>See Plan Details</li>
                     </ul>
                     <a href="#" class="btn btn-primary mt-5 d-block">Buy Now</a>
                  </div>
               </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12">
               <div class="card m-2">
                <div class="card-header p-2 text-center" >
                      <h3>Prepaid Pack</h3>
                  </div>
                  <div class="card-body border text-center rounded">
                     <h2 class="text-uppercase">GOLD</h2>
                     <div class="d-flex align-items-center justify-content-center">
                        <h1 class="mb-2" style="font-size:35px;">&#8377;25000</h1>                         
                        <small class=" text-muted">/ Month</small>
                     </div> 
                     <ul class="list-unstyled line-height-4 mb-0">
                        <li>Discover Buyers</li>
                        <li>See Plan Details</li>
                     </ul>
                     <a href="#" class="btn btn-primary mt-5 d-block">Buy Now</a>
                  </div>
               </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12">
               <div class="card m-2">
                <div class="card-header p-2 text-center" >
                      <h3>Prepaid Pack</h3>
                  </div>
                  <div class="card-body border text-center rounded">
                     <h2 class="text-uppercase">SILVER</h2>
                     <div class="d-flex align-items-center justify-content-center">
                        <h1 class="mb-2" style="font-size:35px;">&#8377;17000</h1>                         
                        <small class=" text-muted">/ Month</small>
                     </div> 
                     <ul class="list-unstyled line-height-4 mb-0">
                        <li>Discover Buyers</li>
                        <li>See Plan Details</li>
                     </ul>
                     <a href="#" class="btn btn-primary mt-5 d-block">Buy Now</a>
                  </div>
               </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12">
               <div class="card m-2">
                <div class="card-header p-2 text-center" >
                      <h3>Premium Pack</h3>
                  </div>
                  <div class="card-body border text-center rounded">
                     <h2 class="text-uppercase">Premium</h2>
                     <div class="d-flex align-items-center justify-content-center">
                        <h1 class="mb-2" style="font-size:35px;">&#8377;20000</h1>                         
                        <small class=" text-muted">/ Month</small>
                     </div> 
                     <ul class="list-unstyled line-height-4 mb-0">
                        <li>Discover Buyers</li>
                        <li>See Plan Details</li>
                     </ul>
                     <a href="#" class="btn btn-primary mt-5 d-block">Buy Now</a>
                  </div>
               </div>
            </div>
            
            
            
            
            
            
            
            
         </div>
      </div>