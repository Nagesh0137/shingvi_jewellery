<?php if (isset($det)) { ?>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <h5 class="heading">Add Banner</h5>

                <form action="<?= base_url() ?>admin/update_banner" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="banner_tbl_id" value="<?= $det['banner_tbl_id'] ?>">
                    <input type="hidden" name="old_banner_img" value="<?= $det['banner_img'] ?>">
                    <div class="row">
                        <div class="form-floating col-md-6 mb-3">
                            <input type="file" value="<?= $det['banner_img'] ?>" name="banner_img" class="form-control" id="floatingnameInput" placeholder="e.g. Labour,Supervisor">
                            <label for="floatingnameInput">Banner Image</label>
                            <img src="<?= base_url() ?>uploads/<?= $det['banner_img'] ?>" class=" img-fluid" height="50px" width="50px" alt="">
                        </div>
                        <div class="form-floating col-md-6 mb-3">
                            <input type="text" value="<?= $det['banner_title'] ?>" name="banner_title" class="form-control" id="floatingnameInput" placeholder="e.g. Labour,Supervisor">
                            <label for="floatingnameInput">Banner Title</label>
                        </div>
                        <div class="form-floating col-md-12 mb-3">
                            <textarea value="" name="banner_desc" class=" form-control" id=""><?= $det['banner_desc'] ?></textarea>
                            <label for="floatingnameInput">Description</label>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary w-md">SAVE</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php } else { ?>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <h5 class="heading">Add Banner</h5>

                <form action="<?= base_url() ?>admin/save_banner" method="post" enctype="multipart/form-data">
                    <div class="row">
                        <div class="form-floating col-md-6 mb-3">
                            <input type="file" name="banner_img" class="form-control" id="floatingnameInput" placeholder="e.g. Labour,Supervisor" required>
                            <label for="floatingnameInput">Banner Image <span class=" text-danger">*</span></label>
                        </div>
                        <div class="form-floating col-md-6 mb-3">
                            <input type="text" name="banner_title" class="form-control" id="floatingnameInput" placeholder="e.g. Labour,Supervisor" required>
                            <label for="floatingnameInput">Banner Title <span class=" text-danger">*</span></label>
                        </div>
                        <div class="form-floating col-md-12 mb-3">
                            <textarea name="banner_desc" class=" form-control" id=""></textarea>
                            <label for="floatingnameInput">Description <span class=" text-danger">*</span></label>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary w-md">SAVE</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <h4 class="heading">Banner List</h4>
                <table id="datatable-buttons" class="table table-sm table-bordered dt-responsive nowrap w-100">
                    <thead>
                        <tr>
                            <th>Action</th>
                            <th>SN</th>
                            <th>Banner Image</th>
                            <th>Banner Title</th>
                            <th>Description</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                        $i = 0;
                        foreach ($list as $row) {
                            $i++;
                        ?>
                            <tr id="myEdit<?= $i ?>">
                                <form action="<?= base_url() ?>admin/update_banner" method="post" enctype="multipart/form-data">
                                    <td style="width: 120px">
                                        <a href="<?= base_url() ?>admin/edit_banner/<?= $row['banner_tbl_id'] ?>" class="btn btn-outline-secondary btn-sm edit" title="Edit">
                                            <i class="fas fa-pencil-alt"></i>
                                        </a>
                                        <button type="submit" class="btn btn-outline-info btn-sm save d-none" title="Save" id="save_btn<?= $i ?>">
                                            <i class="fas fa-save"></i>
                                        </button>
                                        <a href="<?= base_url() ?>admin/delete_banner/<?= $row['banner_tbl_id'] ?>" onclick="return confirm('Are You Sure You Want to Delete ??')" class="btn btn-sm btn-outline-danger" title="Delete">
                                            <i class="fa fa-trash "></i>
                                        </a>
                                    </td>
                                    <td>
                                        <?= $i ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($row['banner_img'])): ?>
                                            <img src="<?= base_url() ?>uploads/<?= $row['banner_img'] ?>" alt="Banner Image" style="width: 80px; height: 50px; object-fit: cover;" class="img-thumbnail">
                                        <?php else: ?>
                                            <span class="text-muted">No Image</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span id="title_span<?= $i ?>"><?= $row['banner_title'] ?></span>
                                        <input type="hidden" name="banner_id" value="<?= $row['banner_tbl_id'] ?>">
                                        <input type="text" class="form-control d-none" required value="<?= $row['banner_title'] ?>" name="banner_title" id="banner_title<?= $i ?>">
                                    </td>
                                    <td>
                                        <span id="desc_span<?= $i ?>"><?= substr($row['banner_desc'], 0, 50) ?>...</span>
                                        <textarea class="form-control d-none" name="banner_desc" id="banner_desc<?= $i ?>"><?= $row['banner_desc'] ?></textarea>
                                    </td>

                                </form>
                            </tr>
                        <?php
                        }
                        if ($i == 0) {
                        ?>
                            <tr>
                                <td colspan="5" class="text-center p-2">
                                    <h4>No Records Found</h4>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>

                    </tbody>
                </table>
            </div>

        </div>

    </div>
<?php } ?>