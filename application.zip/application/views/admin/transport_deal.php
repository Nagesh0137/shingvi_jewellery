
    <div class="container-fluid mt-3">
            <div class="row p-3">
                
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between">
                            <div class="header-title">
                                <h4 class="card-title">Transport Deals</h4>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="table-responsive">
                                <table id="datatable" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th>Deal id</th>
                                            <th>Rental id</th>
                                            <th>Deal Name</th>
                                            <th>Transport Provider</th>
                                            <th>Contract Type</th>
                                            <th>Vehicle</th>
                                            <th>No Of Vehicles</th>
                                            <th>Hire Dates</th>
                                            <th>Rates</th>
                                            <th>From Location</th>
                                            <th>To Location</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><input type="checkbox" name="" id=""></td>
                                            <td>645482</td>
                                            <td>4391</td>
                                            <td><i class="fa-solid fa-truck text-primary"></i></td>
                                            <td>86422</td>
                                            <td>30-Jun-2024</td>
                                            <td>Ahmednagar, Ahmednagar District Maharashtra</td>
                                            <td>Virtual White</td>
                                            <td>Maharashtra</td>
                                            <td>BioFuelCircle Buyer</td>
                                        </tr>
                                        <tr>
                                            <td><input type="checkbox" name="" id=""></td>
                                            <td>645482</td>
                                            <td>4391</td>
                                            <td><i class="fa-solid fa-truck text-primary"></i></td>
                                            <td>86422</td>
                                            <td>30-Jun-2024</td>
                                            <td>Ahmednagar, Ahmednagar District Maharashtra</td>
                                            <td>Virtual White</td>
                                            <td>Maharashtra</td>
                                            <td>BioFuelCircle Buyer</td>
                                        </tr>
                                        <tr>
                                            <td><input type="checkbox" name="" id=""></td>
                                            <td>645482</td>
                                            <td>4391</td>
                                            <td><i class="fa-solid fa-truck text-primary"></i></td>
                                            <td>86422</td>
                                            <td>30-Jun-2024</td>
                                            <td>Ahmednagar, Ahmednagar District Maharashtra</td>
                                            <td>Virtual White</td>
                                            <td>Maharashtra</td>
                                            <td>BioFuelCircle Buyer</td>
                                        </tr>
                                        <tr>
                                            <td><input type="checkbox" name="" id=""></td>
                                            <td>645482</td>
                                            <td>4391</td>
                                            <td><i class="fa-solid fa-truck text-primary"></i></td>
                                            <td>86422</td>
                                            <td>30-Jun-2024</td>
                                            <td>Ahmednagar, Ahmednagar District Maharashtra</td>
                                            <td>Virtual White</td>
                                            <td>Maharashtra</td>
                                            <td>BioFuelCircle Buyer</td>
                                        </tr>
                                        <tr>
                                            <td><input type="checkbox" name="" id=""></td>
                                            <td>645482</td>
                                            <td>4391</td>
                                            <td><i class="fa-solid fa-truck text-primary"></i></td>
                                            <td>86422</td>
                                            <td>30-Jun-2024</td>
                                            <td>Ahmednagar, Ahmednagar District Maharashtra</td>
                                            <td>Virtual White</td>
                                            <td>Maharashtra</td>
                                            <td>BioFuelCircle Buyer</td>
                                        </tr>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th></th>
                                            <th>Deal id</th>
                                            <th>Rental id</th>
                                            <th>Deal Name</th>
                                            <th>Transport Provider</th>
                                            <th>Contract Type</th>
                                            <th>Vehicle</th>
                                            <th>No Of Vehicles</th>
                                            <th>Hire Dates</th>
                                            <th>Rates</th>
                                            <th>From Location</th>
                                            <th>To Location</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
    </div>
