<div class="container-xxl">                    
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col">                      
                            <h4 class="card-title">Add Package Form</h4>                      
                        </div><!--end col-->
                        <div class="col text-end">
                            <a href="<?=base_url()?>admin/package_list"><button class="btn btn-primary btn-sm">Package List <i class="fa fa-list"></i></button></a>
                        </div>
                    </div><!--end row-->                                  
                </div><!--end card-header-->
                <div class="card-body pt-0">
                    <form id="form-validation-2" action="<?=base_url()?>admin/add_package" method="POST" class="form">
                        <div class="row">
                            <!-- Package Name -->
                            <div class="col-md-4 form-group mb-2">
                                <label for="package_name" class="form-label">Package Name</label>
                                <input class="form-control" type="text" id="package_name" name="package_name" placeholder="Enter Package Name" required>
                                <small>Error Message</small>
                            </div>

                            <!-- Package Type -->
                            <div class="col-md-4 form-group mb-2">
                                <label for="package_type" class="form-label">Package Type</label>
                                <select class="form-control" id="package_type" name="package_type" required>
                                    <option value="">Select Package Type</option>
                                    <option value="monthly">Monthly</option>
                                    <option value="annually">Annually</option>
                                </select>
                                <small>Error Message</small>
                            </div>

                            <!-- Package Price -->
                            <div class="col-md-4 form-group mb-2">
                                <label for="package_price" class="form-label">Package Price</label>
                                <input class="form-control" type="number" id="package_price" name="package_price" placeholder="Enter Package Price" required>
                                <small>Error Message</small>
                            </div>

                            <!-- Free Trial Days -->
                            <div class="col-md-4 form-group mb-2">
                                <label for="free_trial_days" class="form-label">Free Trial Days</label>
                                <input class="form-control" type="number" id="free_trial_days" name="free_trial_days" placeholder="Enter Free Trial Days" required>
                                <small>Error Message</small>
                            </div>

                            <!-- Features Included -->
                            <div class="col-md-4 form-group mb-2">
                                <label for="features" class="form-label">Features Included</label>
                                <select class="form-control" id="features" name="features[]" multiple required>
                                    <option value="basic">Basic Features</option>
                                    <option value="premium">Premium Features</option>
                                    <option value="analytics">Advanced Analytics</option>
                                    <option value="reports">Custom Reports</option>
                                    <option value="support">Priority Support</option>
                                </select>
                                <small>Error Message</small>
                            </div>

                            <!-- Package Description -->
                            <div class="col-md-4 form-group mb-2">
                                <label for="package_description" class="form-label">Package Description</label>
                                <textarea class="form-control" id="package_description" name="package_description" placeholder="Describe the package" required></textarea>
                                <small>Error Message</small>
                            </div>

                            <!-- Activation Status -->
                            <div class="col-md-2 form-group mb-2">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="activation_status" value="yes" name="activation_status">
                                    <label class="form-check-label" for="activation_status">
                                        Activate Package
                                    </label>
                                </div>
                            </div>
                            <!-- Discount Option -->
                            <div class="col-md-2 form-group mb-2">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="allow_discount" name="allow_discount">
                                    <label class="form-check-label" for="allow_discount">
                                        Allow Discounts
                                    </label>
                                </div>
                            </div>

                            <!-- Discount Amount (Initially hidden) -->
                            <div class="col-md-4 form-group mb-2" id="discount_amount_field" style="display: none;">
                                <label for="discount_amount" class="form-label">Discount Amount</label>
                                <input class="form-control" type="number" id="discount_amount" name="discount_amount" placeholder="Enter Discount Amount">
                                <small>Error Message</small>
                            </div>

                            <!-- Package Validity -->
                            <div class="col-md-4 form-group mb-2">
                                <label for="validity_date" class="form-label">Package Validity</label>
                                <input class="form-control" type="date" id="validity_date" name="validity_date" required>
                                <small>Error Message</small>
                            </div>


                            <!-- Access Limitations -->
                            <div class="col-md-4 form-group mb-2">
                                <label for="access_limit" class="form-label">Access Limitations</label>
                                <input class="form-control" type="number" id="access_limit" name="access_limit" placeholder="Maximum number of schools allowed" required>
                                <small>Error Message</small>
                            </div>


                            <button type="submit" class="btn btn-primary">Submit Package</button>
                        </div>
                    </form><!--end form-->            
                </div><!--end card-body--> 
            </div>
        </div> <!--end col-->                                                                                
    </div><!--end row-->
</div>



<script>
    // jQuery for handling discount field visibility
$(document).ready(function() {
    $('#allow_discount').change(function() {
        if ($(this).is(':checked')) {
            // Show the discount field and add the 'required' attribute
            $('#discount_amount_field').show();
            $('#discount_amount').attr('required', true);
        } else {
            // Hide the discount field and remove the 'required' attribute
            $('#discount_amount_field').hide();
            $('#discount_amount').removeAttr('required');
        }
    });
});

</script>
