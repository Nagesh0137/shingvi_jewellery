<!-- Numbers List -->
<div class="col-lg-12">
    <div class="card">
        <div class="card-body">
            <h5 class=" heading">Numbers List</h5>


            <?php
            $show = "";
            extract($_GET);
            ?>

            <!-- Search and Filter Form -->
            <div class="row mt-3 mb-1">
                <div class="col-md-12 mb-1">
                    <form action="<?= base_url() ?>admin/numbers_list" id="search_form">
                        <div class="row g-md-0 g-1">
                            <div class="col-md-2">
                                <input type="text" name="q" id="search_inp" placeholder="Search by..."
                                    value="<?= (isset($_GET['q'])) ? $_GET['q'] : '' ?>" class="form-control">
                            </div>
                            <div class="col-md-2">
                                <select name="category" class="form-control">
                                    <option value="">All Categories</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?= $category['category_tbl_id'] ?>" <?= (isset($_GET['category']) && $_GET['category'] == $category['category_tbl_id']) ? 'selected' : '' ?>>
                                            <?= $category['category_name'] ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <select name="status" class="form-control">
                                    <option value="">All Status</option>
                                    <option value="Available" <?= (isset($_GET['status']) && $_GET['status'] == 'Available') ? 'selected' : '' ?>>Available</option>
                                    <option value="Sold" <?= (isset($_GET['status']) && $_GET['status'] == 'Sold') ? 'selected' : '' ?>>Sold</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <input type="date" name="form"
                                    value="<?= (isset($_GET['form'])) ? $_GET['form'] : '' ?>" class="form-control"
                                    placeholder="From Date">
                            </div>
                            <div class="col-md-2">
                                <input type="date" name="to" value="<?= (isset($_GET['to'])) ? $_GET['to'] : '' ?>"
                                    class="form-control" placeholder="To Date">
                            </div>
                            <div class="col-md-2">
                                <button class="btn btn-primary btn-sm" style="border-radius: 0px;"
                                    onclick="search_form.submit();"><i class="fa fa-search"></i> Search</button>
                                <a class="btn btn-info btn-sm text-center" style="border-radius: 0px;"
                                    href="<?= base_url() ?>admin/download_number_list"><i class="fa fa-file-csv"></i>
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>


        </div>

        <div class="col-md-12 mb-2">
            <div class="float-end">
                <button class="btn btn-danger btn-sm" onclick="markSelectedAsSold()">Mark Selected as
                    Sold</button>
                <button class="btn btn-success btn-sm" onclick="markSelectedAsAvailable()">Mark Selected as
                    Available</button>
            </div>
        </div>
        <div class="table-responsive px-2">

            <table class="table table-sm table-bordered table-striped w-100">
                <thead class="table-info">
                    <tr>
                        <th><input type="checkbox" id="select_all" onchange="toggleSelectAll()"></th>
                        <th>SN</th>
                        <th>Mobile Number</th>
                        <th>Sale Price</th>
                        <th>Original Price</th>
                        <th>Category</th>
                        <th>Port Region</th>
                        <th>Filter</th>
                        <th>Status</th>
                        <th>Entry Date</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                    $i = $start;
                    if (isset($list) && !empty($list)) {
                        foreach ($list as $row) {
                            $category_name = '';
                            foreach ($categories as $cat) {
                                if ($cat['category_tbl_id'] == $row['category_tbl_id']) {
                                    $category_name = $cat['category_name'];
                                    break;
                                }
                            }
                            ?>
                            <tr>
                                <td><input type="checkbox" class="row-checkbox" value="<?= $row['numbers_tbl_id'] ?>">
                                </td>
                                <td><?= ++$i ?></td>
                                <td>
                                    <strong><?= htmlspecialchars($row['mobile_number']) ?></strong>
                                </td>
                                <td>₹<?= number_format($row['price'], 2) ?></td>
                                <td>₹<?= number_format($row['original_price'], 2) ?></td>
                                <td><?= htmlspecialchars($category_name) ?></td>
                                <td><?= htmlspecialchars($row['port_region']) ?></td>
                                <td><?= filter_name($row['filter_tbl_id']) ?></td>
                                <td>
                                    <?php
                                    $status_class = '';
                                    switch ($row['product_status']) {
                                        case 'Available':
                                            $status_class = 'badge bg-success';
                                            break;
                                        case 'Sold':
                                            $status_class = 'badge bg-danger';
                                            break;
                                        default:
                                            $status_class = 'badge bg-secondary';
                                    }
                                    ?>
                                    <span class="<?= $status_class ?>">
                                        <?= $row['product_status'] ?>
                                    </span>
                                </td>
                                <td>
                                    <small>
                                        <?= date('d M Y', strtotime($row['entry_date'])) ?>
                                    </small>
                                </td>
                                <td style="width: 150px">
                                    <a href="<?= base_url() ?>admin/edit_number/<?= $row['numbers_tbl_id'] ?>"
                                        class="btn btn-outline-secondary btn-sm" title="Edit">
                                        <i class="fas fa-pencil-alt"></i>
                                    </a>
                                    <?php if ($row['product_status'] == 'Available'): ?>
                                        <a href="<?= base_url() ?>admin/mark_sold_2/<?= $row['numbers_tbl_id'] ?>"
                                            class="btn btn-outline-warning btn-sm" title="Mark as Sold">
                                            <i class="fas fa-check"></i>
                                        </a>
                                    <?php else: ?>
                                        <a href="<?= base_url() ?>admin/mark_available_2/<?= $row['numbers_tbl_id'] ?>"
                                            class="btn btn-outline-success btn-sm" title="Mark as Available">
                                            <i class="fas fa-undo"></i>
                                        </a>
                                    <?php endif; ?>
                                    <a href="<?= base_url() ?>admin/delete_number/<?= $row['numbers_tbl_id'] ?>"
                                        onclick="return confirm('Are You Sure You Want to Delete ??')"
                                        class="btn btn-sm btn-outline-danger" title="Delete">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php
                        }
                    } else {
                        ?>
                        <tr>
                            <td colspan="9" class="text-center py-4">
                                <div class="text-muted">
                                    <i class="fas fa-phone fa-3x mb-3"></i>
                                    <h5>No Numbers Found</h5>
                                    <p>There are no numbers matching your search criteria.</p>
                                </div>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>

            <?php
            if (function_exists('pagination') && isset($ttl_pages) && isset($page_no)) {
                pagination($ttl_pages, $page_no);
            }
            ?>
        </div>

    </div>
</div>




<script>
    // Toggle select all checkboxes
    function toggleSelectAll() {
        const selectAll = document.getElementById('select_all');
        const checkboxes = document.querySelectorAll('.row-checkbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = selectAll.checked;
        });
    }

    // Mark selected numbers as sold
    function markSelectedAsSold() {
        const selected = getSelectedIds();
        if (selected.length === 0) {
            alert('Please select at least one number');
            return;
        }
        if (confirm('Mark selected numbers as Sold?')) {
            submitBulkAction('bulk_mark_sold_2', selected);
        }
    }

    // Mark selected numbers as available
    function markSelectedAsAvailable() {
        const selected = getSelectedIds();
        if (selected.length === 0) {
            alert('Please select at least one number');
            return;
        }
        if (confirm('Mark selected numbers as Available?')) {
            submitBulkAction('bulk_mark_available_2', selected);
        }
    }

    // Submit bulk action via POST
    function submitBulkAction(action, ids) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '<?= base_url() ?>admin/' + action;

        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'selected_ids';
        input.value = ids.join(',');

        form.appendChild(input);
        document.body.appendChild(form);
        form.submit();
    }

    // Get selected checkbox IDs
    function getSelectedIds() {
        const checkboxes = document.querySelectorAll('.row-checkbox:checked');
        return Array.from(checkboxes).map(cb => cb.value);
    }
</script>

<style>
    .table td {
        vertical-align: middle;
    }

    .btn-group-sm>.btn,
    .btn-sm {
        margin: 1px;
    }

    .badge {
        font-size: 0.75em;
    }
</style>