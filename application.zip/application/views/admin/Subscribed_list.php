<div class="container-fluid">
    <div class="row ">

                            <div class="col-12">

                                <div class="card p-3">
            <h4 class="heading">User Current Plan Purchase List</h4>
            <?php
            $show="";
            extract($_GET);
            ?>
                          <form action="">
                    <?php
                    foreach($_GET as $key => $row)
                    {

            if(($key!='page_no')&&($key!="search"))
            {
            ?>
            <input type="hidden" name="<?=$key?>" value="<?=$row?>">
            <?php
            }
        }
        ?>
            <div class="row mt-2 mb-4">
            <div class="col-md-6"></div>
            <div class="col-md-4">
                <form action="<?=base_url()?>admin/employee_list" id="search_form">
                    <input type="text" name="q" id="search_inp" placeholder="Type To Search" value="<?=(isset($_GET['q'])) ? $_GET['q']:''?>" class="form-control">
                </form>
            </div>
        <div class="col-md-2">
            <button class="btn btn-primary w-100" style="border-radius: 0px;" onclick="(search_inp.value!='') ? search_form.submit() : search_form.submit();">SEARCH</button>
        </div>
        </div>
    
    </form>
                                    <div class="card-body table-responsive">
                                        <table  class="table table-sm table-bordered table-striped w-100">
                                            <thead class="table-info">
                                            <tr class="">
                                                <th>SN</th>
                                                <th>Name</th>
                                                <th>Mobile no</th>
                                                <th>Plan</th>
                                                <th>Amount</th>
                                                <th>Purchase Date</th>
                                                <th>Expiry Date</th>
                                                <th>Action</th>
                                            </thead>
        
        
                                            <tbody>
                                                <tr>
                                                    <?php 
                                                    $i=$start;
                                                        foreach ($list as $row) {
                                                          
                                                            ?>
                                                            <tr>
                                                                
                                                                <td><?=++$i?></td>
                                                                <td><?=$row['user_name']?></td>
                                                                <td><?=$row['user_mobile_no']?></td>
                                                                <td><?=$row['plan_name']?></td>
                                                                <td><?=$row['purchase_amount']?><sub>/<?=$row['purchase_per']?></sub></td>
                                                                <td><?=$row['purchase_date']?></td>
                                                                <td><?=$row['plan_expiry_date']?></td>
                                                                <td style="white-space: nowrap;">
                                                                    <a href="<?=base_url()?>admin/purchase_plan_history/<?=$row['user_subscribe_plans_id']?>" title="Delete">
                                                                       <button class="btn btn-info btn-sm pt-1 pb-1 edit" > <i class="fa fa-history">&nbsp;Purchase History</i></button>
                                                                    </a>
                                                                    <a href="<?=base_url()?>admin/delete_purchase_plan/<?=$row['user_subscribe_plans_id']?>" title="Delete">
                                                                       <button class="btn btn-outline-danger btn-sm pt-1 pb-1 edit" onclick="return confirm('Are You Sure You Want to Delete ??')" > <i class="fas fa-trash-alt"></i></button>
                                                                    </a>
                                                                </td>
                                                            </tr>
                                                            <?php
                                                        }
                                                    ?>
                                                </tr>
                                            </tbody>
                                        </table>
                                                <?php
            pagination($ttl_pages,$page_no);
            ?>
                                    </div>
                                </div>
                            </div> <!-- end col -->
                        </div>
</div>