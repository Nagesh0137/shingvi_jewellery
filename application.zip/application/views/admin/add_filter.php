<?php if (isset($det)) { ?>

    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Edit Product filter</h5>
                        <form action="<?= base_url() ?>admin/update_filter" method="post" enctype="multipart/form-data">
                            <div class="form-floating mb-3">
                                <input type="text" name="filter" class="form-control" id="floatingnameInput"
                                    placeholder="e.g. Labour,Supervisor" value="<?= $det['filter'] ?>" required>
                                <input type="hidden" name="filter_tbl_id" value="<?= $det['filter_tbl_id'] ?>">
                                <label for="floatingnameInput">Product filter Name</label>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary w-md">UPDATE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php } else { ?>


    <div class="container">
        <div class="row">
            <div class="col-md-12 ">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title heading">Add Filter</h5>

                        <form action="<?= base_url() ?>admin/save_filter" method="post" enctype="multipart/form-data">
                            <div class="form-floating mb-3">
                                <input type="text" name="filter" class="form-control" id="floatingnameInput"
                                    placeholder="e.g. 0000,5555,6666" required>
                                <label for="floatingnameInput">Filter Name <span class="text-danger">*</span></label>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary w-md">SAVE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h6 class="heading">filter List</h6>
                        <table id="datatable-buttons" class="table table-sm table-bordered dt-responsive nowrap w-100">
                            <thead>
                                <tr class="">
                                    <th>Action</th>
                                    <th>SN</th>
                                    <th>Filter Name</th>
                                    <th>Filter Id</th>
                                </tr>
                            </thead>


                            <tbody>
                                <?php
                                $i = 0;
                                foreach ($list as $row) {
                                    $i++;

                                    ?>
                                    <tr id="myEdit<?= $i ?>">
                                        <form action="<?= base_url() ?>admin/update_filter" method="post">
                                            <td style="width: 100px">
                                                <a href="<?= base_url() ?>admin/edit_filter/<?= $row['filter_tbl_id'] ?>"
                                                    class="btn btn-outline-secondary btn-sm edit" title="Edit">
                                                    <i class="fas fa-pencil-alt"></i>
                                                </a>
                                                <button type="submit" class="btn p-0"
                                                    style="border:none;background-color: none;">
                                                    <a href="javascript:void(0);"
                                                        class="btn btn-outline-info btn-sm save d-none" title="Save"
                                                        onclick="toggleEditSave(<?= $i ?>)">
                                                        <i class="fas fa-save"></i>
                                                    </a>
                                                </button>
                                                <a href="<?= base_url() ?>admin/delete_filter/<?= $row['filter_tbl_id'] ?>"
                                                    onclick="return confirm('Are You Sure You Want to Delete ??')"
                                                    class="btn btn-sm btn-outline-danger" title="Delete">
                                                    <i class="fa fa-trash "></i>
                                                </a>
                                            </td>
                                            <td>
                                                <?= $i ?>
                                            </td>
                                            <td>
                                                <span id="job_span<?= $i ?>"><?= $row['filter'] ?></span>
                                                <input type="hidden" name="filter_tbl_id" value="<?= $row['filter_tbl_id'] ?>">
                                                <input type="text" class="form-control d-none" required
                                                    value="<?= $row['filter'] ?>" name="filter" id="filter_id<?= $i ?>">
                                            </td>
                                            <td>
                                                <?= $row['filter_tbl_id'] ?>
                                            </td>

                                        </form>
                                    </tr>
                                    <?php
                                }
                                if ($i == 0) {
                                    ?>
                                    <tr>
                                        <td colspan="6" class="text-center p-2">
                                            <h4>No Records Found</h4>
                                        </td>
                                    </tr>
                                    <?php
                                }
                                ?>


                                <script>
                                    function toggleEditSave(index) {
                                        // Revert all rows to original state
                                        $('[id^="myEdit"] .edit').removeClass('d-none');
                                        $('[id^="myEdit"] .save').addClass('d-none');
                                        $('[id^="myEdit"] span').removeClass('d-none');
                                        $('[id^="myEdit"] input').addClass('d-none');

                                        // Toggle visibility of edit and save buttons for the clicked row
                                        $('#myEdit' + index + ' .edit').toggleClass('d-none');
                                        $('#myEdit' + index + ' .save').toggleClass('d-none');

                                        // Toggle visibility of span and input for the clicked row
                                        $('#myEdit' + index + ' span').toggleClass('d-none');
                                        $('#myEdit' + index + ' input').toggleClass('d-none');
                                    }
                                </script>

                            </tbody>
                        </table>
                    </div>

                </div>

            </div>
            <!-- end col -->
        </div>
    </div>

<?php } ?>