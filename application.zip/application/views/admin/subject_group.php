<div class="container-fluid bg-white">
    <div class="row">
        <div class="col-md-4 border card p-3">
            <form method="POST" action="<?= isset($det) ? base_url('admin/update_subject_group') : base_url('admin/save_subject_group') ?>">
                <h4><?= isset($det) ? 'Edit' : 'Add' ?> Subject Group</h4>

                <label>Class <span class="text-danger">*</span></label>
                <select name="class_id" class="form-control" required>
                    <option value="">-- Select Class --</option>
                    <?php foreach ($class_list as $class): ?>
                        <option value="<?= $class['class_id'] ?>"
                            <?= isset($det[0]) && $det[0]['class_id'] == $class['class_id'] ? 'selected' : '' ?>>
                            <?= $class['class_name'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label class="mt-2">Subject Group Name <span class="text-danger">*</span></label>
                <input type="text" name="subject_group_name" class="form-control" required
                       value="<?= isset($det[0]) ? $det[0]['subject_group_name'] : '' ?>">

                <?php if (isset($det[0])): ?>
                    <input type="hidden" name="subject_group_tbl_id" value="<?= $det[0]['subject_group_tbl_id'] ?>">
                <?php endif; ?>

                <button class="btn btn-primary mt-2" type="submit"><?= isset($det) ? 'Update' : 'Save' ?></button>
            </form>
        </div>

        <div class="col-md-8 table-responsive p-3">
            <h5>All Subject Groups</h5>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Group Name</th>
                        <th>Class</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 0; foreach ($list as $row): $i++; 
                        $class = $this->My_model->select_where("class", ['class_id' => $row['class_id']]);
                    ?>
                        <tr>
                            <td><?= $i ?></td>
                            <td><?= $row['subject_group_name'] ?></td>
                            <td><?= $class[0]['class_name'] ?? '' ?></td>
                            <td>
                                <a href="<?= base_url() ?>admin/edit_subject_group/<?= $row['subject_group_tbl_id'] ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="fa fa-pencil"></i>
                                </a>
                                <a href="<?= base_url() ?>admin/delete_subject_group/<?= $row['subject_group_tbl_id'] ?>" 
                                   onclick="return confirm('Are you sure?')" 
                                   class="btn btn-sm btn-outline-danger">
                                    <i class="fa fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
