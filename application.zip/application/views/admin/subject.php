<div class="container-fluid bg-white">
<?php if(isset($det[0])): ?>
<div class="row">
    <div class="col-md-4 border border-info card p-3">
        <form method="POST" action="<?=base_url()?>admin/update_subject">
            <h4 class="heading">Edit Subject</h4>
            <label>Subject Name <span class="text-danger">*</span></label>
            <input type="text" name="subject_name" value="<?=$det[0]['subject_name']?>" class="form-control" required>
            <input type="hidden" name="subject_tbl_id" value="<?=$det[0]['subject_tbl_id']?>">
            <button class="btn btn-success mt-2" type="submit">Update</button>
        </form>
    </div>
</div>
<?php else: ?>
<div class="row pt-3 pb-3">
    <div class="col-md-4 border border-primary card p-3">
        <form method="POST" action="<?=base_url()?>admin/save_subject">
            <h4 class="heading">Add Subject</h4>
            <label>Subject Name <span class="text-danger">*</span></label>
            <input type="text" name="subject_name" class="form-control" required>
            <button class="btn btn-primary mt-2" type="submit">Save</button>
        </form>
    </div>

    <div class="col-md-8 table-responsive p-2" style="height:400px !important;">
        <table class="table table-sm table-bordered table-striped " >
            <thead>
                <tr>
                    <th>SN</th>
                    <th>Subject Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $i=1; foreach($list as $row): ?>
                <tr>
                    <td><?=$i++?></td>
                    <td><?=$row['subject_name']?></td>
                    <td>
                        <a href="<?=base_url()?>admin/edit_subject/<?=$row['subject_tbl_id']?>" class="btn btn-sm btn-outline-primary"><i class="fa fa-pencil"></i></a>
                        <a href="<?=base_url()?>admin/delete_subject/<?=$row['subject_tbl_id']?>" onclick="return confirm('Delete this subject?')" class="btn btn-sm btn-outline-danger"><i class="fa fa-trash"></i></a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
</div>
