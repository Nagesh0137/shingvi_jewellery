<?php if (isset($det)) { ?>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title heading">Edit Number</h5>

                <form action="<?= base_url() ?>admin/update_number" method="post">
                    <input type="hidden" name="numbers_tbl_id" value="<?= $det['numbers_tbl_id'] ?>">
                    <div class="row">
                        <div class="form-floating col-md-4 mb-3">
                            <input type="text" value="<?= $det['mobile_number'] ?>" name="mobile_number"
                                class="form-control" id="mobile_number" placeholder="Enter Mobile Number" required>
                            <label for="mobile_number">Mobile Number <span class="text-danger">*</span></label>
                        </div>
                        <div class="form-floating col-md-4 mb-3">
                            <select name="category_tbl_id" class="form-control" id="category_tbl_id" required>
                                <option value="">Select Category</option>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?= $category['category_tbl_id'] ?>"
                                        <?= ($det['category_tbl_id'] == $category['category_tbl_id']) ? 'selected' : '' ?>>
                                        <?= $category['category_name'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <label for="category_tbl_id">Category <span class="text-danger">*</span></label>
                        </div>
                        <div class="form-floating col-md-4 mb-3">
                            <input type="number" value="<?= $det['price'] ?>" name="price" class="form-control" id="price"
                                placeholder="Enter Price" step="0.01" required>
                            <label for="price">Sale Price <span class="text-danger">*</span></label>
                        </div>
                        <div class="form-floating col-md-4 mb-3">
                            <input type="number" value="<?= $det['original_price'] ?>" name="original_price"
                                class="form-control" id="original_price" placeholder="Enter Original Price" step="0.01"
                                required>
                            <label for="original_price">Original Price <span class="text-danger">*</span></label>
                        </div>
                        <div class="form-floating col-md-4 mb-3">
                            <input type="text" value="<?= $det['port_region'] ?>" name="port_region" class="form-control"
                                id="port_region" placeholder="Enter Port Region">
                            <label for="port_region">Port Region</label>
                        </div>

                        <div class="form-floating col-md-4 mb-3">
                            <select name="filter_tbl_id" class="form-control" id="filter_tbl_id" required>
                                <option value="" selected disabled>Select Filter</option>
                                <?php foreach ($filters as $filter): ?>
                                    <option value="<?= $filter['filter_tbl_id'] ?>"
                                        <?= ($det['filter_tbl_id'] == $filter['filter_tbl_id']) ? 'selected' : '' ?>>
                                        <?= $filter['filter'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <label for="filter">Filter <span class="text-danger">*</span></label>

                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary w-md">UPDATE</button>
                            <a href="<?= base_url() ?>admin/add_numbers" class="btn btn-secondary w-md">CANCEL</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php } else { ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title heading">Add Number</h5>
                        <form action="<?= base_url() ?>admin/save_number" method="post">
                            <div class="row">
                                <div class="form-floating col-md-6 mb-3">
                                    <input type="number" name="mobile_number" class="form-control" id="mobile_number"
                                        placeholder="Enter Mobile Number" required>
                                    <label for="mobile_number"> Number <span class="text-danger">*</span></label>
                                </div>
                                <div class="form-floating col-md-6 mb-3">
                                    <select name="category_tbl_id" class="form-control" id="category_tbl_id" required>
                                        <option value="">Select Category</option>
                                        <?php foreach ($categories as $category): ?>
                                            <option value="<?= $category['category_tbl_id'] ?>">
                                                <?= $category['category_name'] ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <label for="category_tbl_id">Category <span class="text-danger">*</span></label>
                                </div>
                                <div class="form-floating col-md-6 mb-3">
                                    <input type="number" name="price" class="form-control" id="price"
                                        placeholder="Enter Price" step="0.01" required>
                                    <label for="price">Sale Price <span class="text-danger">*</span></label>
                                </div>
                                <div class="form-floating col-md-6 mb-3">
                                    <input type="number" name="original_price" class="form-control" id="original_price"
                                        placeholder="Enter Original Price" step="0.01" required>
                                    <label for="original_price">Original Price <span class="text-danger">*</span></label>
                                </div>

                                <div class="form-floating col-md-6  mb-3">
                                    <input type="text" name="port_region" class="form-control" id="port_region"
                                        placeholder="Enter Port Region">
                                    <label for="port_region">Port Region</label>
                                </div>
                                <div class="form-floating col-md-6 mb-3">
                                    <select name="filter_tbl_id" class="form-control" id="filter_tbl_id" required>
                                        <option value="" selected disabled>Select Filter</option>
                                        <?php foreach ($filters as $filter): ?>
                                            <option value="<?= $filter['filter_tbl_id'] ?>"><?= $filter['filter'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <label for="filter">Filter <span class="text-danger">*</span></label>

                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary w-md">SAVE</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Bulk CSV Import Section -->
            <div class="col-lg-6 ">
                <div class="card ">
                    <div class="card-body">
                        <h5 class="card-title heading">Bulk CSV Import</h5>
                        <form action="<?= base_url() ?>admin/import_numbers_csv" method="post"
                            enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="row">
                                        <div class="form-floating col-md-8 mb-3">
                                            <input type="file" name="csv_file" class="form-control" id="csv_file"
                                                accept=".csv" required>
                                            <label for="csv_file">Select CSV File <span class="text-danger">*</span></label>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-md-4">

                                    <a href="<?= base_url() ?>admin/download_sample_csv"
                                        class="btn btn-outline-primary btn-sm">Download Sample CSV</a>
                                </div>

                                <div class="col-md-12 mb-3 text-center">
                                    <button type="submit" class="btn btn-success">IMPORT CSV</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Numbers List -->
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title heading">Numbers List</h4>


                        <?php
                        $show = "";
                        extract($_GET);
                        ?>

                        <!-- Search and Filter Form -->
                        <div class="row mt-2 mb-4">
                            <form action="<?= base_url() ?>admin/add_numbers" id="search_form">
                                <div class="row">
                                    <div class="col-md-3">
                                        <input type="text" name="q" id="search_inp" placeholder="Search by..."
                                            value="<?= (isset($_GET['q'])) ? $_GET['q'] : '' ?>" class="form-control">
                                    </div>
                                    <div class="col-md-2">
                                        <select name="category" class="form-control">
                                            <option value="">All Categories</option>
                                            <?php foreach ($categories as $category): ?>
                                                <option value="<?= $category['category_tbl_id'] ?>" <?= (isset($_GET['category']) && $_GET['category'] == $category['category_tbl_id']) ? 'selected' : '' ?>>
                                                    <?= $category['category_name'] ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <select name="status" class="form-control">
                                            <option value="">All Status</option>
                                            <option value="Available" <?= (isset($_GET['status']) && $_GET['status'] == 'Available') ? 'selected' : '' ?>>Available</option>
                                            <option value="Sold" <?= (isset($_GET['status']) && $_GET['status'] == 'Sold') ? 'selected' : '' ?>>Sold</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <input type="date" name="form"
                                            value="<?= (isset($_GET['form']) && $_GET['form'] != '') ? $_GET['form'] : date('Y-m-d') ?>"
                                            class="form-control" placeholder="From Date">
                                    </div>
                                    <div class="col-md-2">
                                        <input type="date" name="to"
                                            value="<?= (isset($_GET['to']) && $_GET['to'] != '') ? $_GET['to'] : date('Y-m-d') ?>"
                                            class="form-control" placeholder="To Date">
                                    </div>
                                    <div class="col-md-1">
                                        <button class="btn btn-primary btn-sm" style="border-radius: 0px;"
                                            onclick="search_form.submit();">SEARCH</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class=" mb-3">
                            <div>
                                <button class="btn btn-danger btn-sm" onclick="markSelectedAsSold()">Mark Selected as
                                    Sold</button>
                                <button class="btn btn-success btn-sm" onclick="markSelectedAsAvailable()">Mark Selected as
                                    Available</button>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-sm table-bordered table-striped w-100">
                                <thead class="table-info">
                                    <tr>
                                        <th><input type="checkbox" id="select_all" onchange="toggleSelectAll()"></th>
                                        <th>SN</th>
                                        <th>Mobile Number</th>
                                        <th>Sale Price</th>
                                        <th>Original Price</th>
                                        <th>Category</th>
                                        <th>Port Region</th>
                                        <th>Filter</th>
                                        <th>Status</th>
                                        <th>Entry Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php
                                    $i = $start;
                                    if (isset($list) && !empty($list)) {
                                        foreach ($list as $row) {
                                            $category_name = '';
                                            foreach ($categories as $cat) {
                                                if ($cat['category_tbl_id'] == $row['category_tbl_id']) {
                                                    $category_name = $cat['category_name'];
                                                    break;
                                                }
                                            }
                                            ?>
                                            <tr>
                                                <td><input type="checkbox" class="row-checkbox"
                                                        value="<?= $row['numbers_tbl_id'] ?>">
                                                </td>
                                                <td><?= ++$i ?></td>
                                                <td>
                                                    <strong><?= htmlspecialchars($row['mobile_number']) ?></strong>
                                                </td>
                                                <td>₹<?= number_format($row['price'], 2) ?></td>
                                                <td>₹<?= number_format($row['original_price'], 2) ?></td>
                                                <td><?= htmlspecialchars($category_name) ?></td>
                                                <td><?= htmlspecialchars($row['port_region']) ?></td>
                                                <td><?= filter_name($row['filter_tbl_id']) ?></td>
                                                <td>
                                                    <?php
                                                    $status_class = '';
                                                    switch ($row['product_status']) {
                                                        case 'Available':
                                                            $status_class = 'badge bg-success';
                                                            break;
                                                        case 'Sold':
                                                            $status_class = 'badge bg-danger';
                                                            break;
                                                        default:
                                                            $status_class = 'badge bg-secondary';
                                                    }
                                                    ?>
                                                    <span class="<?= $status_class ?>">
                                                        <?= $row['product_status'] ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <small>
                                                        <?= date('d M Y', strtotime($row['entry_date'])) ?>
                                                    </small>
                                                </td>
                                                <td style="width: 150px">
                                                    <a href="<?= base_url() ?>admin/edit_number/<?= $row['numbers_tbl_id'] ?>"
                                                        class="btn btn-outline-secondary btn-sm" title="Edit">
                                                        <i class="fas fa-pencil-alt"></i>
                                                    </a>
                                                    <?php if ($row['product_status'] == 'Available'): ?>
                                                        <a href="<?= base_url() ?>admin/mark_sold/<?= $row['numbers_tbl_id'] ?>"
                                                            class="btn btn-outline-warning btn-sm" title="Mark as Sold">
                                                            <i class="fas fa-check"></i>
                                                        </a>
                                                    <?php else: ?>
                                                        <a href="<?= base_url() ?>admin/mark_available/<?= $row['numbers_tbl_id'] ?>"
                                                            class="btn btn-outline-success btn-sm" title="Mark as Available">
                                                            <i class="fas fa-undo"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <a href="<?= base_url() ?>admin/delete_number/<?= $row['numbers_tbl_id'] ?>"
                                                        onclick="return confirm('Are You Sure You Want to Delete ??')"
                                                        class="btn btn-sm btn-outline-danger" title="Delete">
                                                        <i class="fa fa-trash"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    } else {
                                        ?>
                                        <tr>
                                            <td colspan="9" class="text-center py-4">
                                                <div class="text-muted">
                                                    <i class="fas fa-phone fa-3x mb-3"></i>
                                                    <h5>No Numbers Found</h5>
                                                    <p>There are no numbers matching your search criteria.</p>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>

                            <?php
                            if (function_exists('pagination') && isset($ttl_pages) && isset($page_no)) {
                                pagination($ttl_pages, $page_no);
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php } ?>

<script>
    // Toggle select all checkboxes
    function toggleSelectAll() {
        const selectAll = document.getElementById('select_all');
        const checkboxes = document.querySelectorAll('.row-checkbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = selectAll.checked;
        });
    }

    // Mark selected numbers as sold
    function markSelectedAsSold() {
        const selected = getSelectedIds();
        if (selected.length === 0) {
            alert('Please select at least one number');
            return;
        }
        if (confirm('Mark selected numbers as Sold?')) {
            submitBulkAction('bulk_mark_sold', selected);
        }
    }

    // Mark selected numbers as available
    function markSelectedAsAvailable() {
        const selected = getSelectedIds();
        if (selected.length === 0) {
            alert('Please select at least one number');
            return;
        }
        if (confirm('Mark selected numbers as Available?')) {
            submitBulkAction('bulk_mark_available', selected);
        }
    }

    // Submit bulk action via POST
    function submitBulkAction(action, ids) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '<?= base_url() ?>admin/' + action;

        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'selected_ids';
        input.value = ids.join(',');

        form.appendChild(input);
        document.body.appendChild(form);
        form.submit();
    }

    // Get selected checkbox IDs
    function getSelectedIds() {
        const checkboxes = document.querySelectorAll('.row-checkbox:checked');
        return Array.from(checkboxes).map(cb => cb.value);
    }
</script>

<style>
    .table td {
        vertical-align: middle;
    }

    .btn-group-sm>.btn,
    .btn-sm {
        margin: 1px;
    }

    .badge {
        font-size: 0.75em;
    }
</style>