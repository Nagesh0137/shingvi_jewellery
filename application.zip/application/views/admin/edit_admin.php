 <div class="container bg-white p-4">
     <div class="card-body">
         <form action="<?= base_url() ?>admin/update_admin" class="g-3 row needs-validation" method="post" enctype="multipart/form-data" novalidate>

             <input type="hidden" name="admin_tbl_id" value="<?= $admin_det['admin_tbl_id'] ?>" />
             <input type="hidden" name="admin_profile_logo1" value="<?= $admin_det['admin_profile_logo'] ?>" />
             <div class="col-12 col-md-6">
                 <label for="admin_name" class="form-label">Name <span class="text-danger">*</span></label>
                 <input type="text" class="form-control" id="admin_name" name="admin_name" value="<?= $admin_det['admin_name'] ?>" placeholder="Enter Full Name" />
                 <div class="invalid-feedback">Please provide a valid name.</div>
             </div>

             <div class="col-12 col-md-6">
                 <label for="admin_email" class="form-label">Email <span class="text-danger">*</span></label>
                 <input type="email" class="form-control" id="admin_email" name="admin_email" value="<?= $admin_det['admin_email'] ?>" placeholder="Enter Email Address" />
                 <div class="invalid-feedback">Please provide a valid email.</div>
             </div>

             <div class="col-12 col-md-6">
                 <label for="admin_mobile" class="form-label">Mobile Number <span class="text-danger">*</span></label>
                 <input type="tel" class="form-control" id="admin_mobile" name="admin_mobile_no" value="<?= $admin_det['admin_mobile_no'] ?>" placeholder="Enter Mobile Number" pattern="[0-9]{10}" />
                 <div class="invalid-feedback">Please provide a valid 10-digit mobile number.</div>
             </div>

             <div class="col-12 col-md-6">
                 <label for="admin_password" class="form-label">Password <span class="text-danger">*</span></label>
                 <input type="text" class="form-control" id="admin_password" name="admin_password" value="<?= $admin_det['admin_password'] ?>" placeholder="Enter Password" minlength="6" />
                 <div class="invalid-feedback">Password must be at least 6 characters long.</div>
             </div>

             <div class="col-12 col-md-6">
                 <label for="admin_position" class="form-label">Position <span class="text-danger">*</span></label>
                 <select class="form-select" id="admin_position" name="admin_position" value="<?= $admin_det['admin_position'] ?>">
                     <option value="" disabled selected>Select Position</option>
                     <?php if (!empty($positions)) {
                            foreach ($positions as $position) { ?>
                             <option value="<?= $position['admin_position_id'] ?>" <?= ($position['admin_position_id'] == $admin_det['admin_position']) ? 'selected' : '' ?>><?= $position['admin_position'] ?></option>
                     <?php }
                        } ?>
                 </select>
                 <div class="invalid-feedback">Please select a position.</div>
             </div>

             <div class="col-12 col-md-6">
                 <label for="admin_profile_logo" class="form-label">Profile Photo</label>
                 <input type="file" class="form-control" id="admin_profile_logo" name="admin_profile_logo" accept="image/*" />
                 <div class="form-text">Accepted formats: JPG, PNG, GIF (Max: 2MB)</div>
                 <img src="<?= base_url() ?>uploads/<?= $admin_det['admin_profile_logo'] ?>" class=" img-fluid" height="100px" width="100px" alt="">
             </div>



             <div class="col-md-12 text-center">
                 <button class="btn btn-ml btn-success text-uppercase mt-4" type="submit"><b>Update</b></button>
             </div>
         </form>
     </div>
 </div>