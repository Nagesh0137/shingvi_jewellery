<?php if (isset($det)) { ?>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Edit Mission and Vision</h5>

                <form action="<?= base_url() ?>admin/update_mission_and_vision" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="mission_vision_tbl_id" value="<?= $det['mission_vision_tbl_id'] ?>">
                    <input type="hidden" name="old_mission_vision_img" value="<?= $det['mission_vision_img'] ?>">
                    <div class="row">
                        <div class="form-floating col-md-6 mb-3">
                            <input type="file" value="<?= $det['mission_vision_img'] ?>" name="mission_vision_img" class="form-control" id="floatingnameInput" placeholder="Select Mission & Vision Image">
                            <label for="floatingnameInput">Mission & Vision Image</label>
                            <img src="<?= base_url() ?>uploads/<?= $det['mission_vision_img'] ?>" class="img-fluid mt-2" height="50px" width="50px" alt="Mission & Vision Image">
                        </div>
                        <div class="form-floating col-md-6 mb-3">
                            <input type="text" value="<?= $det['mission_vision_title'] ?>" name="mission_vision_title" class="form-control" id="floatingnameInput" placeholder="Enter Mission & Vision Title">
                            <label for="floatingnameInput">Mission & Vision Title</label>
                        </div>
                        <div class="form-floating col-md-12 mb-3">
                            <textarea name="mission_vision_desc" class="form-control" id="mission_vision_desc" style="height: 150px;"><?= $det['mission_vision_desc'] ?></textarea>
                            <label for="mission_vision_desc">Mission & Vision Description</label>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary w-md">UPDATE</button>
                            <a href="<?= base_url() ?>admin/mission_and_vision" class="btn btn-secondary w-md">CANCEL</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php } else { ?>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Add Mission and Vision</h5>

                <form action="<?= base_url() ?>admin/save_mission_and_vision" method="post" enctype="multipart/form-data">
                    <div class="row">
                        <div class="form-floating col-md-6 mb-3">
                            <input type="file" name="mission_vision_img" class="form-control" id="floatingnameInput" placeholder="Select Mission & Vision Image" required>
                            <label for="floatingnameInput">Mission & Vision Image <span class=" text-danger">*</span></label>
                        </div>
                        <div class="form-floating col-md-6 mb-3">
                            <input type="text" name="mission_vision_title" class="form-control" id="floatingnameInput" placeholder="Enter Mission & Vision Title" required>
                            <label for="floatingnameInput">Mission & Vision Title <span class=" text-danger">*</span></label>
                        </div>
                        <div class="form-floating col-md-12 mb-3">
                            <textarea name="mission_vision_desc" class="form-control" id="mission_vision_desc" style="height: 80px;" placeholder="Enter Mission & Vision Description"></textarea>
                            <label for="mission_vision_desc">Mission & Vision Description <span class=" text-danger">*</span></label>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary w-md">SAVE</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Mission and Vision List</h4>
                <table id="datatable-buttons" class="table table-sm table-bordered dt-responsive nowrap w-100">
                    <thead>
                        <tr>
                            <th>Action</th>
                            <th>SN</th>
                            <th>Mission & Vision Image</th>
                            <th>Mission & Vision Title</th>
                            <th>Description</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                        $i = 0;
                        foreach ($list as $row) {
                            $i++;
                        ?>
                            <tr id="myEdit<?= $i ?>">
                                <form action="<?= base_url() ?>admin/update_mission_and_vision" method="post" enctype="multipart/form-data">
                                    <td style="width: 120px">
                                        <a href="<?= base_url() ?>admin/edit_mission_and_vision/<?= $row['mission_vision_tbl_id'] ?>" class="btn btn-outline-secondary btn-sm edit" title="Edit">
                                            <i class="fas fa-pencil-alt"></i>
                                        </a>
                                        <button type="submit" class="btn btn-outline-info btn-sm save d-none" title="Save" id="save_btn<?= $i ?>">
                                            <i class="fas fa-save"></i>
                                        </button>
                                        <a href="<?= base_url() ?>admin/delete_mission_and_vision/<?= $row['mission_vision_tbl_id'] ?>" onclick="return confirm('Are You Sure You Want to Delete ??')" class="btn btn-sm btn-outline-danger" title="Delete">
                                            <i class="fa fa-trash "></i>
                                        </a>
                                    </td>
                                    <td>
                                        <?= $i ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($row['mission_vision_img'])): ?>
                                            <img src="<?= base_url() ?>uploads/<?= $row['mission_vision_img'] ?>" alt="Mission & Vision Image" style="width: 80px; height: 50px; object-fit: cover;" class="img-thumbnail">
                                        <?php else: ?>
                                            <span class="text-muted">No Image</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span id="title_span<?= $i ?>"><?= $row['mission_vision_title'] ?></span>
                                        <input type="hidden" name="mission_vision_id" value="<?= $row['mission_vision_tbl_id'] ?>">
                                        <input type="text" class="form-control d-none" required value="<?= $row['mission_vision_title'] ?>" name="mission_vision_title" id="mission_vision_title<?= $i ?>">
                                    </td>
                                    <td>
                                        <span id="desc_span<?= $i ?>"><?= substr($row['mission_vision_desc'], 0, 50) ?>...</span>
                                        <textarea class="form-control d-none" name="mission_vision_desc" id="mission_vision_desc<?= $i ?>"><?= $row['mission_vision_desc'] ?></textarea>
                                    </td>

                                </form>
                            </tr>
                        <?php
                        }
                        if ($i == 0) {
                        ?>
                            <tr>
                                <td colspan="5" class="text-center p-2">
                                    <h4>No Records Found</h4>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>

                    </tbody>
                </table>
            </div>

        </div>

    </div>
<?php } ?>

<script>
    function toggleEditSave(index) {
        // Toggle visibility of spans and inputs
        const titleSpan = document.getElementById('title_span' + index);
        const titleInput = document.getElementById('mission_vision_title' + index);
        const descSpan = document.getElementById('desc_span' + index);
        const descInput = document.getElementById('mission_vision_desc' + index);
        const editBtn = document.querySelector('#myEdit' + index + ' .edit');
        const saveBtn = document.getElementById('save_btn' + index);

        if (titleInput.classList.contains('d-none')) {
            // Switch to edit mode
            titleSpan.classList.add('d-none');
            titleInput.classList.remove('d-none');
            descSpan.classList.add('d-none');
            descInput.classList.remove('d-none');
            editBtn.classList.add('d-none');
            saveBtn.classList.remove('d-none');
        } else {
            // Switch to view mode
            titleSpan.classList.remove('d-none');
            titleInput.classList.add('d-none');
            descSpan.classList.remove('d-none');
            descInput.classList.add('d-none');
            editBtn.classList.remove('d-none');
            saveBtn.classList.add('d-none');
        }
    }
</script>