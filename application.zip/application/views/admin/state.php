<div class="container-fluid bg-white">
    <?php if (isset($det[0])): ?>
    <div class="row">
        <div class="col-md-4 border border-warning card p-3 form-group">
            <form method="POST" action="<?=base_url()?>admin/update_state">
                <h4 class="heading">Edit State</h4>
                <label class="mb-0">State Name <span class="text-danger">*</span></label>
                <input type="text" name="state_name" value="<?=$det[0]['state_name']?>" placeholder="Enter State Name" class="form-control" required>
                <input type="hidden" name="state_id" value="<?=$det[0]['state_id']?>">
                <button class="btn btn-primary mt-2" type="submit">UPDATE & SAVE</button>
            </form>
        </div>
    </div>
    <?php else: ?>
    <div class="row">
        <div class="col-md-4 border border-warning card p-3 form-group">
            <form method="POST" action="<?=base_url()?>admin/save_state">
                <h4 class="heading">Add State</h4>
                <label class="mb-0">State Name <span class="text-danger">*</span></label>
                <input type="text" name="state_name" placeholder="Enter State Name" class="form-control" required>
                <button class="btn btn-primary mt-2" type="submit">SAVE</button>
            </form>
        </div>
        
        <div class="col-md-8 table-responsive p-2" style="height:400px;">
            <table class="table table-sm table-bordered table-striped">
                <thead>
                    <tr>
                        <th>SN</th>
                        <th>State Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 0; foreach ($list as $row): $i++; ?>
                    <tr>
                        <td><?=$i?></td>
                        <td><?=$row['state_name']?></td>
                        <td>
                            <a href="<?=base_url()?>admin/edit_state/<?=$row['state_id']?>" class="btn btn-outline-primary btn-sm">
                                <i class="fa fa-pencil"></i>
                            </a>
                            <a onclick="return confirm('Are You Sure You Want To Delete This State?')" href="<?=base_url()?>admin/delete_state/<?=$row['state_id']?>" class="btn btn-outline-danger btn-sm">
                                <i class="fa fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>
