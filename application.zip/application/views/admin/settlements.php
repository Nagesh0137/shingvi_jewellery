
    <div class="container-fluid mt-3">
            <div class="row p-3">
                
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between">
                            <div class="header-title">
                                <h4 class="card-title">Vehicle</h4>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="table-responsive">
                                        <table class="table mx-0">
                                        <thead>
                                            <tr>
                                                <th>Invoice&nbsp;No</th>
                                                <th>Type</th>
                                                <th>Category</th>
                                                <th>Goods</th>
                                                <th>Deal Id</th>
                                                <th>Delivery Id</th>
                                                <th>Buyer</th>
                                                <th>Seller</th>
                                                <th>Load</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>86979</td>
                                                <td>Credit Note</td>
                                                <td>Qty Adjustment</td>
                                                <td>Groundnut Briquette</td>
                                                <td>4391</td>
                                                <td>63601</td>
                                                <td>IDHMA Supplies Private Limited</td>
                                                <td>Virtual White Flash</td>
                                                <td>Ahmednagar</td>
                                            </tr>
                                            <tr>
                                                <td>86979</td>
                                                <td>Credit Note</td>
                                                <td>Qty Adjustment</td>
                                                <td>Groundnut Briquette</td>
                                                <td>4391</td>
                                                <td>63601</td>
                                                <td>IDHMA Supplies Private Limited</td>
                                                <td>Virtual White Flash</td>
                                                <td>Ahmednagar</td>
                                            </tr>
                                            <tr>
                                                <td>86979</td>
                                                <td>Credit Note</td>
                                                <td>Qty Adjustment</td>
                                                <td>Groundnut Briquette</td>
                                                <td>4391</td>
                                                <td>63601</td>
                                                <td>IDHMA Supplies Private Limited</td>
                                                <td>Virtual White Flash</td>
                                                <td>Ahmednagar</td>
                                            </tr>
                                        </tbody>
                    </table>    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
    </div>
