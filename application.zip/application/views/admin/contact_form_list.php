<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card p-3">
                <h4 class="heading">Contact Form Inquiries</h4>
                <?php
                $show = "";
                extract($_GET);
                ?>

                <div class="row mt-2 mb-4">
                    <form action="<?= base_url() ?>admin/contact_form_list" id="search_form">
                        <div class="row">
                            <div class="col-md-4">
                                <input type="text" name="q" id="search_inp" placeholder="Search by name, email, or message" value="<?= (isset($_GET['q'])) ? $_GET['q'] : '' ?>" class="form-control">
                            </div>
                            <div class="col-md-2">
                                <input type="date" name="form" value="<?= (isset($_GET['form'])) ? $_GET['form'] : '' ?>" class="form-control" id="date">
                            </div>
                            <div class="col-md-2">
                                <input type="date" name="to" value="<?= (isset($_GET['to'])) ? $_GET['to'] : '' ?>" class="form-control" id="date">
                            </div>
                            <div class="col-md-2">
                                <button class="btn btn-primary w-100" style="border-radius: 0px;" onclick="(search_inp.value!='') ? search_form.submit() : search_form.submit();">SEARCH</button>
                            </div>
                        </div>
                </div>


                <div class="card-body table-responsive">
                    <table class="table table-sm table-bordered table-striped w-100">
                        <thead class="table-info">
                            <tr>
                                <th>Action</th>
                                <th>SN</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Mobile No</th>
                                <th>Message</th>
                                <th>Date & Time</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i = $start;
                            if (isset($list) && !empty($list)) {
                                foreach ($list as $row) {
                            ?>
                                    <tr>
                                        <td style="width: 120px">
                                            <!-- <a href="<?= base_url() ?>admin/view_contact_inquiry/<?= $row['contact_us_tbl_id'] ?>" class="btn btn-outline-info btn-sm pt-1 pb-1" title="View Details">
                                                <i class="fas fa-eye"></i>
                                            </a> -->
                                            <a href="<?= base_url() ?>admin/delete_contact_form/<?= $row['contact_us_tbl_id'] ?>" class="btn btn-outline-danger btn-sm pt-1 pb-1" title="Delete" onclick="return confirm('Are You Sure You Want to Delete This Inquiry?')">
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                            <?php if ($row['status'] != 'seen') { ?>
                                                <a href="<?= base_url() ?>admin/mark_as_seen/<?= $row['contact_us_tbl_id'] ?>" class="btn btn-outline-success btn-sm pt-1 pb-1" title="Mark as Seen" onclick="return confirm('Mark this inquiry as seen?')">
                                                    <i class="fas fa-check"></i>
                                                </a>
                                            <?php } ?>

                                        </td>
                                        <td><?= ++$i ?></td>
                                        <td>
                                            <strong><?= htmlspecialchars($row['name']) ?></strong>
                                        </td>
                                        <td>
                                            <a href="mailto:<?= htmlspecialchars($row['email']) ?>" class="text-primary">
                                                <?= htmlspecialchars($row['email']) ?>
                                            </a>
                                        </td>
                                        <td>
                                            <a href="tel:<?= htmlspecialchars($row['mobile_no']) ?>" class="text-success">
                                                <?= htmlspecialchars($row['mobile_no']) ?>
                                            </a>
                                        </td>
                                        <td style="max-width: 300px;">
                                            <div class="message-preview" title="<?= htmlspecialchars($row['message']) ?>">
                                                <?php
                                                $message = htmlspecialchars($row['message']);
                                                echo strlen($message) > 100 ? substr($message, 0, 100) . '...' : $message;
                                                ?>
                                            </div>
                                        </td>
                                        <td>
                                            <small>
                                                <?= date('d M Y', strtotime($row['entry_date'])) ?><br>
                                                <?= date('h:i A', strtotime($row['entry_time'])) ?>
                                            </small>
                                        </td>
                                        <td>
                                            <?php
                                            $status_class = '';
                                            switch ($row['status']) {
                                                case 'active':
                                                    $status_class = 'badge bg-warning text-dark';
                                                    break;
                                                case 'pending':
                                                    $status_class = 'badge bg-info';
                                                    break;
                                                case 'seen':
                                                    $status_class = 'badge bg-success';
                                                    break;
                                                default:
                                                    $status_class = 'badge bg-secondary';
                                            }
                                            ?>
                                            <span class="<?= $status_class ?>">
                                                <?= ucfirst($row['status']) ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php
                                }
                            } else {
                                ?>
                                <tr>
                                    <td colspan="8" class="text-center py-4">
                                        <div class="text-muted">
                                            <i class="fas fa-inbox fa-3x mb-3"></i>
                                            <h5>No Contact Inquiries Found</h5>
                                            <p>There are no contact form submissions to display.</p>
                                        </div>
                                    </td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>

                    <?php
                    if (function_exists('pagination') && isset($ttl_pages) && isset($page_no)) {
                        pagination($ttl_pages, $page_no);
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .message-preview {
        word-wrap: break-word;
        word-break: break-word;
        line-height: 1.4;
    }

    .badge {
        font-size: 0.75em;
    }

    .table td {
        vertical-align: middle;
    }

    .btn-group-sm>.btn,
    .btn-sm {
        margin: 1px;
    }
</style>