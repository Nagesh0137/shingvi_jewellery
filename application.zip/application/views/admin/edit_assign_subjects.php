<div class="container-fluid bg-white p-3">
    <form method="POST" action="<?= base_url() ?>admin/update_assigned_subjects">
        <div class="row">
            <div class="col-md-4">
                <label>Subject Group <span class="text-danger">*</span></label>
                <select name="subject_group_id" class="form-control" required>
                    <option value="">Select Subject Group</option>
                    <?php foreach ($subject_groups as $group): ?>
                        <option value="<?= $group['subject_group_tbl_id'] ?>" <?= ($edit_id == $group['subject_group_tbl_id']) ? 'selected' : '' ?>>
                            <?= $group['subject_group_name'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="row mt-3">
            <label>Select Subjects</label>
            <?php foreach ($subjects as $sub): ?>
                <div class="col-md-3">
                    <input type="checkbox" name="subject_ids[]" value="<?= $sub['subject_tbl_id'] ?>"
                        id="sub<?= $sub['subject_tbl_id'] ?>"
                        <?= in_array($sub['subject_tbl_id'], $selected_subjects) ? 'checked' : '' ?>>
                    <label for="sub<?= $sub['subject_tbl_id'] ?>"><?= $sub['subject_name'] ?></label>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="mt-3">
            <button type="submit" class="btn btn-primary">Update Subjects</button>
            <a href="<?= base_url() ?>admin/assign_subjects" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
