<div class="content-inner " id="page_layout">
   <div class="container">
        <div class="row ">
            <div class="col-lg-6  align-content-center text-center">
                <h1 class="text-primary" style="font-size:32px;">Virtual White Flame</h1>
                <h6>Transport Quality Services, and More</h6>
            </div>
            <div class="col-lg-6 text-center mb-5" >
                <img class="d-md-block d-sm d-none" src="<?=base_url()?>uploads/logistic.png" style="height: 75vh;">
                <img class="d-md-none d-sm-block mt-3" src="<?=base_url()?>uploads/logistic.png" style="height: 45vh;">
            </div>
        </div>
    </div>
</div>