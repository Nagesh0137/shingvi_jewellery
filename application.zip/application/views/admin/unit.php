<div class="container">
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Add Unit</h5>

                    <form action="<?=base_url()?>admin/save_unit" method="post" enctype="multipart/form-data">
                        <div class="form-floating mb-3">
                            <input type="text" name="unit_name" class="form-control" id="floatingnameInput" placeholder="e.g. Labour,Supervisor" required>
                            <label for="floatingnameInput">Unit Name</label>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary w-md">SAVE</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
                       

        <div class="col-lg-12">
            <div class="card">
               <div class="card-body">
                    <h4 class="card-title">Unit List</h4>
                        <table id="datatable-buttons" class="table table-sm table-bordered dt-responsive nowrap w-100">
                            <thead>
                                <tr>
                                    <th>SN</th>
                                    <th>Unit Name</th>
                                    <th>Action</th>
                                </tr>
                            </thead>


                        <tbody>
                        <?php 
                        $i = 0;
                        foreach ($unit_list as $row) {
                        $i++;
                        // echo "<pre>";
                        // print_r($row);
                        // echo "</pre>";
                        ?>
                        <tr id="myEdit<?=$i?>">
                            <form action="<?=base_url()?>admin/update_unit" method="post">

                            <td>
                                <?=$i?>
                            </td>
                            <td>    
                                <span id="job_span<?=$i?>"><?=$row['unit_name']?></span>
                                <input type="hidden" name="unit_tbl_id" value="<?=$row['unit_tbl_id']?>">
                                <input type="text" class="form-control d-none" required value="<?=$row['unit_name']?>" name="unit_name" id="unit_id<?=$i?>">
                            </td>
                            <td style="width: 100px">
                                <a class="btn btn-outline-secondary btn-sm edit" title="Edit" onclick="toggleEditSave(<?=$i?>)">
                                    <i class="fas fa-pencil-alt"></i>
                                </a>

                                 <button type="submit" class="btn p-0" style="border:none;background-color: none;">
                            <a href="javascript:void(0);" class="btn btn-outline-info btn-sm save d-none" title="Save" onclick="toggleEditSave(<?=$i?>)">
                           
                            <i class="fas fa-save"></i>  
                      
                            </a>      </button>
                            <a href="<?=base_url()?>admin/delete_unit/<?=$row['unit_tbl_id']?>" onclick="return confirm('Are You Sure You Want to Delete ??')" class="btn btn-sm btn-outline-danger" title="Delete">
                                <i class="fa fa-trash "></i>
                            </a>
                            </td>
                            </form>
                        </tr>
                        <?php
                        }
                        if($i==0)
                    {
                    ?>
                    <tr>
                        <td colspan="6" class="text-center p-2">
                            <h4>No Records Found</h4>
                        </td>
                    </tr>
                    <?php
                    }
                    ?>
                        

                        <script>
                        function toggleEditSave(index) {
                        // Revert all rows to original state
                        $('[id^="myEdit"] .edit').removeClass('d-none');
                        $('[id^="myEdit"] .save').addClass('d-none');
                        $('[id^="myEdit"] span').removeClass('d-none');
                        $('[id^="myEdit"] input').addClass('d-none');

                        // Toggle visibility of edit and save buttons for the clicked row
                        $('#myEdit' + index + ' .edit').toggleClass('d-none');
                        $('#myEdit' + index + ' .save').toggleClass('d-none');

                        // Toggle visibility of span and input for the clicked row
                        $('#myEdit' + index + ' span').toggleClass('d-none');
                        $('#myEdit' + index + ' input').toggleClass('d-none');
                        }

                        </script>

                        </tbody>
                        </table>
                </div> 
               
            </div>
           
        </div>
                            <!-- end col -->
 </div>
</div>