<div class="container-fluid">
	<div class="row">
	<div class="row">
	<div class="col-xl-12">
	    <div class="card">
	        <div class="card-body">
	            <h5 class="card-title">Select State</h5>
	            <form action="<?=base_url()?>admin/update_district" method="post" enctype="multipart/form-data">
	            	<input type="hidden" name="district_id" value="<?=$det[0]['district_id']?>">
	            <div class="row">
	                <div class="col-md-6 mb-3">
	                    <label for="floatingnameInput">State Name</label>
	                    <select class="form-control" name="state_id" required>
	                    	<option value="" disabled selected>Select State</option>
	                    	<?php 
	                    		foreach($state as $row)
	                    		{
	                    			?>
	                    			<option <?php if($row['state_id']==$det[0]['state_id']){echo 'selected';} ?> value="<?=$row['state_id']?>"><?=$row['state_name']?></option>
	                    			<?php
	                    		}
	                    	?>
	                    </select>
	                </div>
	                <div class="col-md-6 mb-3">
	                	<label>District Name</label>
	                	<input type="text" value="<?=$det[0]['district_name']?>" name="district_name" placeholder="Enter District Name" class="form-control" required>
	                </div>
	                <div class="text-center">
	                    <button type="submit" class="btn btn-primary w-md">SAVE</button>
	                </div>
	        </div>
	            </form>
	        </div>
	    </div>
	</div>
	</div>
	</div>
</div>