<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin2 extends CI_Controller {

	public function __construct() 
	{
		parent::__construct();
		$this->load->model('My_model');
		// error_reporting(0);
		// array_multisort(array_column($members, 'member_name'), SORT_ASC, $members);
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->helper('helper1');
		// $this->load->helper('mail');
 		$this->load->library('form_validation');
		$this->load->library('session');
    	$config['upload_path']= './uploads/';
    	$config['allowed_types'] = 'gif|jpg|png|jpeg';
    	$this->load->library('upload', $config);
    	date_default_timezone_set('Asia/Kolkata');
    	if(!isset($_SESSION['admin_id']))
    	{
    		redirect(base_url().'login','refresh');
    	}
    }

     	function upload_img($imgname,$imgtemp,$path="uploads/")
 	{
        $fname=time().rand(00000000,99999999).".".explode(".",$imgname)[count(explode(".",$imgname))-1];
        $path1=$path.$fname;
        move_uploaded_file($imgtemp,$path1);
        return $fname;
    }
    
	public function head()
	{
        $data['company_det']=$this->My_model->select_where("company_details_tbl",['status'=>'active']);

		$this->load->view("admin/head",$data);
	}
	public function nav()
	{
		$data['company_det']=$this->My_model->select_where("company_details_tbl",['status'=>'active']);

		$data['admin_det']=$this->My_model->select_where("admin_tbl",['admin_tbl_id'=>$_SESSION['admin_id']])[0];
		$data['system_not']=$this->db->query("SELECT * FROM system_notification ORDER BY system_notification_id DESC limit 20")->result_array();
		$this->load->view("admin/nav",$data);
	}
	public function footer()
	{
        $data['company_det']=$this->My_model->select_where("company_details_tbl",['company_det_id'=>'1'])[0];
		$this->load->view("admin/footer",$data);
	}

	public function about(){
		$this->head();
		$this->nav();
		$data['about_company']=$this->My_model->select_where('about_tbl',['status' =>'active']);
		$this->load->view('admin/about',$data);
		$this->footer();
	}

	public function add_about(){
		$about=$this->My_model->select_where('about_tbl',array('status'=>'active','title'=>$_POST['title']));
		if (isset($about[0])) {
			$this->ci_flashdata('Danger','This Offer Allready Exit..',"yes");
			redirect('admin/about','refresh');
		}
		else{
			if($_FILES['about_image']['name']!="")
			{
				$imgname=$_FILES['about_image']['name'];
				$imgtemp=$_FILES['about_image']['tmp_name'];
				$path="uploads/";
				$_POST['about_image']=$this->upload_img($imgname,$imgtemp,$path);
			}
			
			$_POST['status']="active";
			$_POST['entry_by']=$_SESSION['admin_id'];
			$_POST['entry_time']=time();
			$this->My_model->insert("about_tbl",$_POST);
			$this->ci_flashdata('Success','About Company Details Added Successfully..',"yes");
			redirect('admin/about','refresh');	
		}
	}

	public function ov($page,$data="")
	{
		$this->head();
		$this->nav();
		$this->load->view("admin/".$page,$data);
		$this->footer();
	}

	public function edit_company($ab_id)
	{
		$this->head();
		$this->nav();
		$data['about_det']=$this->My_model->select_where("about_tbl",['about_tbl_id'=>$ab_id]);
		$this->load->view("admin/about",$data);
		$this->footer();
	}
	public function update_details(){

		if($_FILES['about_image']['name']!="")
		{
			$imgname=$_FILES['about_image']['name'];
			$imgtemp=$_FILES['about_image']['tmp_name'];
			$path="uploads/";
			$_POST['about_image']=$this->upload_img($imgname,$imgtemp,$path);
			$path1="uploads/".$_POST['about_image1'];
			unlink($path1);
		}
		else{
			$_POST['about_image']=$_POST['about_image1'];
		}
		
		unset($_POST['about_image1']);

		$this->My_model->update("about_tbl",['about_tbl_id'=> $_POST['about_tbl_id']],$_POST);
		// $this->ci_flashdata('Success','Details Updated Successfully..',"yes");
		redirect('admin2/about','refresh');
	}
	public function service(){
		$this->head();
		$this->nav();
		$data['service_company']=$this->My_model->select_where('service_tbl',['status' =>'active']);
		$this->load->view('admin/service',$data);
		$this->footer();
	}

	public function add_service(){
		$service=$this->My_model->select_where('service_tbl',array('status'=>'active','title'=>$_POST['title']));
		if (isset($service[0])) {
			$this->ci_flashdata('Danger','This Offer Allready Exit..',"yes");
			redirect('admin2/service','refresh');
		}
		else{
			if($_FILES['service_image']['name']!="")
			{
				$imgname=$_FILES['service_image']['name'];
				$imgtemp=$_FILES['service_image']['tmp_name'];
				$path="uploads/";
				$_POST['service_image']=$this->upload_img($imgname,$imgtemp,$path);
			}
			
			$_POST['status']="active";
			$_POST['entry_by']=$_SESSION['admin_id'];
			$_POST['entry_time']=time();
			$this->My_model->insert("service_tbl",$_POST);
			// $this->ci_flashdata('Success','service Company Details Added Successfully..',"yes");
			redirect('admin2/service','refresh');	
		}
	}
	public function edit_service($ab_id)
	{
		$this->head();
		$this->nav();
		$data['service_det']=$this->My_model->select_where("service_tbl",['service_tbl_id'=>$ab_id]);
		$this->load->view("admin/service",$data);
		$this->footer();
	}

	public function delete_service($id)
	{
		$this->My_model->update("service_tbl",['service_tbl_id'=> $id],['status'=>'deleted']);
		redirect('admin2/service','refresh');
		
	}

	public function update_service(){

		if($_FILES['service_image']['name']!="")
		{
			$imgname=$_FILES['service_image']['name'];
			$imgtemp=$_FILES['service_image']['tmp_name'];
			$path="uploads/";
			$_POST['service_image']=$this->upload_img($imgname,$imgtemp,$path);
			$path1="uploads/".$_POST['service_image1'];
			unlink($path1);
		}
		else{
			$_POST['service_image']=$_POST['service_image1'];
		}
		
		unset($_POST['service_image1']);

		$this->My_model->update("service_tbl",['service_tbl_id'=> $_POST['service_tbl_id']],$_POST);
		// $this->ci_flashdata('Success','Details Updated Successfully..',"yes");
		redirect('admin2/service','refresh');
	}   
	// Blogs
	public function blogs(){
		$this->head();
		$this->nav();
		$data['blogs']=$this->My_model->select_where('blog_tbl',['status' =>'active']);
		$this->load->view('admin/blogs',$data);
		$this->footer();
	}

	public function add_blog(){
		$blog=$this->My_model->select_where('blog_tbl',array('status'=>'active','title'=>$_POST['title']));
		if (isset($blog[0])) {
			$this->ci_flashdata('Danger','This Offer Allready Exit..',"yes");
			redirect('admin2/blogs','refresh');
		}
		else{
			if($_FILES['blog_image']['name']!="")
			{
				$imgname=$_FILES['blog_image']['name'];
				$imgtemp=$_FILES['blog_image']['tmp_name'];
				$path="uploads/";
				$_POST['blog_image']=$this->upload_img($imgname,$imgtemp,$path);
			}
			
			$_POST['status']="active";
			$_POST['entry_by']=$_SESSION['admin_id'];
			$_POST['entry_time']=time();
			$this->My_model->insert("blog_tbl",$_POST);
			// $this->ci_flashdata('Success','blog Company Details Added Successfully..',"yes");
			redirect('admin2/blogs','refresh');	
		}
	}
	public function edit_blog($ab_id)
	{
		$this->head();
		$this->nav();
		$data['blog_det']=$this->My_model->select_where("blog_tbl",['blog_tbl_id'=>$ab_id]);
		$this->load->view("admin/blogs",$data);
		$this->footer();
	}

	public function delete_blog($id)
	{
		$this->My_model->update("blog_tbl",['blog_tbl_id'=> $id],['status'=>'deleted']);
		redirect('admin2/blogs','refresh');
		
	}

	public function update_blog(){

		if($_FILES['blog_image']['name']!="")
		{
			$imgname=$_FILES['blog_image']['name'];
			$imgtemp=$_FILES['blog_image']['tmp_name'];
			$path="uploads/";
			$_POST['blog_image']=$this->upload_img($imgname,$imgtemp,$path);
			$path1="uploads/".$_POST['blog_image1'];
			unlink($path1);
		}
		else{
			$_POST['blog_image']=$_POST['blog_image1'];
		}
		
		unset($_POST['blog_image1']);

		$this->My_model->update("blog_tbl",['blog_tbl_id'=> $_POST['blog_tbl_id']],$_POST);
		// $this->ci_flashdata('Success','Details Updated Successfully..',"yes");
		redirect('admin2/blogs','refresh');
	}   





	// 02 APR MANOJ MORE 

	public function delete_job_type($id)
	{
		$data=$this->My_model->update("job_position_tbl",['job_position_tbl_id'=>$id],['status'=>'deleted']);
		
		if($data)
		{
			redirect('admin/job_position','refresh');
		}
		else{
			redirect('admin/job_position','refresh');
		}
	}

	public function raw_product()
	{
		$this->head();
		$this->nav();
		$data['units']=$this->My_model->select_where("unit_tbl",['status'=>'active']);
		$page_no=1;
        $search="";
        extract($_GET);
        if(!isset($_GET['q']))
        {
            $show=" ";
        }
        else
        {
            $show=" AND (
                (raw_materials.raw_materials_name LIKE '%".$_GET['q']."%') 
                OR (unit_tbl.unit_name LIKE '%".$_GET['q']."%')
            )";
        }
         $total_rows = $this->db->query("SELECT count(raw_materials.raw_materials_id) as ttl_rows FROM raw_materials,unit_tbl WHERE raw_materials.status='active' AND raw_materials.unit_id=unit_tbl.unit_tbl_id ".$show)->result_array()[0]['ttl_rows'];

        $per_page = 20;
        $data['start']=$per_page*$page_no-$per_page;
        $data['ttl_pages']=$total_rows/$per_page;
        $data['page_no']=$page_no;

        $data['list'] = $this->db->query("SELECT * FROM raw_materials,unit_tbl WHERE raw_materials.status='active' AND raw_materials.unit_id=unit_tbl.unit_tbl_id ".$show." ORDER BY raw_materials.raw_materials_id DESC limit ".$data['start'].",".$per_page)->result_array();

		$this->load->view("admin/raw_material",$data);
		$this->footer();
	}

	public function save_raw_material()
	{

		$_POST['added_by'] = 'admin';
	    $_POST['entry_time'] = time();
	    $_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['status'] = 'active';
		$data=$this->My_model->insert("raw_materials",$_POST);
		if($data)
		{
			redirect('admin2/raw_product','refresh');
		}
		else{
			redirect('admin2/raw_product','refresh');
		}
	}

	public function edit_product_cat()
	{
		$data=$this->My_model->update("raw_materials",['raw_materials_id'=>$_POST['raw_materials_id']],$_POST);
		if($data)
		{
			redirect('admin2/raw_product','refresh');
		}
		else{
			redirect('admin2/raw_product','refresh');
		}
	}
	public function delete_product_cat($id)
	{
		$data=$this->My_model->update("raw_materials",['raw_materials_id'=>$id],['status'=>'deleted']);
		
		if($data)
		{
			redirect('admin2/raw_product','refresh');
		}
		else{
			redirect('admin2/raw_product','refresh');
		}
	}


	public function edit_Inventory($plant_id,$inv_id)
	{
		$this->head();
		$this->nav();
		$data['plant_list']=$this->My_model->select_where("plant_tbl",['status'=>'active']);
		
		$data['det']=$this->My_model->select_where("inventory_tbl",['plant_id'=>$plant_id,'inventory_tbl_id'=>$inv_id]);
		// echo "<pre>";
		// print_r($data['det']);	
		$this->load->view('admin/inventory',$data);
		$this->footer();
	}


	public function update_Inventory()
	{

		if($_FILES['inventory_img']['name']!="")
		{
			$imgname=$_FILES['inventory_img']['name'];
			$imgtemp=$_FILES['inventory_img']['tmp_name'];
			$path="uploads/";
			$_POST['inventory_img']=$this->upload_img($imgname,$imgtemp,$path);
			$path1="uploads/".$_POST['inventory_img1'];
			unlink($path1);
		}
		else{
			$_POST['inventory_img']=$_POST['inventory_img1'];
		}
		
		unset($_POST['inventory_img1']);

		$data=$this->My_model->update("inventory_tbl",['inventory_tbl_id'=>$_POST['inventory_tbl_id']],$_POST);
		if($data)
		{
			redirect('admin/inventory_list','refresh');
		}
		else{
			redirect('admin/inventory_list','refresh');
		}
	}


	public function delete_Inventory($plant_id,$inventory_tbl_id)
	{
		$data=$this->My_model->update("inventory_tbl",['plant_id'=>$plant_id,'inventory_tbl_id'=>$inventory_tbl_id],['status'=>'deleted']);
		if($data)
		{
			redirect('admin/inventory_list','refresh');
		}
		else{
			redirect('admin/inventory_list','refresh');
		}
	}


	// 03 APR M.M 

	public function edit_farmer($id)
	{
		$data['emp_list'] = $this->My_model->select_where("supplier_tbl",['status'=>'active']);
		$data['prod_cat_list'] = $this->My_model->select_where("raw_materials",['status'=>'active']);
		$data['farmers_det'] = $this->My_model->select_where("farmer_tbl",['farmer_tbl_id'=>$id,'status'=>'active']);
		$this->ov('farmer',$data);
	}


	public function update_farmers()
	{
		$farmer_tbl_id = $_POST['farmer_tbl_id'];

		
		$data=$this->My_model->update("farmer_tbl",['farmer_tbl_id'=>$farmer_tbl_id],$_POST);
		if($data)
		{
			redirect('admin/farmer_list','refresh');
		}
		else{
			redirect('admin/farmer_list','refresh');
		}
	}


	public function delete_farmer($id)
	{
		$data=$this->My_model->update("farmer_tbl",['farmer_tbl_id'=>$id],['status'=>'deleted']);
		if($data)
		{
			redirect('admin/farmer_list','refresh');
		}
		else{
			redirect('admin/farmer_list','refresh');
		}
	}


	public function vehicle_type()
	{
		$data['vehicle_type_list']=$this->My_model->select_where("vehicle_type",['status'=>'active']);
		$this->ov("vehicle_type",$data);
	}

	public function save_vehicle_type()
	{

		$_POST['added_by'] = 'admin';
	    $_POST['entry_time'] = time();
	    $_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['status'] = 'active';
		$data=$this->My_model->insert("vehicle_type",$_POST);
		if($data)
		{
			redirect('admin2/vehicle_type','refresh');
		}
		else{
			redirect('admin2/vehicle_type','refresh');
		}
	}

	public function update_vehicle_type()
	{
		$data=$this->My_model->update("vehicle_type",['vehicle_type_id'=>$_POST['vehicle_type_id']],$_POST);
		if($data)
		{
			redirect('admin2/vehicle_type','refresh');
		}
		else{
			redirect('admin2/vehicle_type','refresh');
		}
	}

	public function delete_vehicle_type($id)
	{
		$data=$this->My_model->update("vehicle_type",['vehicle_type_id'=>$id],['status'=>'deleted']);
		
		if($data)
		{
			redirect('admin2/vehicle_type','refresh');
		}
		else{
			redirect('admin2/vehicle_type','refresh');
		}
	}


	public function fueling_type()
	{
		$data['fueling_type_list']=$this->My_model->select_where("fueling_type",['status'=>'active']);
		$this->ov("fueling_type",$data);
	}

	public function save_fueling_type()
	{

		$_POST['added_by'] = 'admin';
	    $_POST['entry_time'] = time();
	    $_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['status'] = 'active';
		$data=$this->My_model->insert("fueling_type",$_POST);
		if($data)
		{
			redirect('admin2/fueling_type','refresh');
		}
		else{
			redirect('admin2/fueling_type','refresh');
		}
	}

	public function update_fueling_type()
	{
		$data=$this->My_model->update("fueling_type",['fueling_type_id'=>$_POST['fueling_type_id']],$_POST);
		if($data)
		{
			redirect('admin2/fueling_type','refresh');
		}
		else{
			redirect('admin2/fueling_type','refresh');
		}
	}

	public function delete_fueling_type($id)
	{
		$data = $this->My_model->update("fueling_type",['fueling_type_id'=>$id],['status'=>'deleted']);
		
		if($data)
		{
			redirect('admin2/fueling_type','refresh');
		}
		else{
			redirect('admin2/fueling_type','refresh');
		}
	}

	public function vehicle_list()
	{
		
		$page_no=1;
        $search="";
        extract($_GET);
        if(!isset($_GET['q']))
        {
            $show=" ";
        }
        else
        {
            $show=" AND (
                (vehicle_no LIKE '%".$_GET['q']."%') 
                OR (owner_name LIKE '%".$_GET['q']."%')
                OR (owner_mobile_no LIKE '%".$_GET['q']."%')
                OR (vehicle_modal LIKE '%".$_GET['q']."%')
                OR (modal_no LIKE '%".$_GET['q']."%')
                OR (modal_date LIKE '%".$_GET['q']."%')
                OR (machine_no LIKE '%".$_GET['q']."%')
                OR (chassi_no LIKE '%".$_GET['q']."%')
                OR (puc_no LIKE '%".$_GET['q']."%')
            )";
        }
         $total_rows = $this->db->query("SELECT count(vehicle_tbl_id) as ttl_rows FROM vehicle_tbl WHERE status='active'  ".$show)->result_array()[0]['ttl_rows'];

        $per_page = 20;
        $data['start']=$per_page*$page_no-$per_page;
        $data['ttl_pages']=$total_rows/$per_page;
        $data['page_no']=$page_no;

        $data['list'] = $this->db->query("SELECT * FROM vehicle_tbl WHERE status='active' ".$show." ORDER BY vehicle_tbl_id DESC limit ".$data['start'].",".$per_page)->result_array();
		$this->ov('vehicle',$data);
	}

	public function edit_vehicle_detail($id)
	{
		$data['vehicle_type_list'] = $this->My_model->select_where('vehicle_type',['status'=>'active']); 
		$data['fueling_type_list'] = $this->My_model->select_where('fueling_type',['status'=>'active']);
		$data['plant_list']=$this->My_model->select_where("plant_tbl",['status'=>'active']);
		$data['vehicle_detail']=$this->My_model->select_where("vehicle_tbl",['vehicle_tbl_id'=>$id,'status'=>'active']);
		$this->ov('vehicle',$data);
	}

	public function update_vehicle_detail()
	{
		// echo "<pre>";
		// print_r($_POST);

		if($_FILES['vehicle_image']['name']!="")
		{
			$imgname=$_FILES['vehicle_image']['name'];
			$imgtemp=$_FILES['vehicle_image']['tmp_name'];
			$path="uploads/";
			$_POST['vehicle_image']=$this->upload_img($imgname,$imgtemp,$path);
			$path1="uploads/".$_POST['vehicle_image1'];
			unlink($path1);
		}
		else{
			$_POST['vehicle_image']=$_POST['vehicle_image1'];
		}
		
		unset($_POST['vehicle_image1']);

		$data=$this->My_model->update("vehicle_tbl",['vehicle_tbl_id'=>$_POST['vehicle_tbl_id']],$_POST);
		if($data)
		{
			redirect('admin/vehicle/','refresh');
		}
		else{
			redirect('admin/vehicle/','refresh');
		}
	}


	public function delete_vehicle($id)
	{
		$data = $this->My_model->update("vehicle_tbl",['vehicle_tbl_id'=>$id],['status'=>'deleted']);
		
		if($data)
		{
			redirect('admin2/vehicle_list','refresh');
		}	
		else{
			redirect('admin2/vehicle_list','refresh');
		}
	}

	public function unit()
	{
		// $data['list'] = $this->My_model->select_where("vehicle_tbl",['status'=>'active']);

		$data['unit_list']=$this->My_model->select_where("unit_tbl",['status'=>'active']);
		$this->ov("unit",$data);
	}

	public function save_unit()
	{
		$_POST['added_by'] = 'admin';
	    $_POST['entry_time'] = time();
	    $_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['status'] = 'active';
		$data=$this->My_model->insert("unit_tbl",$_POST);
		if($data)
		{
			redirect('admin2/unit','refresh');
		}
		else{
			redirect('admin2/unit','refresh');
		}
	}

	public function update_unit()
	{
		$data=$this->My_model->update("unit_tbl",['unit_tbl_id'=>$_POST['unit_tbl_id']],$_POST);
		if($data)
		{
			redirect('admin2/unit','refresh');
		}
		else{
			redirect('admin2/unit','refresh');
		}
	}

	public function delete_unit($id)
	{
		$data = $this->My_model->update("unit_tbl",['unit_tbl_id'=>$id],['status'=>'deleted']);
		
		if($data)
		{
			redirect('admin2/unit','refresh');
		}
		else{
			redirect('admin2/unit','refresh');
		}
	}

	public function edit_driver($id)
	{
		$data['vehicle_type_list'] = $this->My_model->select_where('vehicle_type',['status'=>'active']); 
		$data['fueling_type_list'] = $this->My_model->select_where('fueling_type',['status'=>'active']);
		$data['plant_list']=$this->My_model->select_where("plant_tbl",['status'=>'active']);
		$data['driver_detail']=$this->My_model->select_where("driver_tbl",['driver_tbl_id'=>$id,'status'=>'active']);

		$this->ov('driver',$data);
	}

	public function update_driver_details()
	{
		// echo "<pre>";
		// print_r($_POST);
		// print_r($_FILES);
		if($_FILES['driver_image']['name']!="")
		{
			$imgname=$_FILES['driver_image']['name'];
			$imgtemp=$_FILES['driver_image']['tmp_name'];
			$path="uploads/";
			$_POST['driver_image']=$this->upload_img($imgname,$imgtemp,$path);
			$path1="uploads/".$_POST['driver_image1'];
			unlink($path1);
		}
		else{
			$_POST['driver_image']=$_POST['driver_image1'];
		}
		
		unset($_POST['driver_image1']);

		if($_FILES['driver_aadhaar_image']['name']!="")
		{
			$imgname=$_FILES['driver_aadhaar_image']['name'];
			$imgtemp=$_FILES['driver_aadhaar_image']['tmp_name'];
			$path="uploads/";
			$_POST['driver_aadhaar_image']=$this->upload_img($imgname,$imgtemp,$path);
			$path1="uploads/".$_POST['driver_aadhaar_image1'];
			unlink($path1);
		}
		else{
			$_POST['driver_aadhaar_image']=$_POST['driver_aadhaar_image1'];
		}
		
		unset($_POST['driver_aadhaar_image1']);

		if($_FILES['driver_license_image']['name']!="")
		{
			$imgname=$_FILES['driver_license_image']['name'];
			$imgtemp=$_FILES['driver_license_image']['tmp_name'];
			$path="uploads/";
			$_POST['driver_license_image']=$this->upload_img($imgname,$imgtemp,$path);
			$path1="uploads/".$_POST['driver_license_image1'];
			unlink($path1);
		}
		else{
			$_POST['driver_license_image']=$_POST['driver_license_image1'];
		}
		
		unset($_POST['driver_license_image1']);



		$data=$this->My_model->update("driver_tbl",['driver_tbl_id'=>$_POST['driver_tbl_id']],$_POST);
		if($data)
		{
			redirect('admin/driver_list','refresh');
		}
		else{
			redirect('admin/driver_list','refresh');
		}
	}

	public function delete_driver($id)
	{
		$data=$this->My_model->update("driver_tbl",['driver_tbl_id'=>$id],['status'=>'deleted']);
		if($data)
		{
			redirect('admin/driver_list','refresh');
		}
		else{
			redirect('admin/driver_list','refresh');
		}
	}
	public function edit_asset($id)
	{
		$data['det'] = $this->db->query("SELECT * FROM plant_tbl,asset_maintenance, asset_tbl WHERE  asset_tbl.plant_id = plant_tbl.plant_tbl_id AND asset_maintenance.asset_id = asset_tbl.asset_tbl_id AND asset_tbl.status='active' AND asset_tbl.asset_tbl_id='".$id."' ")->result_array();
		$this->ov("asset_list",$data);
	}

	public function save_edit_maintenance()
	{
	
		$data = $this->My_model->update("asset_tbl",['asset_tbl_id'=>$_POST['asset_tbl_id']],$_POST);
		if($data)
		{
			redirect('admin2/asset_list','refresh');
		}
		else{
			redirect('admin2/asset_list','refresh');
		}
	}
	public function delete_asset($id)
	{
		$data = $this->My_model->update("asset_tbl",['asset_tbl_id'=>$id],['status'=>'deleted']);
		if($data)
		{
			redirect('admin2/asset_list','refresh');
		}
		else{
			redirect('admin2/asset_list','refresh');
		}
	}

}