<?php
defined('BASEPATH') or exit('No direct script access allowed');

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Font;
use PhpOffice\PhpSpreadsheet\Style\Fill;

class Admin extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('My_model');
		// error_reporting(0);
		// array_multisort(array_column($members, 'member_name'), SORT_ASC, $members);
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->helper('helper1');
		$this->load->helper('helper_helper');
		// $this->load->helper('mail');
		$this->load->library('form_validation');
		$this->load->library('session');
		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = 'gif|jpg|png|jpeg';
		$this->load->library('upload', $config);

		$this->load->config('navbar_urls');
		$this->navbar = $this->config->item('navbar');

		$this->check_permissions();
		date_default_timezone_set('Asia/Kolkata');
		if (!isset($_SESSION['admin_id'])) {
			redirect(base_url() . 'login', 'refresh');
		}
	}
	protected function update_products_stock($product_id, $plant_id, $stock, $reason)
	{
		$plant_products = $this->My_model->select_where("plant_products", ["product_id" => $product_id, "plant_id" => $plant_id]);
		if (isset($plant_products[0])) {
			$plant_products_id = $plant_products[0]['plant_products_id'];

			$new_stock = $plant_products[0]['stock'] + $stock;

			$this->My_model->update("plant_products", ["plant_products_id" => $plant_products_id], ["stock" => $new_stock]);

			$product_stock_history = [
				"plant_products_id" => $plant_products_id,
				"product_id" => $product_id,
				"plant_id" => $plant_id,
				"stock" => $stock,
				"reason" => $reason,
				"date" => date('Y-m-d'),
				"time" => date('H:iA'),
				"entry_by" => "admin"
			];

			$this->My_model->insert("product_stock_history", $product_stock_history);
		}
	}
	private function check_permissions()
	{
		// admin_navbar
		$current_method = $this->router->fetch_method();
		$permission = false;
		$url_match = false;

		$all_urls = $this->My_model->select_where("admin_permission_urls", ["status" => "active"]);
		$all_urls = array_column($all_urls, "admin_permission_url");
		$_SESSION['admin_position_id'] = isset($_SESSION['admin_position_id']) ? $_SESSION['admin_position_id'] : 0;
		if (isset($_SESSION['admin_position_id'])) {
			if (in_array($current_method, $all_urls)) {
				$url_match = true;
				$permission = $this->db->query("SELECT * FROM admin_permission_urls,admin_permission,admin_position WHERE admin_permission_urls.admin_permission_urls_id = admin_permission.admin_permission_urls_id AND admin_position.admin_position_id = admin_permission.admin_position_id AND admin_permission_urls.admin_permission_url = '$current_method' AND admin_permission_urls.status = 'active' AND admin_position.status = 'active' AND admin_position.admin_position_id = '" . $_SESSION['admin_position_id'] . "'")->result_array();
				if (isset($permission[0])) {
					$permission = true;
				}
			}

			if (!$permission && $url_match) {
				redirect(base_url() . 'login/logout');

				// show_error('You do not have permission to access this page <a href="' . base_url() . 'login/logout">Login Again</a>', 403, 'Forbidden');
			}
		} else {
			redirect(base_url() . 'login/logout');
		}
	}
	public function admin()
	{
		$data['positions'] = $this->My_model->select_where("admin_position", ['status' => 'active']);
		$data['admin_data'] = $this->My_model->select_where("admin_tbl", ['status' => 'active']);
		$this->ov("admin", $data);
	}
	public function add_admin()
	{
		$mobile = $this->input->post('admin_mobile_no');
		$password = $this->input->post('admin_password');
		$existingAdmin = $this->My_model->select_where("admin_tbl", ['admin_mobile_no' => $mobile]);
		$existingpassword = $this->My_model->select_where("admin_tbl", ['admin_password' => $password]);
		if (!empty($existingAdmin)) {
			redirect('admin/admin');
			return;
		}

		if ($_FILES['admin_profile_logo']['name'] != "") {
			$imgname = $_FILES['admin_profile_logo']['name'];
			$imgtemp = $_FILES['admin_profile_logo']['tmp_name'];
			$path = "uploads/";
			$_POST['admin_profile_logo'] = $this->upload_img($imgname, $imgtemp, $path);
		}
		// Proceed to save the new admin
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['entry_time'] = time();
		$_POST['last_modified_date'] = date('Y-m-d');
		$_POST['status'] = 'active';
		// print_r($_POST);
		// exit;
		$this->My_model->insert("admin_tbl", $_POST);
		redirect('admin/admin');
	}

	public function admin_list()
	{
		$this->head();
		$this->nav();
		$data['admin_data'] = $this->My_model->select_where("admin_tbl", ['status' => 'active']);
		$this->load->view("admin/admin_list", $data);
		$this->footer();
	}
	public function edit_admin($admin_id)
	{

		$data['positions'] = $this->My_model->select_where("admin_position", ['status' => 'active']);
		$data['admin_det'] = $this->My_model->select_where("admin_tbl", ['admin_tbl_id' => $admin_id, 'status' => 'active'])[0];
		$this->ov("edit_admin", $data);
	}
	public function update_admin()
	{
		if ($_FILES['admin_profile_logo']['name'] != "") {
			$imgname = $_FILES['admin_profile_logo']['name'];
			$imgtemp = $_FILES['admin_profile_logo']['tmp_name'];
			$path = "uploads/";
			$_POST['admin_profile_logo'] = $this->upload_img($imgname, $imgtemp, $path);
		} else {

			$_POST['admin_profile_logo'] = $_POST['admin_profile_logo1'];
		}
		unset($_POST['admin_profile_logo1']);

		$this->My_model->update("admin_tbl", ['admin_tbl_id' => $_POST['admin_tbl_id']], $_POST);

		redirect('admin/admin');
	}
	public function delete_admin($admin_id)
	{
		$this->My_model->update("admin_tbl", ["admin_tbl_id" => $admin_id], ['status' => 'deleted']);

		redirect('admin/admin');
	}

	public function admin_position()
	{
		$data["positions"] = $this->My_model->select_where("admin_position", ["status" => "active"]);
		$this->ov("admin_position", $data);
	}
	public function save_admin_position()
	{
		$_POST['entry_time'] = time();
		$_POST['entry_date'] = date('Y-m-d');
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['status'] = 'active';
		$this->My_model->insert("admin_position", $_POST);
		redirect(base_url() . "admin/admin_position");
	}
	public function delete_position($admin_position_id)
	{
		$this->My_model->update("admin_position", ["admin_position_id" => $admin_position_id], ["status" => "deleted"]);
		redirect(base_url() . "admin/admin_position");
	}

	public function edit_position($id)
	{
		$data['position_det'] = $this->My_model->select_where("admin_position", ["admin_position_id" => $id]);
		redirect(base_url() . "admin/admin_position");
	}


	// admin_permission_url
	public function admin_permission_url()
	{
		$page_no = 1;
		$search = " ";
		extract($_GET);
		if (!isset($_GET['q'])) {
			$show = "";
		} else {
			$show = " AND (
            (customer_name LIKE '%" . $_GET['q'] . "%') 
        )";
		}

		$total_rows = $this->db->query("SELECT count(admin_permission_urls_id) as ttl_rows FROM admin_permission_urls WHERE status='active' " . $show)->result_array()[0]['ttl_rows'];
		$per_page = 20;
		$data['start'] = $per_page * $page_no - $per_page;
		$data['ttl_pages'] = $total_rows / $per_page;
		$data['page_no'] = $page_no;
		$data['permission_urls'] = $this->db->query("SELECT * FROM admin_permission_urls WHERE status='active' " . $show . " ORDER BY admin_permission_urls_id DESC limit " . $data['start'] . "," . $per_page)->result_array();

		$this->ov('admin_permission_url', $data);
	}
	public function save_admin_permission_url()
	{

		if (!isset($this->My_model->select_where("admin_permission_urls", $_POST)[0])) {
			$_POST['entry_time'] = time();
			$_POST['entry_date'] = date('Y-m-d');
			$_POST['entry_by'] = $_SESSION['admin_id'];
			$_POST['status'] = 'active';
			$this->My_model->insert("admin_permission_urls", $_POST);
		}
		redirect(base_url() . "admin/admin_permission_url");
	}
	public function delete_permission_url($admin_permission_url_id)
	{
		$this->My_model->update("admin_permission_urls", ["admin_permission_urls_id" => $admin_permission_url_id], ["status" => "deleted"]);
		redirect(base_url() . "admin/admin_permission_url");
	}
	public function permission_setup()
	{
		$data["permission_urls"] = $this->My_model->select_where_order("admin_permission_urls", ["status" => "active"], 'admin_permission_urls_id', 'DESC');
		$data["positions"] = $this->My_model->select_where("admin_position", ["status" => "active"]);
		$this->ov("permission_setup", $data);
	}
	public function set_admin_permission()
	{
		if (!isset($this->My_model->select_where("admin_permission", $_POST)[0])) {
			$_POST['entry_time'] = time();
			$_POST['entry_date'] = date('Y-m-d');
			$_POST['entry_by'] = $_SESSION['admin_id'];
			$this->My_model->insert("admin_permission", $_POST);
		}
	}
	public function remove_admin_permission()
	{
		$this->My_model->delthis("admin_permission", $_POST);
	}


	function upload_img($imgname, $imgtemp, $path = "uploads/")
	{
		$fname = time() . rand(00000000, 99999999) . "." . explode(".", $imgname)[count(explode(".", $imgname)) - 1];
		$path1 = $path . $fname;
		move_uploaded_file($imgtemp, $path1);
		return $fname;
	}
	public function ov($page, $data = "")
	{
		$this->head();
		$this->nav();
		$this->load->view("admin/" . $page, $data);
		$this->footer();
	}
	public function head()
	{
		$data['company_det'] = $this->My_model->select_where("company_details_tbl", ['status' => 'active']);
		$data['admin_det'] = $this->My_model->select_where("admin_tbl", ['admin_tbl_id' => $_SESSION['admin_id']]);

		$this->load->view("admin/head", $data);
	}
	public function nav()
	{
		$data['company_det'] = $this->My_model->select_where("company_details_tbl", ['status' => 'active']);

		$data['admin_det'] = $this->My_model->select_where("admin_tbl", ['admin_tbl_id' => $_SESSION['admin_id']]);
		$data['system_not'] = $this->db->query("SELECT * FROM system_notification ORDER BY system_notification_id DESC limit 20")->result_array();
		$this->load->view("admin/nav", $data);
	}
	public function topnav()
	{
		$data['company_det'] = $this->My_model->select_where("company_details_tbl", ['status' => 'active']);
		$data['admin_det'] = $this->My_model->select_where("admin_tbl", ['admin_tbl_id' => $_SESSION['admin_id']])[0];
		$data['system_not'] = $this->db->query("SELECT * FROM system_notification ORDER BY system_notification_id DESC limit 20")->result_array();
		$this->load->view("admin/topnav", $data);
	}
	public function footer()
	{
		$data['company_det'] = $this->My_model->select_where("company_details_tbl", ['company_det_id' => '1'])[0];
		$this->load->view("admin/footer", $data);
	}
	public function index()
	{
		$data['company_det'] = $this->My_model->select_where("company_details_tbl", ['company_det_id' => '1'])[0];
		// Dashboard Statistics
		$data['total_available'] = $this->My_model->count_where('numbers_tbl', ['product_status' => 'Available', 'status' => 'active']);
		$data['total_sold'] = $this->My_model->count_where('numbers_tbl', ['product_status' => 'Sold', 'status' => 'active']);
		$data['today_sales'] = $this->My_model->count_where('numbers_tbl', ['product_status' => 'Sold', 'sold_date' => date('Y-m-d'), 'status' => 'active']);

		// Monthly Revenue
		$currentMonth = date('Y-m');
		$monthlyRevenue = $this->db->query("SELECT SUM(price) as total FROM numbers_tbl WHERE product_status = 'Sold' AND status='active' AND DATE_FORMAT(STR_TO_DATE(sold_date, '%Y-%m-%d'), '%Y-%m') = '$currentMonth'")->row();
		$data['monthly_revenue'] = $monthlyRevenue->total ?? 0;

		// Recent Sales
		$data['recent_sales'] = $this->db->query("SELECT * FROM numbers_tbl WHERE status = 'active' ORDER BY numbers_tbl_id DESC LIMIT 10")->result_array();
		// Chart Data - Last 7 days
		$data['daily_labels'] = [];
		$data['daily_sales'] = [];
		$data['daily_sales_entry'] = [];
		for ($i = 6; $i >= 0; $i--) {
			$date = date('Y-m-d', strtotime("-$i days"));
			$data['daily_labels'][] = date('M j', strtotime($date));

			// Count sold numbers
			$countSold = $this->My_model->count_where('numbers_tbl', ['product_status' => 'Sold', 'sold_date' => $date, 'status' => 'active']);
			$data['daily_sales'][] = $countSold;

			// // Count inserted numbers
			// $countEntry = $this->My_model->count_where('numbers_tbl', ['entry_date' => $date, 'status' => 'active']);
			// $data['daily_sales_entry'][] = $countEntry;
		}

		// Chart Data - Last 12 months
		$data['monthly_labels'] = [];
		$data['monthly_sales'] = [];
		$data['monthly_sales_entry'] = [];
		for ($i = 11; $i >= 0; $i--) {
			$month = date('Y-m', strtotime("-$i months"));
			$data['monthly_labels'][] = date('M Y', strtotime($month . '-01'));

			// Count sold numbers
			$countSold = $this->db->query("SELECT COUNT(*) as count FROM numbers_tbl WHERE product_status = 'Sold' AND status='active' AND DATE_FORMAT(STR_TO_DATE(sold_date, '%Y-%m-%d'), '%Y-%m') = '$month'")->row();
			$data['monthly_sales'][] = $countSold->count ?? 0;

			// Count inserted numbers
			$countEntry = $this->db->query("SELECT COUNT(*) as count FROM numbers_tbl WHERE status='active' AND DATE_FORMAT(STR_TO_DATE(entry_date, '%Y-%m-%d'), '%Y-%m') = '$month'")->row();
			$data['monthly_sales_entry'][] = $countEntry->count ?? 0;
		}

		$this->ov("index", $data);
	}
	public function profile()
	{
		$data['det'] = $this->My_model->select_where("school_det", ['status' => 'active']);
		// $data['principal'] = $this->My_model->select_where("principal", ['principal_status' => 'current', 'status' => 'active']);
		$data['company_det'] = $this->My_model->select_where("company_details_tbl", ['status' => 'active']);
		$this->ov('profile', $data);
	}
	public function admin_profile()
	{
		$data['admin_det'] = $this->My_model->select_where("admin_tbl", ['admin_tbl_id' => $_SESSION['admin_id']]);
		$data['det'] = $this->My_model->select_where("school_det", ['status' => 'active']);

		// $data['principal'] = $this->My_model->select_where("principal", ['principal_status' => 'current', 'status' => 'active']);

		$data['company_det'] = $this->My_model->select_where("company_details_tbl", ['status' => 'active']);
		$this->ov('admin_profile', $data);
	}
	public function company_details_update()
	{
		if ($_FILES['company_logo']['name'] != "") {
			$imgname = $_FILES['company_logo']['name'];
			$imgtemp = $_FILES['company_logo']['tmp_name'];
			$path = "uploads/";
			$_POST['company_logo'] = $this->upload_img($imgname, $imgtemp, $path);
			$path2 = "uploads/" . $_POST['company_logo1'];
			unlink($path2);
		} else {
			$_POST['company_logo'] = $_POST['company_logo1'];
		}
		unset($_POST['company_logo1']);
		$title = "Login Failed";
		$description = "Wrong Username or Password. Please try again.";
		$this->session->set_flashdata('success', 'Profile Updated successfully');

		$this->My_model->update("company_details_tbl", ['company_det_id' => $_POST['company_det_id']], $_POST);
		redirect('admin/profile', 'refresh');
	}
	public function update_admin_profile()
	{
		if ($_FILES['admin_profile_logo']['name'] != "") {
			$imgname = $_FILES['admin_profile_logo']['name'];
			$imgtemp = $_FILES['admin_profile_logo']['tmp_name'];
			$path = "uploads/";
			$_POST['admin_profile_logo'] = $this->upload_img($imgname, $imgtemp, $path);
			$path2 = "uploads/" . $_POST['admin_profile_logo1'];
			unlink($path2);
		} else {
			$_POST['admin_profile_logo'] = $_POST['admin_profile_logo1'];
		}
		unset($_POST['admin_profile_logo1']);
		$title = "Login Failed";
		$description = "Wrong Username or Password. Please try again.";
		$this->session->set_flashdata('success', 'Profile Updated successfully');

		$this->My_model->update("admin_tbl", ['admin_tbl_id' => $_POST['admin_tbl_id']], $_POST);
		redirect('admin/admin_profile', 'refresh');
	}


	// 28 th March
	public function employee()
	{
		$data['job_list'] = $this->My_model->select_where("job_position_tbl", ['status' => 'active']);
		$data['plant_list'] = $this->My_model->select_where("plant_tbl", ['status' => 'active']);

		$this->ov('employee', $data);
	}
	public function add_employee()
	{

		if (!empty($_FILES['emp_image']['name'])) {
			$img_name = $_FILES['emp_image']['name'];
			$img_temp = $_FILES['emp_image']['tmp_name'];
			$path = "uploads/";
			$_POST['emp_image'] = $this->upload_img($img_name, $img_temp, $path);
		} else {
			$_FILES['emp_image'] = '';
		}
		$_POST['added_by'] = 'admin';
		$_POST['entry_time'] = time();
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['status'] = 'active';

		$salary['salary_lpa'] = $_POST['salary_lpa'];
		$salary['salary_spm'] = $_POST['salary_spm'];


		$data = $this->My_model->insert("emp_tbl", $_POST);



		$emp_his['emp_id'] = $data;
		$emp_his['plant_id'] = $_POST['plant_id'];
		$emp_his['shift_id'] = $_POST['shift_id'];
		$emp_his['salary_lpa'] = $_POST['salary_lpa'];
		$emp_his['salary_spm'] = $_POST['salary_spm'];
		$emp_his['job_position_id'] = $_POST['job_position_id'];
		$emp_his['emp_id'] = 1;
		$emp_his['added_by'] = 'admin';
		$emp_his['entry_time'] = time();
		$emp_his['entry_by'] = $_SESSION['admin_id'];
		$emp_his['status'] = 'active';
		$this->My_model->insert("emp_his_tbl", $emp_his);
		if ($data) {
			redirect('admin/employee', 'refresh');
		} else {
			redirect('admin/employee', 'refresh');
		}
	}
	public function employee_list()
	{
		$data['plant_list'] = $this->My_model->select_where("plant_tbl", ['status' => 'active']);

		$page_no = 1;
		$search = "";
		extract($_GET);
		if (!isset($_GET['q'])) {
			$show = " ";
		} else {
			$show = " AND (
                (emp_tbl.emp_name LIKE '%" . $_GET['q'] . "%') 
                OR (emp_tbl.emp_mobile_no LIKE '%" . $_GET['q'] . "%') 
                OR (emp_tbl.emp_mobile_no LIKE '%" . $_GET['q'] . "%') 
                OR (job_position_tbl.position_name LIKE '%" . $_GET['q'] . "%') 
            )";
		}
		$total_rows = $this->db->query("SELECT count(emp_tbl.emp_tbl_id) as ttl_rows FROM emp_tbl,plant_tbl,job_position_tbl WHERE emp_tbl.plant_id=plant_tbl.plant_tbl_id AND  emp_tbl.job_position_id=job_position_tbl.job_position_tbl_id AND emp_tbl.status='active' " . $show)->result_array()[0]['ttl_rows'];

		$per_page = 20;
		$data['start'] = $per_page * $page_no - $per_page;
		$data['ttl_pages'] = $total_rows / $per_page;
		$data['page_no'] = $page_no;

		$data['list'] = $this->db->query("SELECT * FROM emp_tbl,plant_tbl,job_position_tbl WHERE emp_tbl.plant_id=plant_tbl.plant_tbl_id AND emp_tbl.job_position_id=job_position_tbl.job_position_tbl_id AND emp_tbl.status='active' " . $show . " ORDER BY emp_tbl.emp_tbl_id DESC limit " . $data['start'] . "," . $per_page)->result_array();
		$this->ov("employee_list", $data);
	}
	public function edit_employee($id)
	{
		$data['job_list'] = $this->My_model->select_where("job_position_tbl", ['status' => 'active']);
		$data['plant_list'] = $this->My_model->select_where("plant_tbl", ['status' => 'active']);
		$data['emp_det'] = $this->My_model->select_where("emp_tbl", ['status' => 'active', 'emp_tbl_id' => $id]);
		$this->ov("employee", $data);
	}
	public function delete_employee($id)
	{
		$data = $this->My_model->update("user_tbl", ['user_tbl_id' => $id], ['status' => 'deleted']);
		if ($data) {
			redirect('admin/all_users', 'refresh');
		} else {
			redirect('admin/all_users', 'refresh');
		}
	}
	public function save_employee()
	{
		if ($_FILES['emp_image']['name'] != "") {
			$imgname = $_FILES['emp_image']['name'];
			$imgtemp = $_FILES['emp_image']['tmp_name'];
			$path = "uploads/";
			$_POST['emp_image'] = $this->upload_img($imgname, $imgtemp, $path);
			$path1 = "uploads/" . $_POST['emp_image1'];
			unlink($path1);
		} else {
			$_POST['emp_image'] = $_POST['emp_image1'];
		}

		unset($_POST['emp_image1']);
		$data = $this->My_model->update("emp_tbl", ['emp_tbl_id' => $_POST['emp_tbl_id']], $_POST);
		$emp_his['emp_id'] = $_POST['emp_tbl_id'];
		$emp_his['plant_id'] = $_POST['plant_id'];
		$emp_his['shift_id'] = $_POST['shift_id'];
		$emp_his['salary_lpa'] = $_POST['salary_lpa'];
		$emp_his['salary_spm'] = $_POST['salary_spm'];
		$emp_his['job_position_id'] = $_POST['job_position_id'];
		$emp_his['emp_id'] = 1;
		$emp_his['added_by'] = 'admin';
		$emp_his['entry_time'] = time();
		$emp_his['entry_by'] = $_SESSION['admin_id'];
		$emp_his['status'] = 'active';
		$this->My_model->insert("emp_his_tbl", $emp_his);

		if ($data) {
			redirect('admin/employee_list', 'refresh');
		} else {
			redirect('admin/employee_list', 'refresh');
		}
	}


	private function setToastMessage($message, $color)
	{
		$_SESSION['toast_message'] = $message;
		$_SESSION['toast_color'] = $color;
	}
	public function sales_lead_list()
	{
		$page_no = 1;
		$search = "";
		extract($_GET);
		if (!isset($_GET['q'])) {
			$show = " ";
		} else {
			$show = " AND (
                (emp_tbl.emp_name LIKE '%" . $_GET['q'] . "%') 
                OR (emp_tbl.emp_mobile_no LIKE '%" . $_GET['q'] . "%') 
                OR (leads_tbl.customer_name LIKE '%" . $_GET['q'] . "%') 
                OR (leads_tbl.company_name LIKE '%" . $_GET['q'] . "%') 
                OR (leads_tbl.company_address LIKE '%" . $_GET['q'] . "%') 
                OR (leads_tbl.customer_name LIKE '%" . $_GET['q'] . "%') 
                OR (leads_tbl.customer_mobile_no LIKE '%" . $_GET['q'] . "%') 
                OR (leads_tbl.feedback_date LIKE '%" . $_GET['q'] . "%') 
                OR (leads_tbl.lead_status LIKE '%" . $_GET['q'] . "%') 
            )";
		}
		$total_rows = $this->db->query("SELECT count(leads_tbl.leads_tbl_id) as ttl_rows FROM emp_tbl,leads_tbl WHERE leads_tbl.status='active' AND leads_tbl.emp_id=emp_tbl.emp_tbl_id AND leads_tbl.entry_by='sales' " . $show)->result_array()[0]['ttl_rows'];

		$per_page = 20;
		$data['start'] = $per_page * $page_no - $per_page;
		$data['ttl_pages'] = $total_rows / $per_page;
		$data['page_no'] = $page_no;

		$data['list'] = $this->db->query("SELECT * FROM emp_tbl,leads_tbl WHERE leads_tbl.status='active' AND leads_tbl.emp_id=emp_tbl.emp_tbl_id AND leads_tbl.entry_by='sales' " . $show . " ORDER BY leads_tbl.leads_tbl_id DESC limit " . $data['start'] . "," . $per_page)->result_array();


		foreach ($data['list'] as $key => $row) {
			$data['list'][$key]['product_name'] = $this->db->query("SELECT * FROM lead_products,product WHERE lead_products.product_id=product.product_id AND lead_products.status='active' AND lead_products.leads_id='" . $row['leads_tbl_id'] . "' ")->result_array();
		}
		$this->ov("sales_lead_list", $data);
	}




	public function array_to_csv_download($array, $filename = "export.csv", $delimiter = ";")
	{
		header('Content-Type: application/csv');
		header('Content-Disposition: attachment; filename="' . $filename . '";');

		$file = fopen("php://output", "w");
		$i = 0;
		foreach ($array as $key => $line) {
			if ($i == 0) {
				$arr = [];
				foreach ($line as $key2 => $value) {
					if ($key2 == "entry_time")
						$key2 = "Reg. Date";

					$arr[] = strtoupper(str_replace("_", " ", $key2));
				}
				fputcsv($file, $arr);
			}
			if (isset($line['entry_time'])) {
				$line['entry_time'] = date('d-m-Y', $line['entry_time']);
			}
			fputcsv($file, $line);
			$i++;
		}
		fclose($file);

		return true;
	}

	public function download_purchase_history_exc()
	{
		$data['list'] = $this->db->query("SELECT * FROM purchase, plant_tbl, raw_materials, unit_tbl, supplier_tbl, emp_tbl WHERE purchase.supplier_id=supplier_tbl.supplier_tbl_id AND plant_tbl.emp_id=emp_tbl.emp_tbl_id AND purchase.unit_id=unit_tbl.unit_tbl_id AND purchase.raw_materials_id=raw_materials.raw_materials_id AND purchase.plant_id=plant_tbl.plant_tbl_id AND purchase.status='active' ORDER BY purchase.purchase_id DESC ")->result_array();
		$data['purchase_list'] = [];
		foreach ($data['list'] as $key => $row) {
			if ($row['transport_by'] == 'own') {
				$driver = $this->My_model->select_where('driver_tbl', ['driver_tbl_id' => $row['driver_id'], 'status' => 'active']);
				$vehicle = $this->My_model->select_where("vehicle_tbl", ['vehicle_tbl_id' => $row['vehicle_id'], 'status' => 'active']);
				$driver_name = isset($driver[0]) ? $driver[0]['driver_name'] : '-';
				$vehicle_no = isset($vehicle[0]) ? $vehicle[0]['vehicle_no'] : '-';
				$data['list'][$key]['driver_name'] = $driver_name;
				$data['list'][$key]['vehicle_no'] = $vehicle_no;
			}
			$data['purchase_list'][$key]['purchase_date'] = $row['purchase_date'];
			$data['purchase_list'][$key]['party_name'] = $row['supplier_name'];
			$data['purchase_list'][$key]['plant_name'] = $row['plant_name'];
			$data['purchase_list'][$key]['raw_materials_name'] = $row['raw_materials_name'];
			$data['purchase_list'][$key]['gross_weight'] = $row['gross_weight'] . " " . $row['unit_name'];
			$data['purchase_list'][$key]['tare_weight'] = $row['tare_weight'] . " " . $row['unit_name'];
			$data['purchase_list'][$key]['deduction'] = $row['deduction'] . " " . $row['unit_name'];
			$data['purchase_list'][$key]['net_weight'] = $row['net_weight'] . " " . $row['unit_name'];
			$data['purchase_list'][$key]['rate'] = $row['rate'];
			$data['purchase_list'][$key]['ttl_amount'] = $row['ttl_amount'];
			$data['purchase_list'][$key]['plant_head'] = $row['emp_name'];
			$data['purchase_list'][$key]['vehicle_no'] = $row['vehicle_no'];
			$data['purchase_list'][$key]['driver_name'] = $row['driver_name'];
		}

		$mergeColumns = ['start' => 'A', 'end' => 'M'];
		$this->array_to_excel_download($data['purchase_list'], 'Purchase_list_' . date('Y-m-d') . '.xlsx', "Purchase History Report", $mergeColumns);
	}


	public function array_to_excel_download($array, $filename = "export.xlsx", $headline = "", $mergeColumns = ['start' => 'A', 'end' => 'M'])
	{
		$spreadsheet = new Spreadsheet();
		$sheet = $spreadsheet->getActiveSheet();

		// Add headline row
		$sheet->setCellValue($mergeColumns['start'] . '1', $headline);
		$sheet->mergeCells($mergeColumns['start'] . '1:' . $mergeColumns['end'] . '1'); // Merge cells for the headline
		$sheet->getStyle($mergeColumns['start'] . '1')->getFont()->setSize(25); // Set font size
		$sheet->getStyle($mergeColumns['start'] . '1')->getFont()->setBold(true); // Set font bold
		$sheet->getStyle($mergeColumns['start'] . '1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER); // Center align
		// Set headline color
		$sheet->getStyle($mergeColumns['start'] . '1:' . $mergeColumns['end'] . '1')->applyFromArray([
			'font' => [
				'color' => ['argb' => 'FFFF0000'] // Red text color
			],
			'fill' => [
				'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
			]
		]);

		// Start from the second row for the actual data
		$rowNum = 2;

		$i = 0;
		foreach ($array as $key => $line) {
			if ($i == 0) {
				$col = 'A';
				foreach ($line as $key2 => $value) {
					if ($key2 == "entry_time")
						$key2 = "Reg. Date";

					$sheet->setCellValue($col . $rowNum, strtoupper(str_replace("_", " ", $key2)));
					$col++;
				}
				$sheet->getStyle('A2:' . $mergeColumns['end'] . '2')->getFont()->setBold(true);
				$sheet->getStyle('A2:' . $mergeColumns['end'] . '2')->getFont()->setSize(12);
				// Set background color for the second row
				$sheet->getStyle('A2:' . $mergeColumns['end'] . '2')->applyFromArray([
					'fill' => [
						'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
						'color' => ['argb' => 'FFF2CD'] // Red color
					]
				]);
				$rowNum++;
			}
			if (isset($line['entry_time'])) {
				$line['entry_time'] = date('d-m-Y', $line['entry_time']);
			}
			$col = 'A';
			foreach ($line as $value) {
				$sheet->setCellValue($col . $rowNum, $value);
				$col++;
			}
			$rowNum++;
			$i++;
		}

		$writer = new Xlsx($spreadsheet);
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment; filename="' . $filename . '"');
		$writer->save("php://output");

		return true;
	}

	public function add_class()
	{
		$data['list'] = $this->db->query("SELECT * FROM grade,class WHERE class.grade_id = grade.grade_id AND class.status='active' AND grade.status = 'active' ")->result_array();
		$data['grade'] = $this->My_model->select_where("grade", ['status' => 'active']);
		$this->ov("add_class", $data);
	}
	public function save_class()
	{
		$_POST['status'] = 'active';
		$_POST['entry_time'] = time();
		$_POST['entry_date'] = date('Y-m-d');
		$_POST['entry_from'] = 'admin';
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$data = $this->My_model->insert("class", $_POST);
		if ($data) {
			redirect('admin/add_class');
		} else {
			redirect('admin/add_class');
		}
	}
	public function edit_class($id)
	{
		$data['det'] = $this->db->query("SELECT * FROM grade,class WHERE class.grade_id = grade.grade_id AND class.status='active' AND grade.status = 'active' AND class.class_id='" . $id . "' ")->result_array();
		$data['grade'] = $this->My_model->select_where("grade", ['status' => 'active']);
		$this->ov("add_class", $data);
	}
	public function update_class()
	{
		$data = $this->My_model->update("class", ['class_id' => $_POST['class_id']], $_POST);
		if ($data) {
			redirect('admin/add_class');
		} else {
			redirect('admin/add_class');
		}
	}
	public function delete_class($id)
	{
		$data = $this->My_model->update("class", ['class_id' => $id], ['status' => 'deleted']);
		if ($data) {
			redirect('admin/add_class');
		} else {
			redirect('admin/add_class');
		}
	}
	public function add_grade()
	{
		$data['list'] = $this->My_model->select_where("grade", ['status' => 'active']);
		$this->ov("add_grade", $data);
	}

	public function save_grade()
	{
		$_POST['status'] = 'active';
		$_POST['entry_time'] = time();
		$_POST['entry_date'] = date('Y-m-d');
		$_POST['entry_from'] = 'admin';
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$data = $this->My_model->insert("grade", $_POST);
		if ($data) {
			redirect('admin/add_grade');
		} else {
			redirect('admin/add_grade');
		}
	}
	public function edit_grade($id)
	{
		$data['det'] = $this->My_model->select_where("grade", ['status' => 'active', 'grade_id' => $id]);
		$this->ov("add_grade", $data);
	}
	public function delete_grade($id)
	{
		$data = $this->My_model->update("grade", ['status' => 'active', 'grade_id' => $id], ['status' => 'deleted']);
		if ($data) {
			redirect('admin/add_grade');
		} else {
			redirect('admin/add_grade');
		}
	}
	public function update_grade()
	{
		$data = $this->My_model->update("grade", ['grade_id' => $_POST['grade_id']], $_POST);
		if ($data) {
			redirect('admin/add_grade');
		} else {
			redirect('admin/add_grade');
		}
	}
	public function save_principal()
	{
		if (isset($_FILES['principal_profile_img'])) {
			if (!empty($_FILES['principal_profile_img']['name'])) {
				$img_name = $_FILES['principal_profile_img']['name'];
				$img_temp = $_FILES['principal_profile_img']['tmp_name'];
				$path = "uploads/";
				$_POST['principal_profile_img'] = $this->upload_img($img_name, $img_temp, $path);
			} else {
				$_FILES['principal_profile_img'] = '';
			}
		}
		$_POST['principal_status'] = 'current';
		$_POST['address'] = '';
		$_POST['status'] = 'active';
		$_POST['entry_time'] = time();
		$_POST['entry_date'] = date('Y-m-d');
		$_POST['entry_from'] = 'admin';
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$this->My_model->insert("principal", $_POST);
		if ($data) {
			redirect('admin/profile');
		} else {
			redirect('admin/profile');
		}
	}
	public function update_principal_details()
	{
		if (isset($_FILES['principal_profile_img'])) {
			if ($_FILES['principal_profile_img']['name'] != "") {
				$imgname = $_FILES['principal_profile_img']['name'];
				$imgtemp = $_FILES['principal_profile_img']['tmp_name'];
				$path = "uploads/";
				$_POST['principal_profile_img'] = $this->upload_img($imgname, $imgtemp, $path);
				$path1 = "uploads/" . $_POST['principal_profile_img1'];
				if (!empty($_POST['principal_profile_img1'])) {
					unlink($path1);
				}
			} else {
				$_POST['principal_profile_img'] = $_POST['principal_profile_img1'];
			}
		}
		unset($_POST['principal_profile_img1']);
		$_POST['principal_status'] = 'current';
		$this->My_model->update("principal", ['principal_id' => $_POST['principal_id']], $_POST);
		if ($data) {
			redirect('admin/profile');
		} else {
			redirect('admin/profile');
		}
	}
	public function update_school_profile()
	{
		$_POST['principal_status'] = 'current';
		$_POST['address'] = '';
		$_POST['status'] = 'active';
		$_POST['entry_time'] = time();
		$_POST['entry_date'] = date('Y-m-d');
		$_POST['entry_from'] = 'admin';
		$_POST['entry_by'] = $_SESSION['admin_id'];

		$data = $this->My_model->update("school_det", ['school_det_id' => $_POST['school_det_id']], $_POST);
		if ($data) {
			redirect('admin/profile');
		} else {
			redirect('admin/profile');
		}
	}

	public function transport_deal()
	{
		$this->ov("transport_deal");
	}
	public function deliveries()
	{
		$this->ov("deliveries");
	}
	public function vehicle()
	{
		$this->ov("vehicle");
	}
	public function settlements()
	{
		$this->ov("settlements");
	}
	public function deal()
	{
		$this->ov("deal");
	}
	public function network()
	{
		$this->ov("network");
	}
	public function buyer()
	{
		$this->ov("buyer");
	}
	public function seller()
	{
		$this->ov("seller");
	}
	public function subscription()
	{
		$this->ov("subscription");
	}
	public function create_sell()
	{
		$this->ov("create_sell");
	}
	public function create_buy()
	{
		$this->ov("create_buy");
	}
	public function all_users()
	{
		$page_no = 1;
		$search = "";
		extract($_GET);
		if (!isset($_GET['q'])) {
			$show = " ";
		} else {
			$show = " AND (
	                (user_name LIKE '%" . $_GET['q'] . "%') 
	                OR (user_mobile_no LIKE '%" . $_GET['q'] . "%') 
	                OR (user_email LIKE '%" . $_GET['q'] . "%') 
	                OR (user_company_name LIKE '%" . $_GET['q'] . "%') 
	            )";
		}
		$total_rows = $this->db->query("SELECT count(user_tbl_id) as ttl_rows FROM user_tbl WHERE user_tbl.status='active' " . $show)->result_array()[0]['ttl_rows'];

		$per_page = 20;
		$data['start'] = $per_page * $page_no - $per_page;
		$data['ttl_pages'] = $total_rows / $per_page;
		$data['page_no'] = $page_no;

		$data['list'] = $this->db->query("SELECT * FROM user_tbl WHERE status='active' " . $show . " ORDER BY user_tbl_id DESC limit " . $data['start'] . "," . $per_page)->result_array();
		$this->ov("all_users", $data);
	}
	public function add_plans()
	{
		$data['list'] = $this->My_model->select_where("plan", ['status' => 'active']);
		$this->ov("add_plans", $data);
	}
	public function delete_plan($id)
	{
		$data = $this->My_model->update("plan", ['plan_id' => $id], ['status' => 'deleted']);
		if ($data) {
			$this->setToastMessage('Plan Deleted Successfully', 'success');
			redirect('admin/add_plans');
		} else {
			$this->setToastMessage('Something Went Wrong...', 'error');
			redirect('admin/add_plans');
		}
	}
	public function save_plan()
	{
		$_POST['added_by'] = 'admin';
		$_POST['entry_time'] = time();
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['status'] = 'active';
		$data = $this->My_model->insert("plan", $_POST);
		if ($data) {
			$this->setToastMessage('Plan Added Successfully', 'success');
			redirect('admin/add_plans');
		} else {
			$this->setToastMessage('Plan Not Added', 'error');
			redirect('admin/add_plans');
		}
	}
	public function edit_plan($id)
	{
		$data['det'] = $this->My_model->select_where("plan", ['status' => 'active', 'plan_id' => $id]);
		$this->ov("add_plans", $data);
	}
	public function update_plan()
	{
		$data = $this->My_model->update("plan", ['plan_id' => $_POST['plan_id']], $_POST);
		if ($data) {
			$this->setToastMessage('Plan Updates Successfully', 'success');
			redirect('admin/add_plans');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_plans');
		}
	}
	public function add_features($id)
	{
		$data['feature'] = $this->My_model->select_where("plan_feature", ['plan_id' => $id, 'status' => 'active']);
		$data['det'] = $this->My_model->select_where("plan", ['status' => 'active', 'plan_id' => $id]);
		$this->ov("add_features", $data);
	}
	public function save_feature()
	{
		$_POST['added_by'] = 'admin';
		$_POST['entry_time'] = time();
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['status'] = 'active';
		$data = $this->My_model->insert("plan_feature", $_POST);
		if ($data) {
			$this->setToastMessage('Feature Added Successfully', 'success');
			redirect('admin/add_features/' . $_POST['plan_id']);
		} else {
			$this->setToastMessage('Feature Not Added', 'error');
			redirect('admin/add_features/' . $_POST['plan_id']);
		}
	}
	public function edit_feature($id)
	{
		$data['f_det'] = $this->My_model->select_where("plan_feature", ['plan_feature_id' => $id, 'status' => 'active']);
		$this->ov("add_features", $data);
	}
	public function update_feature()
	{
		$data = $this->My_model->update("plan_feature", ['plan_feature_id' => $_POST['plan_feature_id'], 'status' => 'active'], $_POST);
		if ($data) {
			$this->setToastMessage('Feature Updated Successfully', 'success');
			redirect('admin/all_features');
		} else {
			$this->setToastMessage('Something Went Wrong..', 'error');
			redirect('admin/all_features');
		}
	}
	public function all_features()
	{
		$data['list'] = $this->db->query("SELECT * FROM plan,plan_feature WHERE plan_feature.plan_id=plan.plan_id AND plan_feature.status='active' AND plan.status='active' ")->result_array();
		$this->ov("all_features", $data);
	}
	public function delete_feature($id)
	{
		$data = $this->My_model->update("plan_feature", ['plan_feature_id' => $id], ['status' => 'deleted']);
		if ($data) {
			$this->setToastMessage('Feature Deleted Successfully', 'success');
			redirect('admin/all_features');
		} else {
			$this->setToastMessage('Something Went Wrong..', 'error');
			redirect('admin/all_features');
		}
	}
	public function plans_list()
	{
		$data['list'] = $this->My_model->select_where("plan", ['status' => 'active']);

		$this->ov("all_plans", $data);
	}
	public function all_posts()
	{
		$page_no = 1;
		$search = "";
		extract($_GET);
		if (!isset($_GET['q'])) {
			$show = " ";
		} else {
			$show = " AND (
	                (user_name LIKE '%" . $_GET['q'] . "%') 
	                OR (user_mobile_no LIKE '%" . $_GET['q'] . "%') 
	                OR (user_email LIKE '%" . $_GET['q'] . "%') 
	                OR (user_company_name LIKE '%" . $_GET['q'] . "%') 
	            )";
		}
		$total_rows = $this->db->query("SELECT count(user_post.user_post_id) as ttl_rows FROM user_tbl,user_post WHERE user_post.user_id=user_post.user_post_id AND user_post.status='active' AND user_tbl.status='active' " . $show)->result_array()[0]['ttl_rows'];

		$per_page = 20;
		$data['start'] = $per_page * $page_no - $per_page;
		$data['ttl_pages'] = $total_rows / $per_page;
		$data['page_no'] = $page_no;

		$data['list'] = $this->db->query("SELECT * FROM user_tbl,user_post WHERE user_post.user_id=user_tbl.user_tbl_id AND user_post.status='active' AND user_tbl.status='active' " . $show . " ORDER BY user_post.user_post_id DESC limit " . $data['start'] . "," . $per_page)->result_array();
		foreach ($data['list'] as $key => $row) {
			$data['list'][$key]['ttl_likes'] = $this->db->query("SELECT count(user_liked_post_id) as ttl_likes FROM user_liked_post WHERE status='active' AND post_id='" . $row['user_post_id'] . "' ")->result_array()[0]['ttl_likes'];
			$data['list'][$key]['ttl_comments'] = $this->db->query("SELECT count(user_comment_post_id) as ttl_comments FROM user_comment_post WHERE status='active' AND post_id='" . $row['user_post_id'] . "' ")->result_array()[0]['ttl_comments'];
		}

		$this->ov("all_posts", $data);
	}

	public function post_info($id)
	{

		$data['list'] = $this->db->query("SELECT * FROM user_tbl,user_post WHERE user_post.user_id=user_tbl.user_tbl_id AND user_post.status='active' AND user_tbl.status='active' AND user_post.user_post_id='" . $id . "' ")->result_array();
		foreach ($data['list'] as $key => $row) {
			$data['list'][$key]['ttl_likes'] = $this->db->query("SELECT count(user_liked_post_id) as ttl_likes FROM user_liked_post WHERE status='active' AND post_id='" . $row['user_post_id'] . "' ")->result_array()[0]['ttl_likes'];
			$data['list'][$key]['ttl_comments'] = $this->db->query("SELECT count(user_comment_post_id) as ttl_comments FROM user_comment_post WHERE status='active' AND post_id='" . $row['user_post_id'] . "' ")->result_array()[0]['ttl_comments'];
			$data['list'][$key]['postData'] = $this->My_model->select_where("user_post_data", ['status' => 'active', 'user_post_id' => $row['user_post_id']]);
			$data['likes'] = $this->db->query("SELECT * FROM user_liked_post,user_tbl WHERE user_liked_post.user_id=user_tbl.user_tbl_id AND user_liked_post.status='active' AND user_liked_post.post_id='" . $row['user_post_id'] . "' ")->result_array();
			$data['comments'] = $this->db->query("SELECT * FROM user_comment_post,user_tbl WHERE user_comment_post.user_id=user_tbl.user_tbl_id AND user_comment_post.status='active' AND user_comment_post.post_id='" . $row['user_post_id'] . "' ")->result_array();
		}
		$this->ov("post_info", $data);
	}
	public function Subscribed_list()
	{
		$page_no = 1;
		$search = "";
		extract($_GET);
		if (!isset($_GET['q'])) {
			$show = " ";
		} else {
			$show = " AND (
	                (user_name LIKE '%" . $_GET['q'] . "%') 
	                OR (user_mobile_no LIKE '%" . $_GET['q'] . "%') 
	                OR (user_email LIKE '%" . $_GET['q'] . "%') 
	                OR (user_company_name LIKE '%" . $_GET['q'] . "%') 
	            )";
		}
		$total_rows = $this->db->query("SELECT count(user_tbl.user_tbl_id) as ttl_rows FROM user_tbl,user_subscribe_plans,plan WHERE user_subscribe_plans.user_id=user_tbl.user_tbl_id AND user_tbl.user_subscribe_plans_id=user_subscribe_plans.user_subscribe_plans_id AND user_tbl.status='active' AND user_subscribe_plans.plan_id=plan.plan_id  " . $show)->result_array()[0]['ttl_rows'];

		$per_page = 20;
		$data['start'] = $per_page * $page_no - $per_page;
		$data['ttl_pages'] = $total_rows / $per_page;
		$data['page_no'] = $page_no;

		$data['list'] = $this->db->query("SELECT * FROM user_tbl,user_subscribe_plans,plan WHERE user_subscribe_plans.user_id=user_tbl.user_tbl_id AND user_tbl.user_subscribe_plans_id=user_subscribe_plans.user_subscribe_plans_id AND user_tbl.status='active' AND user_subscribe_plans.plan_id=plan.plan_id " . $show . " ORDER BY user_tbl.user_tbl_id DESC limit " . $data['start'] . "," . $per_page)->result_array();
		$this->ov("Subscribed_list", $data);
	}
	public function purchase_plan_history()
	{
		$page_no = 1;
		$search = "";
		extract($_GET);
		if (!isset($_GET['q'])) {
			$show = " ";
		} else {
			$show = " AND (
	                (user_name LIKE '%" . $_GET['q'] . "%') 
	                OR (user_mobile_no LIKE '%" . $_GET['q'] . "%') 
	                OR (user_email LIKE '%" . $_GET['q'] . "%') 
	                OR (user_company_name LIKE '%" . $_GET['q'] . "%') 
	            )";
		}
		$total_rows = $this->db->query("SELECT count(user_tbl.user_tbl_id) as ttl_rows FROM user_tbl,user_subscribe_plans,plan WHERE user_subscribe_plans.user_id=user_tbl.user_tbl_id AND  user_tbl.status='active' AND user_subscribe_plans.plan_id=plan.plan_id  " . $show)->result_array()[0]['ttl_rows'];

		$per_page = 20;
		$data['start'] = $per_page * $page_no - $per_page;
		$data['ttl_pages'] = $total_rows / $per_page;
		$data['page_no'] = $page_no;

		$data['list'] = $this->db->query("SELECT *, user_tbl.user_subscribe_plans_id as current_plan_id FROM user_tbl,user_subscribe_plans,plan WHERE user_subscribe_plans.user_id=user_tbl.user_tbl_id AND  user_tbl.status='active' AND user_subscribe_plans.plan_id=plan.plan_id " . $show . " ORDER BY user_subscribe_plans.user_subscribe_plans_id DESC limit " . $data['start'] . "," . $per_page)->result_array();
		$this->ov("purchase_plan_history", $data);
	}

	public function add_unit()
	{
		$data['unit_list'] = $this->My_model->select_where("unit_tbl", ['status' => 'active']);
		$this->ov("unit", $data);
	}

	public function save_unit()
	{
		$_POST['added_by'] = 'admin';
		$_POST['entry_time'] = time();
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['status'] = 'active';
		$data = $this->My_model->insert("unit_tbl", $_POST);
		if ($data) {
			$this->setToastMessage('Unit Added Successfully', 'success');
			redirect('admin/add_unit', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_unit', 'refresh');
		}
	}

	public function update_unit()
	{
		$data = $this->My_model->update("unit_tbl", ['unit_tbl_id' => $_POST['unit_tbl_id']], $_POST);
		if ($data) {
			$this->setToastMessage('Unit Updatetd Successfully', 'success');
			redirect('admin/add_unit', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_unit', 'refresh');
		}
	}

	public function delete_unit($id)
	{
		$data = $this->My_model->update("unit_tbl", ['unit_tbl_id' => $id], ['status' => 'deleted']);

		if ($data) {
			$this->setToastMessage('Unit Deleted', 'error');
			redirect('admin/add_unit', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_unit', 'refresh');
		}
	}

	public function add_state()
	{
		$page_no = 1;
		$search = "";
		extract($_GET);
		if (!isset($_GET['q'])) {
			$show = " ";
		} else {
			$show = " AND (
	                (state_name LIKE '%" . $_GET['q'] . "%') 
	            )";
		}
		$total_rows = $this->db->query("SELECT count(state_id) as ttl_rows FROM state WHERE state.status='active' " . $show)->result_array()[0]['ttl_rows'];

		$per_page = 20;
		$data['start'] = $per_page * $page_no - $per_page;
		$data['ttl_pages'] = $total_rows / $per_page;
		$data['page_no'] = $page_no;

		$data['list'] = $this->db->query("SELECT * FROM state WHERE status='active' " . $show . " ORDER BY state_id DESC limit " . $data['start'] . "," . $per_page)->result_array();

		$this->ov("add_state", $data);
	}
	public function edit_state($id)
	{
		$data['det'] = $this->My_model->select_where("state", ['status' => 'active', 'state_id' => $id]);
		$this->ov("add_state", $data);
	}
	public function delete_state($id)
	{
		$data = $this->My_model->update("state", ['status' => 'active', 'state_id' => $id], ['status' => 'deleted']);
		if ($data) {
			$this->setToastMessage('State Deleted', 'success');
			redirect('admin/add_state', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_state', 'refresh');
		}
	}
	public function update_state()
	{
		$data = $this->My_model->update("state", ['status' => 'active', 'state_id' => $_POST['state_id']], $_POST);
		if ($data) {
			$this->setToastMessage('State Updated', 'success');
			redirect('admin/add_state', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_state', 'refresh');
		}
	}
	public function save_state()
	{
		$_POST['status'] = 'active';
		$_POST['entry_time'] = time();
		$_POST['entry_date'] = date('Y-m-d');
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$data = $this->My_model->insert("state", $_POST);
		if ($data) {
			$this->setToastMessage('State Added', 'success');
			redirect('admin/add_state', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_state', 'refresh');
		}
	}
	public function add_district()
	{
		$data['state'] = $this->My_model->select_where("state", ['status' => 'active']);
		$page_no = 1;
		$search = "";
		extract($_GET);
		if (!isset($_GET['q'])) {
			$show = " ";
		} else {
			$show = " AND (
	                (district.district_name LIKE '%" . $_GET['q'] . "%') 
	                OR (state.state_name LIKE '%" . $_GET['q'] . "%') 

	            )";
		}
		$total_rows = $this->db->query("SELECT count(district.district_id) as ttl_rows FROM state,district WHERE district.state_id=state.state_id AND state.status='active' AND district.status='active' " . $show)->result_array()[0]['ttl_rows'];

		$per_page = 20;
		$data['start'] = $per_page * $page_no - $per_page;
		$data['ttl_pages'] = $total_rows / $per_page;
		$data['page_no'] = $page_no;

		$data['list'] = $this->db->query("SELECT * FROM state,district WHERE district.state_id=state.state_id AND state.status='active' AND district.status='active' " . $show . " ORDER BY district.district_id DESC limit " . $data['start'] . "," . $per_page)->result_array();
		$this->ov("add_district", $data);
	}
	public function save_district()
	{
		$_POST['status'] = 'active';
		$_POST['entry_time'] = time();
		$_POST['entry_date'] = date('Y-m-d');
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$data = $this->My_model->insert("district", $_POST);
		if ($data) {
			$this->setToastMessage('District Added', 'success');
			redirect('admin/add_district', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_district', 'refresh');
		}
		;
	}
	public function edit_district($id)
	{
		$data['det'] = $this->My_model->select_where("district", ['status' => 'active', 'district_id' => $id]);
		$data['state'] = $this->My_model->select_where("state", ['status' => 'active']);
		$this->ov("edit_district", $data);
	}
	public function update_district()
	{
		$data = $this->My_model->update("district", ['status' => 'active', 'district_id' => $_POST['district_id']], $_POST);
		if ($data) {
			$this->setToastMessage('District Updated', 'success');
			redirect('admin/add_district', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_district', 'refresh');
		}
	}
	public function delete_district($id)
	{
		$data = $this->My_model->update("district", ['status' => 'active', 'district_id' => $id], ['status' => 'deleted']);
		if ($data) {
			$this->setToastMessage('District Deleted', 'success');
			redirect('admin/add_district', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_district', 'refresh');
		}
	}
	public function add_category()
	{
		$data['list'] = $this->My_model->select_where("category_tbl", ['status' => 'active']);
		$this->ov("add_category", $data);
	}
	public function edit_category($id)
	{
		$data['det'] = $this->My_model->select_where("category_tbl", ['status' => 'active', 'category_tbl_id' => $id])[0];
		$this->ov("add_category", $data);
	}
	public function update_category()
	{
		$data['list'] = $this->My_model->update("category_tbl", ['status' => 'active', 'category_tbl_id' => $_POST['category_tbl_id']], $_POST);
		if ($data) {
			$this->setToastMessage('Category Updated Successfully', 'success');
			redirect('admin/add_category', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_category', 'refresh');
		}
	}
	public function save_category()
	{

		$_POST['added_by'] = 'admin';
		$_POST['entry_time'] = time();
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['status'] = 'active';
		$data = $this->My_model->insert("category_tbl", $_POST);
		if ($data) {
			$this->setToastMessage('Category Added Successfully', 'success');
			redirect('admin/add_category', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_category', 'refresh');
		}
	}
	public function delete_category($id)
	{
		$data['list'] = $this->My_model->update("category_tbl", ['status' => 'active', 'category_id' => $id], ['status' => 'deleted']);
		if ($data) {
			$this->setToastMessage('Category Deleted Successfully', 'success');
			redirect('admin/add_category', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_category', 'refresh');
		}
	}
	public function add_product()
	{
		$data['category'] = $this->My_model->select_where("category_tbl", ['status' => 'active']);
		$data['unit'] = $this->My_model->select_where("unit_tbl", ['status' => 'active']);
		$page_no = 1;
		$search = "";
		extract($_GET);
		if (!isset($_GET['q'])) {
			$show = " ";
		} else {
			$show = " AND (
                (product_tbl.product_name LIKE '%" . $_GET['q'] . "%') OR
                (product_tbl.avg_price LIKE  '%" . $_GET['q'] . "%') OR
                (product_tbl.product_type LIKE '%" . $_GET['q'] . "%') OR
                (product_tbl.product_details LIKE '%" . $_GET['q'] . "%') 
            )";
		}
		$total_rows = $this->db->query("SELECT count(product_tbl.product_tbl_id) as ttl_rows FROM category,product_tbl WHERE product_tbl.category_id=category.category_id AND category.status='active' AND product_tbl.status='active' " . $show)->result_array()[0]['ttl_rows'];

		$per_page = 20;
		$data['start'] = $per_page * $page_no - $per_page;
		$data['ttl_pages'] = $total_rows / $per_page;
		$data['page_no'] = $page_no;

		$data['product_list'] = $this->db->query("SELECT * FROM category,product_tbl WHERE product_tbl.category_id=category.category_id AND category.status='active' AND product_tbl.status='active' " . $show . " ORDER BY product_tbl.product_tbl_id DESC limit " . $data['start'] . "," . $per_page)->result_array();
		$this->ov('add_product', $data);
	}
	public function save_product()
	{

		if (!empty($_FILES['product_img']['name'])) {
			$img_name = $_FILES['product_img']['name'];
			$img_temp = $_FILES['product_img']['tmp_name'];
			$path = "uploads/";
			$_POST['product_img'] = $this->upload_img($img_name, $img_temp, $path);
		} else {
			$_FILES['product_img'] = '';
		}
		$_POST['status'] = 'active';
		$_POST['entry_time'] = time();
		$_POST['entry_date'] = date('Y-m-d');
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['entry_from'] = 'admin';
		$data = $this->My_model->insert("product_tbl", $_POST);
		if ($data) {
			$this->setToastMessage('Product Added', 'success');
			redirect('admin/add_product', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_product', 'refresh');
		}
	}
	public function edit_product($id)
	{
		$data['unit'] = $this->My_model->select_where("unit_tbl", ['status' => 'active']);
		$data['category'] = $this->My_model->select_where("category", ['status' => 'active']);
		$data['det'] = $this->My_model->select_where("product_tbl", ['status' => 'active', 'product_tbl_id' => $id]);
		$this->ov("edit_product", $data);
	}
	public function update_product()
	{
		if ($_FILES['product_img']['name'] != "") {
			$imgname = $_FILES['product_img']['name'];
			$imgtemp = $_FILES['product_img']['tmp_name'];
			$path = "uploads/";
			$_POST['product_img'] = $this->upload_img($imgname, $imgtemp, $path);
			$path2 = "uploads/" . $_POST['product_img1'];
			unlink($path2);
		} else {
			$_POST['product_img'] = $_POST['product_img1'];
		}
		unset($_POST['product_img1']);

		$data = $this->My_model->update("product_tbl", ['status' => 'active', 'product_tbl_id' => $_POST['product_tbl_id']], $_POST);
		if ($data) {
			$this->setToastMessage('Product Updated', 'success');
			redirect('admin/add_product', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_product', 'refresh');
		}
	}
	public function delete_product($id)
	{
		$data = $this->My_model->update("product_tbl", ['status' => 'active', 'product_tbl_id' => $id], ['status' => 'deleted']);
		if ($data) {
			$this->setToastMessage('Product Deleted', 'success');
			redirect('admin/add_product', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_product', 'refresh');
		}
	}

	public function package()
	{
		$this->ov("package");
	}

	public function add_package()
	{
		$_POST['added_by'] = 'admin';
		$_POST['entry_time'] = time();
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['status'] = 'active';
		$f = $_POST['features'];
		unset($_POST['features']);
		$data = $this->My_model->insert("package", $_POST);

		for ($i = 0; $i < count($f); $i++) {
			$features['package_id'] = $data;
			$features['features'] = $f[$i];
			$features['added_by'] = 'admin';
			$features['entry_time'] = time();
			$features['entry_by'] = $_SESSION['admin_id'];
			$features['status'] = 'active';
		}

		$this->My_model->insert("features", $features);
		if ($data) {
			$this->setToastMessage('Package Added Successfully', 'success');
			redirect('admin/package', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/package', 'refresh');
		}
	}

	public function package_list()
	{
		$query = "SELECT 
			    *
			FROM package WHERE status='active';
			";
		$data['list'] = $this->db->query($query)->result_array();
		foreach ($data['list'] as $key => $row) {
			$data['list'][$key]['feature'] = $this->My_model->select_where("features", ['package_id' => $row['package_id'], 'status' => 'active']);
		}
		$this->ov("package_list", $data);
	}
	public function delete_package($id)
	{
		$data = $this->My_model->update("package", ['package_id' => $id], ['status' => 'deleted']);
		$this->My_model->update("features", ['package_id' => $id], ['status' => 'deleted']);
		if ($data) {
			$this->setToastMessage('Package deleted Successfully', 'success');
			redirect('admin/package', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/package', 'refresh');
		}
	}
	public function edit_package($id)
	{
		$data['det'] = $this->My_model->select_where("package", ['package_id' => $id, 'status' => 'active']);
		$data['features'] = $this->My_model->select_where("features", ['package_id' => $id, 'status' => 'active']);
		$this->ov("edit_package", $data);
	}

	public function job_position()
	{
		$data['list'] = $this->My_model->select_where("job_position", ['status' => 'active']);
		$this->ov("job_position", $data);
	}
	public function save_job_position()
	{
		$_POST['added_by'] = 'admin';
		$_POST['entry_time'] = time();
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['status'] = 'active';
		$data = $this->My_model->insert("job_position", $_POST);
		if ($data) {
			$this->setToastMessage('job position Added Successfully', 'success');
			redirect('admin/job_position', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/job_position', 'refresh');
		}
	}

	public function edit_job_position($id)
	{
		$data['det'] = $this->My_model->select_where("job_position", ['status' => 'active', 'job_position_id' => $id]);
		$this->ov("job_position", $data);
	}
	public function delete_job_position($id)
	{
		$data = $this->My_model->update("job_position", ['status' => 'active', 'job_position_id' => $id], ['status' => 'deleted']);
		if ($data) {
			$this->setToastMessage('job position Deleted Successfully', 'success');
			redirect('admin/job_position', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/job_position', 'refresh');
		}
	}
	public function update_job_position()
	{
		$data = $this->My_model->update("job_position", ['status' => 'active', 'job_position_id' => $_POST['job_position_id']], $_POST);
		if ($data) {
			$this->setToastMessage('job position Updated Successfully', 'success');
			redirect('admin/job_position', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/job_position', 'refresh');
		}
	}
	public function contract_type()
	{
		$data['list'] = $this->My_model->select_where("contract_type", ['status' => 'active']);
		$this->ov("contract_type", $data);
	}

	public function update_contract_type()
	{
		$data = $this->My_model->update("contract_type", ['status' => 'active', 'contract_type_id' => $_POST['contract_type_id']], $_POST);
		if ($data) {
			$this->setToastMessage('Contract Updated Successfully', 'success');
			redirect('admin/contract_type', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/contract_type', 'refresh');
		}
	}
	public function save_contract_type()
	{
		$_POST['status'] = 'active';
		$_POST['entry_time'] = time();
		$_POST['entry_date'] = date('Y-m-d');
		$_POST['entry_from'] = 'admin';
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$data = $this->My_model->insert("contract_type", $_POST);
		if ($data) {
			$this->setToastMessage('Contract Added Successfully', 'success');
			redirect('admin/contract_type');
		} else {
			$this->setToastMessage('Contract Failed To Add..', 'success');
			redirect('admin/contract_type');
		}
	}
	public function edit_contract_type($id)
	{
		$data['det'] = $this->My_model->select_where("contract_type", ['status' => 'active', 'contract_type_id' => $id]);
		$this->ov("contract_type", $data);
	}
	public function delete_contract_type($id)
	{
		$data = $this->My_model->update("contract_type", ['status' => 'active', 'contract_type_id' => $id], ['status' => 'deleted']);
		if ($data) {
			$this->setToastMessage('Contract Deleted Successfully', 'success');
			redirect('admin/contract_type', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/contract_type', 'refresh');
		}
	}
	// public function add_admin()
	// {
	// 	$data['class'] = $this->db->query("SELECT * FROM grade,class WHERE class.grade_id = grade.grade_id AND class.status='active' AND grade.status = 'active' ")->result_array();
	// 	$this->ov("add_admin", $data);
	// }
	public function logout()
	{
		session_destroy();
		redirect('login', 'refresh');
	}

	public function city()
	{
		$data['states'] = $this->My_model->select_where("state", ['status' => 'active']);
		$data['list'] = $this->My_model->select_join_3(
			"city c",
			"state s",
			"district d",
			"c.state_id = s.state_id",
			"c.district_id = d.district_id",
			"c.*, s.state_name, d.district_name",
			['c.status' => 'active']
		);
		$this->ov("city", $data);
	}

	public function get_district_by_state()
	{
		$state_id = $_POST['state_id'];
		$districts = $this->My_model->select_where("district", ['status' => 'active', 'state_id' => $state_id]);
		echo json_encode($districts);
	}

	public function save_city()
	{
		$_POST['status'] = 'active';
		$_POST['entry_time'] = time();
		$_POST['entry_date'] = date('Y-m-d');
		$_POST['entry_from'] = 'admin';
		$_POST['entry_by'] = $_SESSION['admin_id'];

		$data = $this->My_model->insert("city", $_POST);

		$this->setToastMessage($data ? 'City Added Successfully' : 'Failed to Add City', $data ? 'success' : 'error');
		redirect('admin/city');
	}

	public function edit_city($id)
	{
		$city = $this->My_model->select_where("city", ['status' => 'active', 'city_id' => $id]);
		$state_id = $city[0]['state_id'];

		$data['det'] = $city;
		$data['states'] = $this->My_model->select_where("state", ['status' => 'active']);
		$data['districts'] = $this->My_model->select_where("district", ['status' => 'active', 'state_id' => $state_id]);

		$data['list'] = $this->My_model->select_join_3(
			"city c",
			"state s",
			"district d",
			"c.state_id = s.state_id",
			"c.district_id = d.district_id",
			"c.*, s.state_name, d.district_name",
			['c.status' => 'active']
		);
		$this->ov("city", $data);
	}


	public function update_city()
	{
		$data = $this->My_model->update("city", ['city_id' => $_POST['city_id']], $_POST);
		$this->setToastMessage($data ? 'City Updated Successfully' : 'Something Went Wrong', $data ? 'success' : 'error');
		redirect('admin/city');
	}

	public function delete_city($id)
	{
		$data = $this->My_model->update("city", ['city_id' => $id], ['status' => 'deleted']);
		$this->setToastMessage($data ? 'City Deleted Successfully' : 'Something Went Wrong', 'error');
		redirect('admin/city');
	}


	public function get_districts_by_state($state_id)
	{
		$data = $this->My_model->select_where("district", ['status' => 'active', 'state_id' => $state_id]);
		echo json_encode($data);
	}

	public function department()
	{
		$data['list'] = $this->My_model->select_where("department_tbl", ['status' => 'active']);
		$this->ov("department", $data);  // Load view department.php
	}

	public function save_department()
	{
		$_POST['status'] = 'active';
		$_POST['entry_date'] = date('Y-m-d');
		$_POST['entry_time'] = time();
		$_POST['entry_from'] = 'admin';
		$_POST['entry_by'] = $_SESSION['admin_id'];

		$data = $this->My_model->insert("department_tbl", $_POST);
		if ($data) {
			$this->setToastMessage("Department Added Successfully", "success");
		} else {
			$this->setToastMessage("Failed to Add Department", "error");
		}
		redirect('admin/department');
	}

	public function edit_department($id)
	{
		$data['det'] = $this->My_model->select_where("department_tbl", ['status' => 'active', 'department_tbl_id' => $id]);
		$data['list'] = $this->My_model->select_where("department_tbl", ['status' => 'active']);
		$this->ov("department", $data);
	}

	public function update_department()
	{
		$where = ['status' => 'active', 'department_tbl_id' => $_POST['department_tbl_id']];
		$data = $this->My_model->update("department_tbl", $where, $_POST);

		if ($data) {
			$this->setToastMessage("Department Updated Successfully", "success");
		} else {
			$this->setToastMessage("Failed to Update Department", "error");
		}
		redirect('admin/department');
	}
	public function delete_department($id)
	{
		$data = $this->My_model->update("department_tbl", ['department_tbl_id' => $id], ['status' => 'deleted']);
		if ($data) {
			$this->setToastMessage("Department Deleted Successfully", "error");
		} else {
			$this->setToastMessage("Failed to Delete Department", "error");
		}
		redirect('admin/department');
	}

	public function subject()
	{
		$data['list'] = $this->My_model->select_where("subject_tbl", ['status' => 'active']);
		$this->ov("subject", $data);  // Loads subject.php view
	}
	public function save_subject()
	{
		$_POST['status'] = 'active';
		$_POST['entry_date'] = date('Y-m-d');
		$_POST['entry_time'] = time();
		$_POST['entry_from'] = 'admin';
		$_POST['entry_by'] = $_SESSION['admin_id'];

		$data = $this->My_model->insert("subject_tbl", $_POST);
		if ($data) {
			$this->setToastMessage("Subject Added Successfully", "success");
		} else {
			$this->setToastMessage("Failed to Add Subject", "error");
		}
		redirect('admin/subject');
	}

	public function edit_subject($id)
	{
		$data['det'] = $this->My_model->select_where("subject_tbl", ['status' => 'active', 'subject_tbl_id' => $id]);
		$data['list'] = $this->My_model->select_where("subject_tbl", ['status' => 'active']);
		$this->ov("subject", $data);
	}
	public function update_subject()
	{
		$where = ['status' => 'active', 'subject_tbl_id' => $_POST['subject_tbl_id']];
		$data = $this->My_model->update("subject_tbl", $where, $_POST);

		if ($data) {
			$this->setToastMessage("Subject Updated Successfully", "success");
		} else {
			$this->setToastMessage("Failed to Update Subject", "error");
		}
		redirect('admin/subject');
	}
	public function delete_subject($id)
	{
		$data = $this->My_model->update("subject_tbl", ['subject_tbl_id' => $id], ['status' => 'deleted']);
		if ($data) {
			$this->setToastMessage("Subject Deleted Successfully", "success");
		} else {
			$this->setToastMessage("Failed to Delete Subject", "error");
		}
		redirect('admin/subject');
	}

	public function class_subject()
	{
		$data['class_list'] = $this->My_model->select_where("class", ['status' => 'active']);
		$data['subject_list'] = $this->My_model->select_where("subject_tbl", ['status' => 'active']);
		$this->ov("class_subject", $data);
	}

	public function subject_group()
	{
		$data['list'] = $this->My_model->select_where("subject_group_tbl", ['status' => 'active']);
		$data['class_list'] = $this->My_model->select_where("class", ['status' => 'active']);
		$this->ov("subject_group", $data);
	}
	public function save_subject_group()
	{
		$_POST['status'] = 'active';
		$_POST['entry_date'] = date('Y-m-d');
		$_POST['entry_time'] = time();
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['entry_from'] = 'admin';

		$data = $this->My_model->insert("subject_group_tbl", $_POST);
		if ($data) {
			$this->setToastMessage("Subject Group Added Successfully", "success");
		} else {
			$this->setToastMessage("Failed to Add Subject Group", "error");
		}
		redirect('admin/subject_group');
	}


	public function edit_subject_group($id)
	{
		$data['det'] = $this->My_model->select_where("subject_group_tbl", ['subject_group_tbl_id' => $id, 'status' => 'active']);
		$data['list'] = $this->My_model->select_where("subject_group_tbl", ['status' => 'active']);
		$data['class_list'] = $this->My_model->select_where("class", ['status' => 'active']);
		$this->ov("subject_group", $data);
	}
	public function update_subject_group()
	{
		$id = $_POST['subject_group_tbl_id'];
		$where = ['subject_group_tbl_id' => $id, 'status' => 'active'];

		$data = $this->My_model->update("subject_group_tbl", $where, $_POST);

		if ($data) {
			$this->setToastMessage("Subject Group Updated Successfully", "success");
		} else {
			$this->setToastMessage("Failed to Update Subject Group", "error");
		}
		redirect('admin/subject_group');
	}
	public function delete_subject_group($id)
	{
		$data = $this->My_model->update("subject_group_tbl", ['subject_group_tbl_id' => $id], ['status' => 'deleted']);

		if ($data) {
			$this->setToastMessage("Subject Group Deleted Successfully", "success");
		} else {
			$this->setToastMessage("Failed to Delete Subject Group", "error");
		}
		redirect('admin/subject_group');
	}

	public function assign_subjects()
	{
		$data['subject_groups'] = $this->My_model->select_where('subject_group_tbl', ['status' => 'active']);
		$data['subjects'] = $this->My_model->select_where('subject_tbl', ['status' => 'active']);
		$data['assigned'] = $this->My_model->select_where('assign_subject_tbl', []);
		$this->ov("assign_subjects", $data);
	}

	public function save_assigned_subjects()
	{
		$group_id = $_POST['subject_group_id'];
		$subject_ids = $_POST['subject_ids'] ?? [];

		// First delete previous entries
		$this->My_model->delete_where('assign_subject_tbl', ['subject_group_id' => $group_id]);

		foreach ($subject_ids as $subject_id) {
			$this->My_model->insert('assign_subject_tbl', [
				'subject_group_id' => $group_id,
				'subject_id' => $subject_id
			]);
		}

		$this->setToastMessage('Subjects Assigned Successfully', 'success');
		redirect('admin/assign_subjects');
	}

	public function edit_assigned_subjects($subject_group_id)
	{
		$data['subject_groups'] = $this->My_model->select_where('subject_group_tbl', ['status' => 'active']);
		$data['subjects'] = $this->My_model->select_where('subject_tbl', ['status' => 'active']);
		$data['assigned'] = $this->My_model->select_where('assign_subject_tbl', []);
		$data['selected_subjects'] = array_column(
			$this->My_model->select_where('assign_subject_tbl', ['subject_group_id' => $subject_group_id]),
			'subject_id'
		);
		$data['edit_id'] = $subject_group_id;
		$this->ov("edit_assign_subjects", $data);
	}

	public function update_assigned_subjects()
	{
		$group_id = $_POST['subject_group_id'];
		$subject_ids = $_POST['subject_ids'] ?? [];

		$this->My_model->delete_where('assign_subject_tbl', ['subject_group_id' => $group_id]);

		foreach ($subject_ids as $subject_id) {
			$this->My_model->insert('assign_subject_tbl', [
				'subject_group_id' => $group_id,
				'subject_id' => $subject_id
			]);
		}

		$this->setToastMessage('Subjects Updated Successfully', 'success');
		redirect('admin/assign_subjects');
	}

	public function delete_assigned_subjects($subject_group_id)
	{
		$this->My_model->delete_where('assign_subject_tbl', ['subject_group_id' => $subject_group_id]);
		$this->setToastMessage('Assigned Subjects Deleted', 'success');
		redirect('admin/assign_subjects');
	}

	// Show Fee Types List & Add/Edit Form
	public function fee_types()
	{
		$data['list'] = $this->My_model->select_where("fee_types", ['status' => 'active']);
		$this->ov("fee_types", $data);
	}

	// Save Fee Type
	public function save_fee_type()
	{
		$_POST['status'] = 'active';
		$_POST['entry_date'] = date('Y-m-d');
		$_POST['entry_time'] = time();
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['entry_from'] = 'admin';

		$data = $this->My_model->insert("fee_types", $_POST);
		$this->setToastMessage($data ? 'Fee Type Added Successfully' : 'Failed to Add Fee Type', $data ? 'success' : 'error');
		redirect('admin/fee_types');
	}

	// Edit Fee Type
	public function edit_fee_type($id)
	{
		$data['det'] = $this->My_model->select_where("fee_types", ['fee_types_id' => $id, 'status' => 'active']);
		$data['list'] = $this->My_model->select_where("fee_types", ['status' => 'active']);
		$this->ov("fee_types", $data);
	}

	// Update Fee Type
	public function update_fee_type()
	{
		$this->My_model->update("fee_types", ['fee_types_id' => $_POST['fee_types_id']], $_POST);
		$this->setToastMessage("Fee Type Updated Successfully", "success");
		redirect('admin/fee_types');
	}

	// Delete Fee Type
	public function delete_fee_type($id)
	{
		$this->My_model->update("fee_types", ['fee_types_id' => $id], ['status' => 'deleted']);
		$this->setToastMessage("Fee Type Deleted Successfully", "success");
		redirect('admin/fee_types');
	}
	// List + Form View
	public function competitions_types()
	{
		$data['list'] = $this->My_model->select_where("competitions_types", ['status' => 'active']);
		$this->ov("competitions_types", $data);
	}

	// Save
	public function save_competitions_type()
	{
		$_POST['status'] = 'active';
		$this->My_model->insert("competitions_types", $_POST);
		$this->setToastMessage("Competition Type Added Successfully", "success");
		redirect('admin/competitions_types');
	}

	// Edit
	public function edit_competitions_type($id)
	{
		$data['det'] = $this->My_model->select_where("competitions_types", ['competitions_types_id' => $id, 'status' => 'active']);
		$data['list'] = $this->My_model->select_where("competitions_types", ['status' => 'active']);
		$this->ov("competitions_types", $data);
	}

	// Update
	public function update_competitions_type()
	{
		$this->My_model->update("competitions_types", ['competitions_types_id' => $_POST['competitions_types_id']], $_POST);
		$this->setToastMessage("Competition Type Updated Successfully", "success");
		redirect('admin/competitions_types');
	}

	// Delete
	public function delete_competitions_type($id)
	{
		$this->My_model->update("competitions_types", ['competitions_types_id' => $id], ['status' => 'deleted']);
		$this->setToastMessage("Competition Type Deleted Successfully", "success");
		redirect('admin/competitions_types');
	}
	public function add_banner()
	{
		$data['list'] = $this->My_model->select_where("banner_tbl", ['status' => 'active']);
		$this->ov("add_banner", $data);
	}
	public function save_banner()
	{
		$_POST['status'] = 'active';
		$_POST['entry_date'] = date('Y-m-d');
		$_POST['entry_time'] = time();
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['entry_from'] = 'admin';
		if (!empty($_FILES['banner_img']['name'])) {
			$img_name = $_FILES['banner_img']['name'];
			$img_temp = $_FILES['banner_img']['tmp_name'];
			$path = "uploads/";
			$_POST['banner_img'] = $this->upload_img($img_name, $img_temp, $path);
		} else {
			$_FILES['banner_img'] = '';
		}
		$data = $this->My_model->insert("banner_tbl", $_POST);
		if ($data) {
			$this->setToastMessage('Banner Added Successfully', 'success');
			redirect('admin/add_banner', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_banner', 'refresh');
		}
	}
	public function edit_banner($id)
	{
		$data['det'] = $this->My_model->select_where("banner_tbl", ['status' => 'active', 'banner_tbl_id' => $id])[0];
		$this->ov("add_banner", $data);
	}
	public function update_banner()
	{
		if ($_FILES['banner_img']['name'] != "") {
			$imgname = $_FILES['banner_img']['name'];
			$imgtemp = $_FILES['banner_img']['tmp_name'];
			$path = "uploads/";
			$_POST['banner_img'] = $this->upload_img($imgname, $imgtemp, $path);
			$path2 = "uploads/" . $_POST['old_banner_img'];
			unlink($path2);
		} else {
			$_POST['banner_img'] = $_POST['old_banner_img'];
		}
		unset($_POST['old_banner_img']);

		$data = $this->My_model->update("banner_tbl", ['banner_tbl_id' => $_POST['banner_tbl_id']], $_POST);
		if ($data) {
			$this->setToastMessage('Banner Updated Successfully', 'success');
			redirect('admin/add_banner', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_banner', 'refresh');
		}
	}
	public function delete_banner($id)
	{
		$data = $this->My_model->update("banner_tbl", ['banner_tbl_id' => $id], ['status' => 'deleted']);
		if ($data) {
			$this->setToastMessage('Banner Deleted Successfully', 'success');
			redirect('admin/add_banner', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_banner', 'refresh');
		}
	}

	// About Us CRUD Methods
	public function about_us()
	{
		$data['list'] = $this->My_model->select_where("about_tbl", ['status' => 'active']);
		$this->ov("about_us", $data);
	}

	public function save_about_us()
	{
		$_POST['status'] = 'active';
		$_POST['entry_date'] = date('Y-m-d');
		$_POST['entry_time'] = time();
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['entry_from'] = 'admin';
		if (!empty($_FILES['about_img']['name'])) {
			$img_name = $_FILES['about_img']['name'];
			$img_temp = $_FILES['about_img']['tmp_name'];
			$path = "uploads/";
			$_POST['about_img'] = $this->upload_img($img_name, $img_temp, $path);
		} else {
			$_FILES['about_img'] = '';
		}
		$data = $this->My_model->insert("about_tbl", $_POST);
		if ($data) {
			$this->setToastMessage('About Us Added Successfully', 'success');
			redirect('admin/about_us', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/about_us', 'refresh');
		}
	}

	public function edit_about_us($id)
	{
		$data['det'] = $this->My_model->select_where("about_tbl", ['status' => 'active', 'about_tbl_id' => $id])[0];
		$data['list'] = $this->My_model->select_where("about_tbl", ['status' => 'active']);
		$this->ov("about_us", $data);
	}

	public function update_about_us()
	{
		if ($_FILES['about_img']['name'] != "") {
			$imgname = $_FILES['about_img']['name'];
			$imgtemp = $_FILES['about_img']['tmp_name'];
			$path = "uploads/";
			$_POST['about_img'] = $this->upload_img($imgname, $imgtemp, $path);
			$path2 = "uploads/" . $_POST['old_about_img'];
			if (file_exists($path2)) {
				unlink($path2);
			}
		} else {
			$_POST['about_img'] = $_POST['old_about_img'];
		}
		unset($_POST['old_about_img']);

		$data = $this->My_model->update("about_tbl", ['about_tbl_id' => $_POST['about_tbl_id']], $_POST);
		if ($data) {
			$this->setToastMessage('About Us Updated Successfully', 'success');
			redirect('admin/about_us', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/about_us', 'refresh');
		}
	}

	public function delete_about_us($id)
	{
		$data = $this->My_model->update("about_tbl", ['about_tbl_id' => $id], ['status' => 'deleted']);
		if ($data) {
			$this->setToastMessage('About Us Deleted Successfully', 'success');
			redirect('admin/about_us', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/about_us', 'refresh');
		}
	}

	// Mission and Vision CRUD Methods
	public function mission_and_vision()
	{
		$data['list'] = $this->My_model->select_where("mission_vision_tbl", ['status' => 'active']);
		$this->ov("mission_and_vision", $data);
	}

	public function save_mission_and_vision()
	{
		$_POST['status'] = 'active';
		$_POST['entry_date'] = date('Y-m-d');
		$_POST['entry_time'] = time();
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['entry_from'] = 'admin';
		if (!empty($_FILES['mission_vision_img']['name'])) {
			$img_name = $_FILES['mission_vision_img']['name'];
			$img_temp = $_FILES['mission_vision_img']['tmp_name'];
			$path = "uploads/";
			$_POST['mission_vision_img'] = $this->upload_img($img_name, $img_temp, $path);
		} else {
			$_FILES['mission_vision_img'] = '';
		}
		$data = $this->My_model->insert("mission_vision_tbl", $_POST);
		if ($data) {
			$this->setToastMessage('Mission and Vision Added Successfully', 'success');
			redirect('admin/mission_and_vision', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/mission_and_vision', 'refresh');
		}
	}

	public function edit_mission_and_vision($id)
	{
		$data['det'] = $this->My_model->select_where("mission_vision_tbl", ['status' => 'active', 'mission_vision_tbl_id' => $id])[0];
		$data['list'] = $this->My_model->select_where("mission_vision_tbl", ['status' => 'active']);
		$this->ov("mission_and_vision", $data);
	}

	public function update_mission_and_vision()
	{
		if ($_FILES['mission_vision_img']['name'] != "") {
			$imgname = $_FILES['mission_vision_img']['name'];
			$imgtemp = $_FILES['mission_vision_img']['tmp_name'];
			$path = "uploads/";
			$_POST['mission_vision_img'] = $this->upload_img($imgname, $imgtemp, $path);
			$path2 = "uploads/" . $_POST['old_mission_vision_img'];
			if (file_exists($path2)) {
				unlink($path2);
			}
		} else {
			$_POST['mission_vision_img'] = $_POST['old_mission_vision_img'];
		}
		unset($_POST['old_mission_vision_img']);

		$data = $this->My_model->update("mission_vision_tbl", ['mission_vision_tbl_id' => $_POST['mission_vision_tbl_id']], $_POST);
		if ($data) {
			$this->setToastMessage('Mission and Vision Updated Successfully', 'success');
			redirect('admin/mission_and_vision', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/mission_and_vision', 'refresh');
		}
	}

	public function delete_mission_and_vision($id)
	{
		$data = $this->My_model->update("mission_vision_tbl", ['mission_vision_tbl_id' => $id], ['status' => 'deleted']);
		if ($data) {
			$this->setToastMessage('Mission and Vision Deleted Successfully', 'success');
			redirect('admin/mission_and_vision', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/mission_and_vision', 'refresh');
		}
	}

	// Numbers CRUD Methods
	public function add_numbers()
	{
		$page_no = 1;
		$show = '';
		extract($_GET);

		// Search functionality
		if (!isset($_GET['q'])) {
			$search = "";
		} else {
			$search = " AND (mobile_number LIKE '%" . $_GET['q'] . "%' OR port_region LIKE '%" . $_GET['q'] . "%' OR price LIKE '%" . $_GET['q'] . "%')";
		}

		// Category filter
		$category_filter = '';
		if (isset($_GET['category']) && $_GET['category'] != '') {
			$category_filter = " AND category_tbl_id = '" . $_GET['category'] . "'";
		}

		// Status filter
		$status_filter = '';
		if (isset($_GET['status']) && $_GET['status'] != '') {
			$status_filter = " AND product_status = '" . $_GET['status'] . "'";
		}

		// Date range filter
		$form = isset($_GET['form']) ? $_GET['form'] : date('Y-m-d');
		$to = isset($_GET['to']) ? $_GET['to'] : date('Y-m-d');
		$date_filter = '';
		if ($form && $to) {
			$date_filter = " AND (DATE(entry_date) BETWEEN '$form' AND '$to')";
		}

		// Count total rows for pagination
		$total_rows = $this->db->query("SELECT count(numbers_tbl_id) as ttl_rows FROM numbers_tbl WHERE status = 'active' " . $search . $category_filter . $status_filter . $date_filter)->result_array()[0]['ttl_rows'];
		$per_page = 20;
		$data['start'] = $per_page * $page_no - $per_page;
		$data['ttl_pages'] = $total_rows / $per_page;
		$data['page_no'] = $page_no;

		// Get paginated data
		$data['list'] = $this->db->query("SELECT * FROM numbers_tbl WHERE status = 'active'" . $search . $category_filter . $status_filter . $date_filter . " ORDER BY numbers_tbl_id DESC LIMIT " . $data['start'] . "," . $per_page)->result_array();

		$data['categories'] = $this->My_model->select_where("category_tbl", ['status' => 'active']);
		$data['filters'] = $this->My_model->select_where("filter_tbl", ['status' => 'active']);

		$this->ov("add_numbers", $data);
	}

	public function save_number()
	{
		$_POST['status'] = 'active';
		$_POST['product_status'] = 'Available';
		$_POST['entry_date'] = date('Y-m-d');
		$_POST['entry_time'] = time();
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['entry_from'] = 'admin';
		$_POST['duplicate_number'] = str_replace(["+91", " ", "-"], "", $_POST['mobile_number']);


		// Check if mobile number already exists
		$existing = $this->My_model->select_where("numbers_tbl", ['mobile_number' => $_POST['mobile_number'], 'status' => 'active']);
		if (!empty($existing)) {
			$this->setToastMessage('Mobile Number Already Exists', 'error');
			redirect('admin/add_numbers', 'refresh');
			return;
		}

		$data = $this->My_model->insert("numbers_tbl", $_POST);
		if ($data) {
			$this->setToastMessage('Number Added Successfully', 'success');
			redirect('admin/add_numbers', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_numbers', 'refresh');
		}
	}

	public function edit_number($id)
	{
		$data['det'] = $this->My_model->select_where("numbers_tbl", ['status' => 'active', 'numbers_tbl_id' => $id])[0];
		$data['list'] = $this->My_model->select_where("numbers_tbl", ['status' => 'active']);
		$data['categories'] = $this->My_model->select_where("category_tbl", ['status' => 'active']);
		$data['filters'] = $this->My_model->select_where("filter_tbl", ['status' => 'active']);

		$this->ov("add_numbers", $data);
	}

	public function update_number()
	{
		// Check if mobile number already exists (excluding current record)
		$existing = $this->My_model->select_where("numbers_tbl", [
			'mobile_number' => $_POST['mobile_number'],
			'status' => 'active',
			'numbers_tbl_id !=' => $_POST['numbers_tbl_id']
		]);
		if (!empty($existing)) {
			$this->setToastMessage('Mobile Number Already Exists', 'error');
			redirect('admin/add_numbers', 'refresh');
			return;
		}

		$data = $this->My_model->update("numbers_tbl", ['numbers_tbl_id' => $_POST['numbers_tbl_id']], $_POST);
		if ($data) {
			$this->setToastMessage('Number Updated Successfully', 'success');
			redirect('admin/add_numbers', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_numbers', 'refresh');
		}
	}

	public function delete_number($id)
	{
		$data = $this->My_model->update("numbers_tbl", ['numbers_tbl_id' => $id], ['status' => 'deleted']);
		if ($data) {
			$this->setToastMessage('Number Deleted Successfully', 'success');
			redirect('admin/add_numbers', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_numbers', 'refresh');
		}
	}

	public function mark_sold($id)
	{
		$data = $this->My_model->update("numbers_tbl", ['numbers_tbl_id' => $id], ['product_status' => 'Sold', 'sold_date' => date('Y-m-d')]);
		if ($data) {
			$this->setToastMessage('Number Marked as Sold', 'success');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
		}
		redirect('admin/add_numbers', 'refresh');
	}

	public function mark_available($id)
	{
		$data = $this->My_model->update("numbers_tbl", ['numbers_tbl_id' => $id], ['product_status' => 'Available', 'sold_date' => null]);
		if ($data) {
			$this->setToastMessage('Number Marked as Available', 'success');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
		}
		redirect('admin/add_numbers', 'refresh');
	}

	public function bulk_mark_sold()
	{
		$ids = isset($_POST['selected_ids']) ? $_POST['selected_ids'] : '';
		if (empty($ids)) {
			$this->setToastMessage('No numbers selected', 'error');
			redirect('admin/add_numbers', 'refresh');
			return;
		}

		$id_array = explode(',', $ids);
		$success_count = 0;
		foreach ($id_array as $id) {
			$id = trim($id);
			if (!empty($id)) {
				$result = $this->My_model->update("numbers_tbl", ['numbers_tbl_id' => $id], ['product_status' => 'Sold', 'sold_date' => date('Y-m-d')]);
				if ($result)
					$success_count++;
			}
		}
		$this->setToastMessage($success_count . ' Numbers Marked as Sold', 'success');
		redirect('admin/add_numbers', 'refresh');
	}

	public function bulk_mark_available()
	{
		$ids = isset($_POST['selected_ids']) ? $_POST['selected_ids'] : '';
		if (empty($ids)) {
			$this->setToastMessage('No numbers selected', 'error');
			redirect('admin/add_numbers', 'refresh');
			return;
		}

		$id_array = explode(',', $ids);
		$success_count = 0;
		foreach ($id_array as $id) {
			$id = trim($id);
			if (!empty($id)) {
				$result = $this->My_model->update("numbers_tbl", ['numbers_tbl_id' => $id], ['product_status' => 'Available', 'sold_date' => null]);
				if ($result)
					$success_count++;
			}
		}
		$this->setToastMessage($success_count . ' Numbers Marked as Available', 'success');
		redirect('admin/add_numbers', 'refresh');
	}

	public function import_numbers_csv()
	{
		if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
			$this->setToastMessage('Please upload a valid CSV file', 'error');
			redirect('admin/add_numbers', 'refresh');
			return;
		}

		$file_path = $_FILES['csv_file']['tmp_name'];
		$file = fopen($file_path, 'r');

		$success_count = 0;
		$error_count = 0;
		$line_number = 0;
		$error_rows = [];
		$header = [];

		while (($row = fgetcsv($file)) !== FALSE) {
			$line_number++;

			// On first row, get header
			if ($line_number == 1) {
				$header = $row;
				// Add error column to header for error CSV
				$header[] = 'error_message';
				continue;
			}

			// Pad row to header length
			$row = array_pad($row, count($header) - 1, '');

			$error_message = '';

			// Validate required columns
			$mobile_number = isset($row[0]) ? trim($row[0]) : '';
			$price = isset($row[1]) ? trim($row[1]) : '';
			$org_price = isset($row[2]) ? trim($row[2]) : '';
			$category_name = isset($row[3]) ? trim($row[3]) : '';
			$port_region = isset($row[4]) ? trim($row[4]) : '';
			$filter_id = isset($row[5]) ? trim($row[5]) : '';

			if (empty($mobile_number)) {
				$error_message .= 'Mobile number is required. ';
			}
			if (empty($price)) {
				$error_message .= 'Price is required. ';
			}
			if (empty($org_price)) {
				$error_message .= 'Original Price is required. ';
			}
			if (empty($category_name)) {
				$error_message .= 'Category is required. ';
			}

			// Category check
			$category = [];
			if (!empty($category_name)) {
				$category = $this->My_model->select_where("category_tbl", ['status' => 'active', 'category_name' => $category_name]);
				if (empty($category)) {
					$error_message .= 'Category not found. ';
				}
			}

			// Filter check (required and must exist)
			if (empty($filter_id)) {
				$error_message .= 'Filter ID is required. ';
			} else {
				$filter = $this->My_model->select_where("filter_tbl", ['status' => 'active', 'filter_tbl_id' => $filter_id]);
				if (empty($filter)) {
					$error_message .= 'Filter ID not found. ';
				}
			}

			// Duplicate check
			if (!empty($mobile_number)) {
				$existing = $this->My_model->select_where("numbers_tbl", ['mobile_number' => $mobile_number, 'status' => 'active']);
				if (!empty($existing)) {
					$error_message .= 'Mobile number already exists. ';
				}
			}

			// If error, add to error_rows
			if (!empty($error_message)) {
				$error_row = $row;
				$error_row[] = trim($error_message);
				$error_rows[] = $error_row;
				$error_count++;
				continue;
			}

			$category_id = $category[0]['category_tbl_id'];

			// Insert data
			$insert_data = [
				'mobile_number' => $mobile_number,
				'duplicate_number' => str_replace(["+91", " ", "-"], "", $mobile_number),
				'price' => $price,
				'original_price' => $org_price,
				'category_tbl_id' => $category_id,
				'port_region' => $port_region,
				'filter_tbl_id' => $filter_id,
				'status' => 'active',
				'product_status' => 'Available',
				'entry_date' => date('Y-m-d'),
				'entry_time' => time(),
				'entry_by' => $_SESSION['admin_id'],
				'entry_from' => 'admin'
			];

			$result = $this->My_model->insert("numbers_tbl", $insert_data);
			if ($result) {
				$success_count++;
			} else {
				$error_row = $row;
				$error_row[] = 'Database insert failed.';
				$error_rows[] = $error_row;
				$error_count++;
			}
		}

		fclose($file);

		if ($error_count > 0) {

			// Download error CSV
			$filename = 'import_errors_' . date('Ymd_His') . "_{$error_count}_errors.csv";
			header('Content-Type: text/csv');
			header('Content-Disposition: attachment; filename="' . $filename . '"');
			$output = fopen('php://output', 'w');
			fputcsv($output, $header);
			foreach ($error_rows as $row) {
				fputcsv($output, $row);
			}
			fclose($output);
			exit;
		} else {
			$message = "Import completed: $success_count success, $error_count failed";
			$this->setToastMessage($message, $success_count > 0 ? 'success' : 'error');
			redirect('admin/add_numbers', 'refresh');
		}
	}

	public function download_sample_csv()
	{
		$filename = 'sample_numbers.csv';
		// Get all categories
		$categories = $this->My_model->select_where("category_tbl", ['status' => 'active']);
		$sample_data = [
			['mobile_number', 'price', 'original_price', 'category', 'port_region', 'filter_id']
		];
		// Add one sample for each category
		$i = 1;
		foreach ($categories as $key => $cat) {
			$sample_data[] = [
				'900000099' . $i,
				'500.00',
				'400.00',
				$cat['category_name'],
				'SampleRegion',
				$key + 1
			];
			$i++;
		}

		header('Content-Type: text/csv');
		header('Content-Disposition: attachment; filename="' . $filename . '"');
		header('Cache-Control: no-cache, must-revalidate');

		$output = fopen('php://output', 'w');
		foreach ($sample_data as $row) {
			fputcsv($output, $row);
		}
		fclose($output);
		exit;
	}
	public function faq()
	{
		$data['list'] = $this->My_model->select_where("faq_tbl", ['status' => 'active']);
		$this->ov("faq", $data);
	}
	public function save_faq()
	{

		$_POST['status'] = 'active';
		$_POST['entry_date'] = date('Y-m-d');
		$_POST['entry_time'] = time();
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['entry_from'] = 'admin';

		$data = $this->My_model->insert("faq_tbl", $_POST);
		if ($data) {
			$this->setToastMessage("FAQ Added Successfully", "success");
		} else {
			$this->setToastMessage("Failed to Add FAQ", "error");
		}
		redirect('admin/faq');
	}
	public function edit_faq($id)
	{
		$data['det'] = $this->My_model->select_where("faq_tbl", ['status' => 'active', 'faq_tbl_id' => $id]);
		$this->ov("faq", $data);
	}
	public function update_faq()
	{
		$where = ['status' => 'active', 'faq_tbl_id' => $_POST['faq_tbl_id']];
		$data = $this->My_model->update("faq_tbl", $where, $_POST);

		if ($data) {
			$this->setToastMessage("FAQ Updated Successfully", "success");
		} else {
			$this->setToastMessage("Failed to Update FAQ", "error");
		}
		redirect('admin/faq');
	}
	public function contact_form_list()
	{
		$page_no = 1;
		$show = '';
		extract($_GET);
		if (!isset($_GET['q'])) {
			$search = "";
		} else {
			$search = " AND (name LIKE '%" . $_GET['q'] . "%' OR email LIKE '%" . $_GET['q'] . "%' OR mobile_no LIKE '%" . $_GET['q'] . "%' OR message LIKE '%" . $_GET['q'] . "%')";
		}

		$form = isset($_GET['form']) ? $_GET['form'] : '';
		$to = isset($_GET['to']) ? $_GET['to'] : '';
		$date_filter = '';
		if ($form && $to) {
			$date_filter = " AND (DATE(entry_date) BETWEEN '$form' AND '$to')";
		}

		$total_rows = $this->db->query("SELECT count(contact_us_tbl_id) as ttl_rows FROM contact_us_tbl WHERE status != 'deleted'" . $search . $date_filter)->result_array()[0]['ttl_rows'];
		$per_page = 20;
		$data['start'] = $per_page * $page_no - $per_page;
		$data['ttl_pages'] = $total_rows / $per_page;
		$data['page_no'] = $page_no;
		$data['list'] = $this->db->query("SELECT * FROM contact_us_tbl WHERE status != 'deleted'" . $search . $date_filter . " ORDER BY contact_us_tbl_id DESC LIMIT " . $data['start'] . "," . $per_page)->result_array();

		$this->ov('contact_form_list', $data);
	}
	public function mark_as_seen($id)
	{
		$data = $this->My_model->update("contact_us_tbl", ['contact_us_tbl_id' => $id], ['status' => 'seen']);
		if ($data) {
			$this->setToastMessage("Marked as Seen Successfully", "success");
		} else {
			$this->setToastMessage("Failed to Mark as Seen", "error");
		}
		redirect('admin/contact_form_list');
	}
	public function delete_contact_form($id)
	{
		$data = $this->My_model->update("contact_us_tbl", ['contact_us_tbl_id' => $id], ['status' => 'deleted']);
		if ($data) {
			$this->setToastMessage("Contact Form Deleted Successfully", "success");
		} else {
			$this->setToastMessage("Failed to Delete Contact Form", "error");
		}
		redirect('admin/contact_form_list');
	}
	public function orders_list()
	{
		$data['list'] = $this->My_model->select_where("order_tbl", ['status' => 'active']);
		$this->ov('orders_list', $data);
	}
	public function add_filter()
	{
		$data['list'] = $this->My_model->select_where("filter_tbl", ['status' => 'active']);
		$this->ov("add_filter", $data);
	}
	public function edit_filter($id)
	{
		$data['det'] = $this->My_model->select_where("filter_tbl", ['status' => 'active', 'filter_tbl_id' => $id])[0];
		$this->ov("add_filter", $data);
	}
	public function update_filter()
	{
		$data['list'] = $this->My_model->update("filter_tbl", ['status' => 'active', 'filter_tbl_id' => $_POST['filter_tbl_id']], $_POST);
		if ($data) {
			$this->setToastMessage('filter Updated Successfully', 'success');
			redirect('admin/add_filter', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_filter', 'refresh');
		}
	}
	public function save_filter()
	{

		$_POST['added_by'] = 'admin';
		$_POST['entry_time'] = time();
		$_POST['entry_by'] = $_SESSION['admin_id'];
		$_POST['status'] = 'active';
		$data = $this->My_model->insert("filter_tbl", $_POST);
		if ($data) {
			$this->setToastMessage('Filter Added Successfully', 'success');
			redirect('admin/add_filter', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_filter', 'refresh');
		}
	}
	public function delete_filter($id)
	{
		$data['list'] = $this->My_model->update("filter_tbl", ['status' => 'active', 'filter_id' => $id], ['status' => 'deleted']);
		if ($data) {
			$this->setToastMessage('filter Deleted Successfully', 'success');
			redirect('admin/add_filter', 'refresh');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
			redirect('admin/add_filter', 'refresh');
		}
	}
	public function numbers_list()
	{

		$page_no = 1;
		$show = '';
		extract($_GET);

		// Search functionality
		if (!isset($_GET['q'])) {
			$search = "";
		} else {
			$search = " AND (mobile_number LIKE '%" . $_GET['q'] . "%' OR port_region LIKE '%" . $_GET['q'] . "%' OR price LIKE '%" . $_GET['q'] . "%')";
		}

		// Category filter
		$category_filter = '';
		if (isset($_GET['category']) && $_GET['category'] != '') {
			$category_filter = " AND category_tbl_id = '" . $_GET['category'] . "'";
		}

		// Status filter
		$status_filter = '';
		if (isset($_GET['status']) && $_GET['status'] != '') {
			$status_filter = " AND product_status = '" . $_GET['status'] . "'";
		}

		// Date range filter
		$form = isset($_GET['form']) ? $_GET['form'] : '';
		$to = isset($_GET['to']) ? $_GET['to'] : '';
		$date_filter = '';
		if ($form && $to) {
			$date_filter = " AND (DATE(entry_date) BETWEEN '$form' AND '$to')";
		}

		// Count total rows for pagination
		$total_rows = $this->db->query("SELECT count(numbers_tbl_id) as ttl_rows FROM numbers_tbl WHERE status = 'active'" . $search . $category_filter . $status_filter . $date_filter)->result_array()[0]['ttl_rows'];
		$per_page = 20;
		$data['start'] = $per_page * $page_no - $per_page;
		$data['ttl_pages'] = $total_rows / $per_page;
		$data['page_no'] = $page_no;

		// Get paginated data
		$data['list'] = $this->db->query("SELECT * FROM numbers_tbl WHERE status = 'active'" . $search . $category_filter . $status_filter . $date_filter . " ORDER BY numbers_tbl_id DESC LIMIT " . $data['start'] . "," . $per_page)->result_array();


		$data['categories'] = $this->My_model->select_where("category_tbl", ['status' => 'active']);
		$data['filters'] = $this->My_model->select_where("filter_tbl", ['status' => 'active']);

		$this->ov("numbers_list", $data);
	}


	public function mark_sold_2($id)
	{
		$data = $this->My_model->update("numbers_tbl", ['numbers_tbl_id' => $id], ['product_status' => 'Sold', 'sold_date' => date('Y-m-d')]);
		if ($data) {
			$this->setToastMessage('Number Marked as Sold', 'success');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
		}
		redirect('admin/numbers_list', 'refresh');
	}

	public function mark_available_2($id)
	{
		$data = $this->My_model->update("numbers_tbl", ['numbers_tbl_id' => $id], ['product_status' => 'Available', 'sold_date' => null]);
		if ($data) {
			$this->setToastMessage('Number Marked as Available', 'success');
		} else {
			$this->setToastMessage('Something Went Wrong', 'error');
		}
		redirect('admin/numbers_list', 'refresh');
	}

	public function bulk_mark_sold_2()
	{
		$ids = isset($_POST['selected_ids']) ? $_POST['selected_ids'] : '';
		if (empty($ids)) {
			$this->setToastMessage('No numbers selected', 'error');
			redirect('admin/numbers_list', 'refresh');
			return;
		}

		$id_array = explode(',', $ids);
		$success_count = 0;
		foreach ($id_array as $id) {
			$id = trim($id);
			if (!empty($id)) {
				$result = $this->My_model->update("numbers_tbl", ['numbers_tbl_id' => $id], ['product_status' => 'Sold', 'sold_date' => date('Y-m-d')]);
				if ($result)
					$success_count++;
			}
		}
		$this->setToastMessage($success_count . ' Numbers Marked as Sold', 'success');
		redirect('admin/add_numbers', 'refresh');
	}

	public function bulk_mark_available_2()
	{
		$ids = isset($_POST['selected_ids']) ? $_POST['selected_ids'] : '';
		if (empty($ids)) {
			$this->setToastMessage('No numbers selected', 'error');
			redirect('admin/add_numbers', 'refresh');
			return;
		}

		$id_array = explode(',', $ids);
		$success_count = 0;
		foreach ($id_array as $id) {
			$id = trim($id);
			if (!empty($id)) {
				$result = $this->My_model->update("numbers_tbl", ['numbers_tbl_id' => $id], ['product_status' => 'Available', 'sold_date' => null]);
				if ($result)
					$success_count++;
			}
		}
		$this->setToastMessage($success_count . ' Numbers Marked as Available', 'success');
		redirect('admin/add_numbers', 'refresh');
	}


}
