<!DOCTYPE html>
<html lang="en">
    
<!-- Mirrored from spacingtech.com/html/veppo/template/index3.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 11 Jul 2025 11:37:29 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Jewelnagar</title>
        <meta name="description" content="Veppo is a sleek, modern jewelry eCommerce HTML template built with Bootstrap. Perfect for luxury brands, boutiques & online stores.">
        <meta name="keywords" content="jewelry, eCommerce, bootstrap, HTML template, luxury, fashion, rings, bracelets, necklaces, shop">
        <meta name="author" content="spacingtech_webify">
        <!-- favicon -->
        <link rel="shortcut icon" type="image/favicon" href="<?=base_url()?>uploads/<?=$company_det[0]['company_logo']?>">
        <!-- plugin css -->
        <link rel="stylesheet" type="text/css" href="<?=base_url()?>u_assets/assets/css/plugin.css">
        <!-- theme css -->
        
        <link rel="stylesheet" type="text/css" href="<?=base_url()?>u_assets/assets/css/theme3.css">
        <!-- collection css -->
        <link rel="stylesheet" type="text/css" href="<?=base_url()?>u_assets/assets/css/collection3.css">
        <!-- blog css -->
        <link rel="stylesheet" type="text/css" href="<?=base_url()?>u_assets/assets/css/blog3.css">
        <!-- style css -->
        <link rel="stylesheet" type="text/css" href="<?=base_url()?>u_assets/assets/css/style3.css">
        <link rel="stylesheet" type="text/css" href="<?=base_url()?>u_assets/assets/css/product.css">
        
        <link rel="stylesheet" type="text/css" href="<?=base_url()?>u_assets/assets/css/collection.css">
        <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    </head>
    <body>